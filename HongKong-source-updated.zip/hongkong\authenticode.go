package main

import (
	"bytes"
	"crypto"
	"crypto/sha1"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/asn1"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"hash"
	"math/big"
	"strings"
	"time"
	"unicode/utf16"

	_ "crypto/sha256"
	_ "crypto/sha512"
)

// Native Authenticode verification. It reads the signature embedded in a PE
// file without asking Windows, so forged chains, self-signed signers and
// tampered files are caught even when PowerShell is blocked or a fake root
// has been planted in the trusted store to make Windows say "Valid".

type EmbeddedSig struct {
	Present     bool
	ParseErr    string
	DigestAlg   string
	DigestOK    bool // PE image hash matches the signed digest
	SignatureOK bool // signer's signature over the signed attributes verifies
	Signer      *x509.Certificate
	Chain       []*x509.Certificate // signer first, walking up through embedded certs
	Top         *x509.Certificate
	TopSelf     bool // top of the embedded chain is self-issued and self-verifying
	TopThumb    string
	ChainBroken string // an embedded parent does not actually sign its child
	Smuggled    int    // non-zero bytes after the PKCS#7 blob inside the certificate table
}

var (
	oidSignedData   = asn1.ObjectIdentifier{1, 2, 840, 113549, 1, 7, 2}
	oidSpcIndirect  = asn1.ObjectIdentifier{1, 3, 6, 1, 4, 1, 311, 2, 1, 4}
	oidMessageDigst = asn1.ObjectIdentifier{1, 2, 840, 113549, 1, 9, 4}
	oidSHA1         = asn1.ObjectIdentifier{1, 3, 14, 3, 2, 26}
	oidSHA256       = asn1.ObjectIdentifier{2, 16, 840, 1, 101, 3, 4, 2, 1}
	oidSHA384       = asn1.ObjectIdentifier{2, 16, 840, 1, 101, 3, 4, 2, 2}
	oidSHA512       = asn1.ObjectIdentifier{2, 16, 840, 1, 101, 3, 4, 2, 3}
)

type p7ContentInfo struct {
	ContentType asn1.ObjectIdentifier
	Content     asn1.RawValue `asn1:"explicit,optional,tag:0"`
}

type p7SignedData struct {
	Version          int
	DigestAlgorithms asn1.RawValue
	ContentInfo      p7ContentInfo
	Certificates     asn1.RawValue  `asn1:"optional,tag:0"`
	CRLs             asn1.RawValue  `asn1:"optional,tag:1"`
	SignerInfos      []p7SignerInfo `asn1:"set"`
}

type p7IssuerSerial struct {
	Issuer asn1.RawValue
	Serial *big.Int
}

type p7SignerInfo struct {
	Version         int
	IssuerSerial    p7IssuerSerial
	DigestAlgorithm pkix.AlgorithmIdentifier
	AuthAttrs       asn1.RawValue `asn1:"optional,tag:0"`
	DigestEncAlg    pkix.AlgorithmIdentifier
	EncryptedDigest []byte
	UnauthAttrs     asn1.RawValue `asn1:"optional,tag:1"`
}

type p7DigestInfo struct {
	Algorithm pkix.AlgorithmIdentifier
	Digest    []byte
}

type p7SpcIndirect struct {
	Data          asn1.RawValue
	MessageDigest p7DigestInfo
}

type p7Attribute struct {
	Type   asn1.ObjectIdentifier
	Values asn1.RawValue `asn1:"set"`
}

func hashFor(oid asn1.ObjectIdentifier) (crypto.Hash, string) {
	switch {
	case oid.Equal(oidSHA1):
		return crypto.SHA1, "SHA1"
	case oid.Equal(oidSHA256):
		return crypto.SHA256, "SHA256"
	case oid.Equal(oidSHA384):
		return crypto.SHA384, "SHA384"
	case oid.Equal(oidSHA512):
		return crypto.SHA512, "SHA512"
	}
	return 0, oid.String()
}

func thumbprint(c *x509.Certificate) string {
	s := sha1.Sum(c.Raw)
	return strings.ToUpper(hex.EncodeToString(s[:]))
}

// peLayout returns the offsets Authenticode excludes from the image hash.
func peLayout(b []byte) (checksumOff, secDirOff int, certOff, certSize uint32, err error) {
	if len(b) < 0x40 || b[0] != 'M' || b[1] != 'Z' {
		return 0, 0, 0, 0, errors.New("not a PE file")
	}
	pe := int(binary.LittleEndian.Uint32(b[0x3c:]))
	if pe < 0 || pe+24+96 > len(b) || string(b[pe:pe+4]) != "PE\x00\x00" {
		return 0, 0, 0, 0, errors.New("bad PE header")
	}
	opt := pe + 24
	magic := binary.LittleEndian.Uint16(b[opt:])
	var dd int
	switch magic {
	case 0x10b:
		dd = opt + 96
	case 0x20b:
		dd = opt + 112
	default:
		return 0, 0, 0, 0, errors.New("unknown optional header")
	}
	numDirs := int(binary.LittleEndian.Uint32(b[dd-4:]))
	if numDirs < 5 || dd+5*8 > len(b) {
		return 0, 0, 0, 0, errors.New("no security directory")
	}
	secDirOff = dd + 4*8
	certOff = binary.LittleEndian.Uint32(b[secDirOff:])
	certSize = binary.LittleEndian.Uint32(b[secDirOff+4:])
	return opt + 64, secDirOff, certOff, certSize, nil
}

func peImageHash(b []byte, h hash.Hash, checksumOff, secDirOff int, certOff, certSize uint32) []byte {
	h.Write(b[:checksumOff])
	h.Write(b[checksumOff+4 : secDirOff])
	end := int(certOff)
	if end <= secDirOff+8 || end > len(b) {
		end = len(b)
	}
	h.Write(b[secDirOff+8 : end])
	if tail := int(certOff) + int(certSize); int(certOff) > 0 && tail < len(b) {
		h.Write(b[tail:])
	}
	return h.Sum(nil)
}

// VerifyEmbedded parses and verifies the embedded Authenticode signature.
func VerifyEmbedded(b []byte) EmbeddedSig {
	var es EmbeddedSig
	checksumOff, secDirOff, certOff, certSize, err := peLayout(b)
	if err != nil {
		es.ParseErr = err.Error()
		return es
	}
	if certOff == 0 || certSize < 8 || int(certOff)+int(certSize) > len(b) {
		return es // not signed (catalog-signed files land here too)
	}
	es.Present = true
	wc := b[certOff : certOff+certSize]
	l := int(binary.LittleEndian.Uint32(wc))
	if l < 8 || l > len(wc) || binary.LittleEndian.Uint16(wc[6:]) != 2 {
		es.ParseErr = "unsupported WIN_CERTIFICATE"
		return es
	}
	var ci p7ContentInfo
	trailing, err := asn1.Unmarshal(wc[8:l], &ci)
	if err != nil || !ci.ContentType.Equal(oidSignedData) {
		es.ParseErr = "signature is not PKCS#7 signed data"
		return es
	}
	// Anything non-zero after the signature (CVE-2013-3900 style padding abuse)
	// is not covered by the signature and can carry a hidden payload/config.
	for _, part := range [][]byte{trailing, wc[l:]} {
		for _, c := range part {
			if c != 0 {
				es.Smuggled++
			}
		}
	}
	var sd p7SignedData
	if _, err := asn1.Unmarshal(ci.Content.Bytes, &sd); err != nil {
		es.ParseErr = "malformed signed data: " + err.Error()
		return es
	}
	if !sd.ContentInfo.ContentType.Equal(oidSpcIndirect) || len(sd.SignerInfos) == 0 {
		es.ParseErr = "not an Authenticode signature"
		return es
	}

	// certificates [0] IMPLICIT SET OF Certificate
	var certs []*x509.Certificate
	rest := sd.Certificates.Bytes
	for len(rest) > 0 {
		var rv asn1.RawValue
		r, err := asn1.Unmarshal(rest, &rv)
		if err != nil {
			break
		}
		rest = r
		if c, err := x509.ParseCertificate(rv.FullBytes); err == nil {
			certs = append(certs, c)
		}
	}

	// SpcIndirectDataContent: the signed PE digest.
	spcRaw := sd.ContentInfo.Content
	var spc p7SpcIndirect
	if _, err := asn1.Unmarshal(spcRaw.Bytes, &spc); err != nil {
		es.ParseErr = "malformed SpcIndirectDataContent"
		return es
	}
	h, name := hashFor(spc.MessageDigest.Algorithm.Algorithm)
	es.DigestAlg = name
	if h == 0 || !h.Available() {
		es.ParseErr = "unsupported digest " + name
		return es
	}
	got := peImageHash(b, h.New(), checksumOff, secDirOff, certOff, certSize)
	es.DigestOK = bytes.Equal(got, spc.MessageDigest.Digest)

	si := sd.SignerInfos[0]
	for _, c := range certs {
		if c.SerialNumber.Cmp(si.IssuerSerial.Serial) == 0 && bytes.Equal(c.RawIssuer, si.IssuerSerial.Issuer.FullBytes) {
			es.Signer = c
		}
	}
	if es.Signer == nil {
		es.ParseErr = "signer certificate not embedded"
		return es
	}

	// The signed attributes must carry the hash of the SpcIndirectDataContent
	// (PKCS#7 v1.5: content octets without the outer tag/length).
	sh, _ := hashFor(si.DigestAlgorithm.Algorithm)
	if sh == 0 || !sh.Available() {
		sh = h
	}
	signed := spcRaw.Bytes
	if len(si.AuthAttrs.FullBytes) > 0 {
		attrsOK := false
		rest := si.AuthAttrs.Bytes
		for len(rest) > 0 {
			var a p7Attribute
			r, err := asn1.Unmarshal(rest, &a)
			if err != nil {
				break
			}
			rest = r
			if a.Type.Equal(oidMessageDigst) {
				var md []byte
				if _, err := asn1.Unmarshal(a.Values.Bytes, &md); err == nil {
					// spcRaw.Bytes is the SEQUENCE; hash its contents.
					// Classic Authenticode hashes the content octets; some signing
					// tools hash the whole encoding (CMS style). Accept either.
					var seq asn1.RawValue
					if _, err := asn1.Unmarshal(spcRaw.Bytes, &seq); err == nil {
						for _, part := range [][]byte{seq.Bytes, spcRaw.Bytes} {
							hh := sh.New()
							hh.Write(part)
							if bytes.Equal(hh.Sum(nil), md) {
								attrsOK = true
							}
						}
					}
				}
			}
		}
		if !attrsOK {
			es.SignatureOK = false
			es.buildChain(certs)
			return es
		}
		signed = append([]byte{0x31}, si.AuthAttrs.FullBytes[1:]...)
	}
	es.SignatureOK = checkSig(es.Signer, sh, signed, si.EncryptedDigest)
	es.buildChain(certs)
	return es
}

func checkSig(c *x509.Certificate, h crypto.Hash, signed, sig []byte) bool {
	var algos []x509.SignatureAlgorithm
	switch c.PublicKeyAlgorithm {
	case x509.RSA:
		algos = map[crypto.Hash][]x509.SignatureAlgorithm{
			crypto.SHA1: {x509.SHA1WithRSA}, crypto.SHA256: {x509.SHA256WithRSA},
			crypto.SHA384: {x509.SHA384WithRSA}, crypto.SHA512: {x509.SHA512WithRSA}}[h]
	case x509.ECDSA:
		algos = map[crypto.Hash][]x509.SignatureAlgorithm{
			crypto.SHA1: {x509.ECDSAWithSHA1}, crypto.SHA256: {x509.ECDSAWithSHA256},
			crypto.SHA384: {x509.ECDSAWithSHA384}, crypto.SHA512: {x509.ECDSAWithSHA512}}[h]
	}
	for _, a := range algos {
		if c.CheckSignature(a, signed, sig) == nil {
			return true
		}
	}
	return false
}

// signs reports whether parent's key produced child's certificate signature
// (SHA-1 allowed: plenty of legitimate older chains still use it).
func signs(parent, child *x509.Certificate) bool {
	return parent.CheckSignature(child.SignatureAlgorithm, child.RawTBSCertificate, child.Signature) == nil
}

func (es *EmbeddedSig) buildChain(certs []*x509.Certificate) {
	cur := es.Signer
	es.Chain = []*x509.Certificate{cur}
	for depth := 0; depth < 8; depth++ {
		if bytes.Equal(cur.RawIssuer, cur.RawSubject) {
			break
		}
		var parent *x509.Certificate
		for _, c := range certs {
			if c != cur && bytes.Equal(c.RawSubject, cur.RawIssuer) {
				parent = c
				break
			}
		}
		if parent == nil {
			break
		}
		if !signs(parent, cur) {
			es.ChainBroken = firstCN(parent.Subject.String()) + " did not sign " + firstCN(cur.Subject.String())
		}
		es.Chain = append(es.Chain, parent)
		cur = parent
	}
	es.Top = cur
	es.TopThumb = thumbprint(cur)
	es.TopSelf = bytes.Equal(cur.RawIssuer, cur.RawSubject) && signs(cur, cur)
}

// ---------------------------------------------------------------------------
// Root trust knowledge

// Thumbprints of genuine Microsoft root certificates. A chain that names a
// Microsoft root but ends anywhere else is forged.
var genuineMicrosoftRoots = map[string]string{
	"8F43288AD272F3103B6FB1428485EA3014C0BCFE": "Microsoft Root Certificate Authority 2011",
	"3B1EFD3A66EA28B16697394703A72CA340A05BD5": "Microsoft Root Certificate Authority 2010",
	"CDD4EEAE6000AC7F40C3802C171E30148030C072": "Microsoft Root Certificate Authority",
	"A43489159A520F0D93D032CCAF37E7FE20A8B419": "Microsoft Root Authority",
	"245C97DF7514E7CF2DF8BE72AE957B9E04741E85": "Copyright (c) 1997 Microsoft Corp.",
	"7F88CD7223F3C813818C994614A89C99FA3B5247": "Microsoft Authenticode(tm) Root Authority",
	"06F1AA330B927B753A40E68CDF22E34BCBEF3352": "Microsoft ECC Product Root Certificate Authority 2018",
	"F40042E2E5F7E8EF8189FED15519AECE42C3BFA2": "Microsoft Identity Verification Root Certificate Authority 2020",
	"0119E81BE9A14CD8E22F40AC118C687ECBA3F4D8": "Microsoft Time Stamp Root Certificate Authority 2014",
	"31F9FC8BA3805986B721EA7295C65B3A44534274": "Microsoft ECC TS Root Certificate Authority 2018",
}

// TrustDB is what the machine actually trusts, read from the registry.
type TrustDB struct {
	CTL        map[string]bool // roots in Microsoft's Trusted Root Program (authroot.stl)
	CTLLoaded  bool
	Enterprise map[string]bool   // roots deployed by Group Policy / enterprise PKI
	UserRoots  map[string]string // thumbprint -> hive where a user added it
	Disallowed map[string]bool
	Machine    map[string]bool // in the machine Root / AuthRoot stores
}

func newTrustDB() *TrustDB {
	return &TrustDB{CTL: map[string]bool{}, Enterprise: map[string]bool{}, UserRoots: map[string]string{},
		Disallowed: map[string]bool{}, Machine: map[string]bool{}}
}

// parseCTL extracts SHA-1 subject identifiers from an encoded authroot CTL.
// Every OCTET STRING of length 20 is a candidate; stray matches inside the
// signature are harmless because lookups use real thumbprints.
func parseCTL(b []byte) map[string]bool {
	out := map[string]bool{}
	for i := 0; i+22 <= len(b); i++ {
		if b[i] == 0x04 && b[i+1] == 0x14 {
			out[strings.ToUpper(hex.EncodeToString(b[i+2:i+22]))] = true
		}
	}
	return out
}

func (t *TrustDB) inProgram(thumb string) bool {
	return t != nil && (t.CTL[thumb] || genuineMicrosoftRoots[thumb] != "")
}

func claimsMicrosoft(subjects ...string) bool {
	for _, s := range subjects {
		l := strings.ToLower(s)
		if strings.Contains(l, "o=microsoft corporation") || strings.HasPrefix(strings.ToLower(firstCN(s)), "microsoft ") {
			return true
		}
	}
	return false
}

// rootVerdict decides whether a chain root is genuine.
//   - forged: claims Microsoft but is not a genuine Microsoft root
//   - local:  not in Microsoft's root program and not enterprise-deployed
func (t *TrustDB) rootVerdict(thumb, rootSubject, leafSubject string, rootNotBefore time.Time, now time.Time) (forged, local bool) {
	if thumb == "" {
		return false, false
	}
	if claimsMicrosoft(rootSubject, leafSubject) && genuineMicrosoftRoots[thumb] == "" {
		if t.CTLLoaded {
			forged = !t.CTL[thumb] || !claimsMicrosoft(rootSubject)
		} else {
			// Without the CTL, only call it forged when the "Microsoft" root is brand new.
			forged = !rootNotBefore.IsZero() && rootNotBefore.After(now.AddDate(-3, 0, 0))
		}
	}
	if t.CTLLoaded && !t.inProgram(thumb) && !t.Enterprise[thumb] {
		local = true
	}
	return forged, local
}

// ---------------------------------------------------------------------------
// Certificate store blobs

// certFromBlob pulls the DER certificate (CERT_CERT_PROP_ID = 32) out of a
// registry certificate-store "Blob" value.
func certFromBlob(b []byte) []byte {
	for off := 0; off+12 <= len(b); {
		id := binary.LittleEndian.Uint32(b[off:])
		n := int(binary.LittleEndian.Uint32(b[off+8:]))
		off += 12
		if n < 0 || off+n > len(b) {
			return nil
		}
		if id == 32 {
			return b[off : off+n]
		}
		off += n
	}
	return nil
}

func notBefore(c *x509.Certificate) time.Time {
	if c == nil {
		return time.Time{}
	}
	return c.NotBefore
}

// versionStrings reads CompanyName / OriginalFilename from a PE's version
// resource by scanning for the UTF-16 keys (used when PowerShell is unavailable).
func versionStrings(b []byte) (company, original string) {
	find := func(key string) string {
		k := []byte{}
		for _, r := range key + "\x00" {
			k = append(k, byte(r), 0)
		}
		i := bytes.Index(b, k)
		if i < 0 {
			return ""
		}
		j := i + len(k)
		for j+1 < len(b) && b[j] == 0 && b[j+1] == 0 && (j-i)%4 != 0 {
			j += 2
		}
		for j+1 < len(b) && b[j] == 0 && b[j+1] == 0 && j-i-len(k) < 4 {
			j += 2
		}
		var u []uint16
		for ; j+1 < len(b) && len(u) < 260; j += 2 {
			c := binary.LittleEndian.Uint16(b[j:])
			if c == 0 {
				break
			}
			u = append(u, c)
		}
		return strings.TrimSpace(string(utf16Decode(u)))
	}
	return find("CompanyName"), find("OriginalFilename")
}

func utf16Decode(u []uint16) []rune { return utf16.Decode(u) }

// peTimestamp returns the COFF TimeDateStamp of a PE image.
func peTimestamp(b []byte) time.Time {
	if len(b) < 0x40 || b[0] != 'M' || b[1] != 'Z' {
		return time.Time{}
	}
	pe := int(binary.LittleEndian.Uint32(b[0x3c:]))
	if pe < 0 || pe+12 > len(b) || string(b[pe:pe+4]) != "PE\x00\x00" {
		return time.Time{}
	}
	ts := binary.LittleEndian.Uint32(b[pe+8:])
	if ts == 0 {
		return time.Time{}
	}
	return time.Unix(int64(ts), 0).UTC()
}
