//go:build windows

package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

var (
	advapi32          = syscall.NewLazyDLL("advapi32.dll")
	procRegEnumValueW = advapi32.NewProc("RegEnumValueW")
	shell32           = syscall.NewLazyDLL("shell32.dll")
	procIsUserAnAdmin = shell32.NewProc("IsUserAnAdmin")
	procShellExecuteW = shell32.NewProc("ShellExecuteW")
)

const (
	errNoMoreItems   = syscall.Errno(259)
	errMoreData      = syscall.Errno(234)
	createNoWindow   = 0x08000000
	maxSigBatchFiles = 4000
)

type winPlatform struct{}

func newPlatform() Platform { return winPlatform{} }

func (winPlatform) Getenv(k string) string { return os.Getenv(k) }

func (winPlatform) Stat(p string) FileStat {
	st, err := os.Stat(p)
	if err != nil {
		return FileStat{Denied: !os.IsNotExist(err) && !errors.Is(err, syscall.ERROR_PATH_NOT_FOUND) &&
			!errors.Is(err, syscall.Errno(123) /* ERROR_INVALID_NAME */)}
	}
	fs := FileStat{Exists: true, IsDir: st.IsDir(), Size: st.Size(), ModTime: st.ModTime()}
	if d, ok := st.Sys().(*syscall.Win32FileAttributeData); ok {
		fs.CTime = time.Unix(0, d.CreationTime.Nanoseconds())
	}
	return fs
}

func (winPlatform) ReadFile(p string, max int64) ([]byte, error) {
	f, err := os.Open(p)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return io.ReadAll(io.LimitReader(f, max))
}

func (winPlatform) HashFile(p string) (string, error) {
	f, err := os.Open(p)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func (winPlatform) ListDir(p string) ([]string, error) {
	ents, err := os.ReadDir(p)
	if err != nil {
		return nil, err
	}
	out := make([]string, 0, len(ents))
	for _, e := range ents {
		out = append(out, e.Name())
	}
	return out, nil
}

func systemRoot() string {
	if sr := os.Getenv("SystemRoot"); sr != "" {
		return sr
	}
	return `C:\Windows`
}

func (winPlatform) TaskFiles() ([]TaskFile, error) {
	root := filepath.Join(systemRoot(), "System32", "Tasks")
	var out []TaskFile
	err := filepath.WalkDir(root, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			if p == root {
				return err
			}
			if d != nil && d.IsDir() {
				return fs.SkipDir
			}
			return nil
		}
		if d.IsDir() {
			return nil
		}
		rel, _ := filepath.Rel(root, p)
		tf := TaskFile{RelPath: rel}
		if info, e := d.Info(); e == nil {
			tf.ModTime = info.ModTime()
		}
		f, e := os.Open(p)
		if e != nil {
			tf.Err = e
		} else {
			tf.Data, tf.Err = io.ReadAll(io.LimitReader(f, 8<<20))
			f.Close()
		}
		out = append(out, tf)
		return nil
	})
	return out, err
}

func rootHandle(root string) (syscall.Handle, error) {
	switch strings.ToUpper(root) {
	case "HKLM":
		return syscall.HKEY_LOCAL_MACHINE, nil
	case "HKU":
		return syscall.HKEY_USERS, nil
	case "HKCU":
		return syscall.HKEY_CURRENT_USER, nil
	}
	return 0, errors.New("unknown registry root " + root)
}

func openKey(root, path string) (syscall.Handle, error) {
	rh, err := rootHandle(root)
	if err != nil {
		return 0, err
	}
	if path == "" {
		return rh, nil
	}
	p, err := syscall.UTF16PtrFromString(path)
	if err != nil {
		return 0, err
	}
	var h syscall.Handle
	err = syscall.RegOpenKeyEx(rh, p, 0, syscall.KEY_READ|syscall.KEY_WOW64_64KEY, &h)
	return h, err
}

func closeKey(h syscall.Handle) {
	if h != syscall.HKEY_LOCAL_MACHINE && h != syscall.HKEY_USERS && h != syscall.HKEY_CURRENT_USER {
		syscall.RegCloseKey(h)
	}
}

// RegKeyModTime returns the registry key's last write time via
// RegQueryInfoKey (zero time when the key cannot be opened or the
// timestamp is not maintained).
func (winPlatform) RegKeyModTime(root, path string) time.Time {
	h, err := openKey(root, path)
	if err != nil {
		return time.Time{}
	}
	defer closeKey(h)
	var ft syscall.Filetime
	if err := syscall.RegQueryInfoKey(h, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, &ft); err != nil {
		return time.Time{}
	}
	nt := int64(ft.HighDateTime)<<32 | int64(ft.LowDateTime)
	if nt == 0 {
		return time.Time{}
	}
	return time.Unix(0, (nt-116444736000000000)*100).UTC()
}

func (winPlatform) RegSubkeys(root, path string) ([]string, error) {
	h, err := openKey(root, path)
	if err != nil {
		return nil, err
	}
	defer closeKey(h)
	var n, maxLen uint32
	if err := syscall.RegQueryInfoKey(h, nil, nil, nil, &n, &maxLen, nil, nil, nil, nil, nil, nil); err != nil {
		return nil, err
	}
	out := make([]string, 0, n)
	buf := make([]uint16, maxLen+2)
	for i := uint32(0); ; i++ {
		l := uint32(len(buf))
		err := syscall.RegEnumKeyEx(h, i, &buf[0], &l, nil, nil, nil, nil)
		if err == errNoMoreItems {
			break
		}
		if err == errMoreData {
			buf = make([]uint16, len(buf)*2+256)
			i--
			continue
		}
		if err != nil {
			return out, err
		}
		out = append(out, syscall.UTF16ToString(buf[:l]))
	}
	return out, nil
}

func (winPlatform) RegValues(root, path string) (map[string]RegValue, error) {
	h, err := openKey(root, path)
	if err != nil {
		return nil, err
	}
	defer closeKey(h)
	var nVals, maxName, maxData uint32
	if err := syscall.RegQueryInfoKey(h, nil, nil, nil, nil, nil, nil, &nVals, &maxName, &maxData, nil, nil); err != nil {
		return nil, err
	}
	out := map[string]RegValue{}
	name := make([]uint16, maxName+2)
	data := make([]byte, maxData+8)
	for i := uint32(0); ; i++ {
		nl := uint32(len(name))
		dl := uint32(len(data))
		var typ uint32
		r, _, _ := procRegEnumValueW.Call(uintptr(h), uintptr(i), uintptr(unsafe.Pointer(&name[0])),
			uintptr(unsafe.Pointer(&nl)), 0, uintptr(unsafe.Pointer(&typ)),
			uintptr(unsafe.Pointer(&data[0])), uintptr(unsafe.Pointer(&dl)))
		e := syscall.Errno(r)
		if e == errNoMoreItems {
			break
		}
		if e == errMoreData {
			name = make([]uint16, len(name)*2+256)
			data = make([]byte, len(data)*2+4096)
			i--
			continue
		}
		if e != 0 {
			return out, e
		}
		v := RegValue{Name: syscall.UTF16ToString(name[:nl]), Type: typ}
		b := append([]byte(nil), data[:dl]...)
		switch typ {
		case regSZ, regExpandSZ:
			v.Str = strings.TrimRight(utf16le(b), "\x00")
		case regMultiSZ:
			for _, s := range strings.Split(utf16le(b), "\x00") {
				if s != "" {
					v.Strs = append(v.Strs, s)
				}
			}
		case regDWORD:
			if len(b) >= 4 {
				v.Num = uint64(b[0]) | uint64(b[1])<<8 | uint64(b[2])<<16 | uint64(b[3])<<24
			}
		case regQWORD:
			for j := 0; j < 8 && j < len(b); j++ {
				v.Num |= uint64(b[j]) << (8 * j)
			}
		default:
			v.Bin = b
		}
		out[strings.ToLower(v.Name)] = v
	}
	return out, nil
}

// sigScript verifies every path with Get-AuthenticodeSignature (embedded and
// catalog signatures), rebuilds the signer chain without network revocation to
// classify self-signed / untrusted-root / broken certificates, and reads the
// version resource so renamed system binaries can be spotted.
const sigScript = `
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$paths = Get-Content -LiteralPath $args[0] -Encoding UTF8
$out = foreach ($p in $paths) {
  if (-not $p) { continue }
  $r = [ordered]@{ Path=$p; Status='Error'; Message=''; Signer=''; Issuer=''; Root=''; Thumbprint=''; Type='';
                   Chain=''; Original=''; Company=''; RootThumb=''; RootNotBefore=''; SelfSigned=$false; Timestamped=$false }
  try {
    $s = Get-AuthenticodeSignature -LiteralPath $p -ErrorAction Stop
    $r.Status = [string]$s.Status
    $r.Message = [string]$s.StatusMessage
    $r.Type = [string]$s.SignatureType
    $r.Timestamped = [bool]$s.TimeStamperCertificate
    $c = $s.SignerCertificate
    if ($c) {
      $r.Signer = $c.Subject; $r.Issuer = $c.Issuer; $r.Thumbprint = $c.Thumbprint
      $r.SelfSigned = ($c.Subject -eq $c.Issuer)
      try {
        $ch = New-Object System.Security.Cryptography.X509Certificates.X509Chain
        $ch.ChainPolicy.RevocationMode = 'NoCheck'
        [void]$ch.Build($c)
        $n = $ch.ChainElements.Count
        if ($n -gt 0) {
          $rc = $ch.ChainElements[$n-1].Certificate
          $r.Root = $rc.Subject; $r.RootThumb = $rc.Thumbprint
          $r.RootNotBefore = $rc.NotBefore.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
        }
        $r.Chain = (($ch.ChainStatus | ForEach-Object { [string]$_.Status }) -join ',')
      } catch {}
    }
  } catch { $r.Message = $_.Exception.Message }
  try {
    $vi = (Get-Item -LiteralPath $p -ErrorAction Stop).VersionInfo
    $r.Original = [string]$vi.OriginalFilename; $r.Company = [string]$vi.CompanyName
  } catch {}
  [pscustomobject]$r
}
ConvertTo-Json -InputObject @($out) -Compress -Depth 3
`

func hiddenCmd(ctx context.Context, name string, args ...string) *exec.Cmd {
	cmd := exec.CommandContext(ctx, name, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
	return cmd
}

func (winPlatform) CheckSignatures(paths []string) (map[string]SigInfo, error) {
	res := map[string]SigInfo{}
	for start := 0; start < len(paths); start += maxSigBatchFiles {
		end := start + maxSigBatchFiles
		if end > len(paths) {
			end = len(paths)
		}
		if err := checkBatch(paths[start:end], res); err != nil {
			return res, err
		}
	}
	return res, nil
}

func checkBatch(paths []string, res map[string]SigInfo) error {
	dir, err := os.MkdirTemp("", "hongkong-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(dir)
	script := filepath.Join(dir, "sig.ps1")
	list := filepath.Join(dir, "paths.txt")
	if err := os.WriteFile(script, append([]byte{0xEF, 0xBB, 0xBF}, []byte(sigScript)...), 0o600); err != nil {
		return err
	}
	if err := os.WriteFile(list, []byte(strings.Join(paths, "\r\n")), 0o600); err != nil {
		return err
	}
	ps := filepath.Join(systemRoot(), `System32\WindowsPowerShell\v1.0\powershell.exe`)
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
	defer cancel()
	out, err := hiddenCmd(ctx, ps, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script, list).Output()
	if err != nil {
		return err
	}
	out = []byte(strings.TrimPrefix(strings.TrimSpace(string(out)), "\ufeff"))
	if len(out) == 0 {
		return errors.New("Windows PowerShell returned no output (is powershell.exe available?)")
	}
	var rows []psSig
	if err := json.Unmarshal(out, &rows); err != nil {
		var one psSig
		if err2 := json.Unmarshal(out, &one); err2 != nil {
			return err
		}
		rows = []psSig{one}
	}
	for _, r := range rows {
		res[r.Path] = mapSignature(r)
	}
	return nil
}

func (winPlatform) Hostname() string { h, _ := os.Hostname(); return h }

func (winPlatform) Username() string {
	u := os.Getenv("USERNAME")
	if d := os.Getenv("USERDOMAIN"); d != "" {
		return d + `\` + u
	}
	return u
}

func (winPlatform) Elevated() bool { return isElevated() }

func isElevated() bool {
	r, _, _ := procIsUserAnAdmin.Call()
	return r != 0
}

func shellExecute(hwnd uintptr, verb, file, params string) error {
	v, _ := syscall.UTF16PtrFromString(verb)
	f, _ := syscall.UTF16PtrFromString(file)
	var p *uint16
	if params != "" {
		p, _ = syscall.UTF16PtrFromString(params)
	}
	r, _, _ := procShellExecuteW.Call(hwnd, uintptr(unsafe.Pointer(v)), uintptr(unsafe.Pointer(f)),
		uintptr(unsafe.Pointer(p)), 0, 1)
	if r <= 32 {
		return errors.New("could not open " + file)
	}
	return nil
}

func runSchtasks(args ...string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	out, err := hiddenCmd(ctx, filepath.Join(systemRoot(), `System32\schtasks.exe`), args...).CombinedOutput()
	return string(out), err
}

const wmiScript = `
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$out = @()
foreach ($c in @(Get-CimInstance -Namespace root/subscription -ClassName CommandLineEventConsumer)) {
  $out += [pscustomobject]@{ Name=[string]$c.Name; Kind='CommandLineEventConsumer'; Command=[string]$c.CommandLineTemplate; Script=[string]$c.ExecutablePath; ScriptFile=''; Engine='' }
}
foreach ($c in @(Get-CimInstance -Namespace root/subscription -ClassName ActiveScriptEventConsumer)) {
  $out += [pscustomobject]@{ Name=[string]$c.Name; Kind='ActiveScriptEventConsumer'; Command=''; Script=[string]$c.ScriptText; ScriptFile=[string]$c.ScriptFileName; Engine=[string]$c.ScriptingEngine }
}
ConvertTo-Json -InputObject @($out) -Compress -Depth 3
`

// WMIConsumers lists WMI event consumers that run commands or scripts
// (a classic fileless persistence method).
func (winPlatform) WMIConsumers() ([]WMIConsumer, error) {
	dir, err := os.MkdirTemp("", "hongkong-")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)
	script := filepath.Join(dir, "wmi.ps1")
	if err := os.WriteFile(script, append([]byte{0xEF, 0xBB, 0xBF}, []byte(wmiScript)...), 0o600); err != nil {
		return nil, err
	}
	ps := filepath.Join(systemRoot(), `System32\WindowsPowerShell\v1.0\powershell.exe`)
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	out, err := hiddenCmd(ctx, ps, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script).Output()
	if err != nil {
		return nil, err
	}
	out = []byte(strings.TrimPrefix(strings.TrimSpace(string(out)), "\ufeff"))
	if len(out) == 0 {
		return nil, errors.New("no output")
	}
	var rows []WMIConsumer
	if err := json.Unmarshal(out, &rows); err != nil {
		var one WMIConsumer
		if json.Unmarshal(out, &one) == nil && one.Kind != "" {
			rows = []WMIConsumer{one}
		}
	}
	return rows, nil
}
