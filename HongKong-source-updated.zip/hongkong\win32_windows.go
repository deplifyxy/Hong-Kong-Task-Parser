//go:build windows

package main

import (
	"strings"
	"syscall"
	"unicode/utf16"
	"unsafe"
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	comctl32 = syscall.NewLazyDLL("comctl32.dll")
	comdlg32 = syscall.NewLazyDLL("comdlg32.dll")
	uxtheme  = syscall.NewLazyDLL("uxtheme.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")

	pRegisterClassExW      = user32.NewProc("RegisterClassExW")
	pCreateWindowExW       = user32.NewProc("CreateWindowExW")
	pDefWindowProcW        = user32.NewProc("DefWindowProcW")
	pGetMessageW           = user32.NewProc("GetMessageW")
	pTranslateMessage      = user32.NewProc("TranslateMessage")
	pDispatchMessageW      = user32.NewProc("DispatchMessageW")
	pIsDialogMessageW      = user32.NewProc("IsDialogMessageW")
	pPostMessageW          = user32.NewProc("PostMessageW")
	pSendMessageW          = user32.NewProc("SendMessageW")
	pShowWindow            = user32.NewProc("ShowWindow")
	pUpdateWindow          = user32.NewProc("UpdateWindow")
	pMoveWindow            = user32.NewProc("MoveWindow")
	pGetClientRect         = user32.NewProc("GetClientRect")
	pGetWindowRect         = user32.NewProc("GetWindowRect")
	pLoadCursorW           = user32.NewProc("LoadCursorW")
	pLoadImageW            = user32.NewProc("LoadImageW")
	pSetWindowTextW        = user32.NewProc("SetWindowTextW")
	pGetWindowTextW        = user32.NewProc("GetWindowTextW")
	pGetWindowTextLengthW  = user32.NewProc("GetWindowTextLengthW")
	pMessageBoxW           = user32.NewProc("MessageBoxW")
	pTrackPopupMenu        = user32.NewProc("TrackPopupMenu")
	pCreatePopupMenu       = user32.NewProc("CreatePopupMenu")
	pAppendMenuW           = user32.NewProc("AppendMenuW")
	pDestroyMenu           = user32.NewProc("DestroyMenu")
	pGetCursorPos          = user32.NewProc("GetCursorPos")
	pEnableWindow          = user32.NewProc("EnableWindow")
	pInvalidateRect        = user32.NewProc("InvalidateRect")
	pBeginPaint            = user32.NewProc("BeginPaint")
	pEndPaint              = user32.NewProc("EndPaint")
	pFillRect              = user32.NewProc("FillRect")
	pDrawTextW             = user32.NewProc("DrawTextW")
	pDrawIconEx            = user32.NewProc("DrawIconEx")
	pPostQuitMessage       = user32.NewProc("PostQuitMessage")
	pSetFocus              = user32.NewProc("SetFocus")
	pGetDC                 = user32.NewProc("GetDC")
	pReleaseDC             = user32.NewProc("ReleaseDC")
	pGetSystemMetrics      = user32.NewProc("GetSystemMetrics")
	pOpenClipboard         = user32.NewProc("OpenClipboard")
	pEmptyClipboard        = user32.NewProc("EmptyClipboard")
	pSetClipboardData      = user32.NewProc("SetClipboardData")
	pCloseClipboard        = user32.NewProc("CloseClipboard")
	pCreateFontW           = gdi32.NewProc("CreateFontW")
	pCreateSolidBrush      = gdi32.NewProc("CreateSolidBrush")
	pSetBkMode             = gdi32.NewProc("SetBkMode")
	pSetBkColor            = gdi32.NewProc("SetBkColor")
	pSetTextColor          = gdi32.NewProc("SetTextColor")
	pSelectObject          = gdi32.NewProc("SelectObject")
	pGetDeviceCaps         = gdi32.NewProc("GetDeviceCaps")
	pGetStockObject        = gdi32.NewProc("GetStockObject")
	pGetTextExtentPoint32W = gdi32.NewProc("GetTextExtentPoint32W")
	pInitCommonControlsEx  = comctl32.NewProc("InitCommonControlsEx")
	pGetSaveFileNameW      = comdlg32.NewProc("GetSaveFileNameW")
	pSetWindowTheme        = uxtheme.NewProc("SetWindowTheme")
	pGetModuleHandleW      = kernel32.NewProc("GetModuleHandleW")
	pGlobalAlloc           = kernel32.NewProc("GlobalAlloc")
	pGlobalLock            = kernel32.NewProc("GlobalLock")
	pGlobalUnlock          = kernel32.NewProc("GlobalUnlock")
)

const (
	WM_CREATE         = 0x0001
	WM_DESTROY        = 0x0002
	WM_SIZE           = 0x0005
	WM_PAINT          = 0x000F
	WM_CLOSE          = 0x0010
	WM_GETMINMAXINFO  = 0x0024
	WM_SETFONT        = 0x0030
	WM_NOTIFY         = 0x004E
	WM_CONTEXTMENU    = 0x007B
	WM_KEYDOWN        = 0x0100
	WM_COMMAND        = 0x0111
	WM_CTLCOLOREDIT   = 0x0133
	WM_CTLCOLORSTATIC = 0x0138
	WM_USER           = 0x0400
	WM_APP            = 0x8000

	WS_OVERLAPPEDWINDOW = 0x00CF0000
	WS_VISIBLE          = 0x10000000
	WS_CHILD            = 0x40000000
	WS_TABSTOP          = 0x00010000
	WS_VSCROLL          = 0x00200000
	WS_CLIPCHILDREN     = 0x02000000
	WS_EX_CLIENTEDGE    = 0x00000200

	BS_PUSHBUTTON   = 0x0
	BS_CHECKBOX     = 0x2
	BS_AUTOCHECKBOX = 0x3
	BS_PUSHLIKE     = 0x1000
	BM_GETCHECK     = 0x00F0
	BM_SETCHECK     = 0x00F1
	BST_CHECKED     = 1
	BN_CLICKED      = 0

	ES_MULTILINE    = 0x0004
	ES_AUTOVSCROLL  = 0x0040
	ES_AUTOHSCROLL  = 0x0080
	ES_READONLY     = 0x0800
	EN_CHANGE       = 0x0300
	EM_SETLIMITTEXT = 0x00C5
	EM_SETCUEBANNER = 0x1501

	SS_LEFTNOWORDWRAP = 0x000C
	SS_ENDELLIPSIS    = 0x4000

	SW_HIDE = 0
	SW_SHOW = 5

	CS_VREDRAW = 0x1
	CS_HREDRAW = 0x2

	IDC_ARROW     = 32512
	IMAGE_ICON    = 1
	SM_CXICON     = 11
	SM_CXSMICON   = 49
	COLOR_BTNFACE = 15
	WHITE_BRUSH   = 0
	LOGPIXELSY    = 90
	TRANSPARENT   = 1
	DI_NORMAL     = 3

	DT_LEFT       = 0x0
	DT_VCENTER    = 0x4
	DT_SINGLELINE = 0x20
	DT_NOPREFIX   = 0x800
	DT_END_ELLIPS = 0x8000

	MB_OK          = 0x0
	MB_YESNO       = 0x4
	MB_ICONERROR   = 0x10
	MB_ICONWARNING = 0x30
	MB_ICONINFO    = 0x40
	MB_DEFBUTTON2  = 0x100
	IDYES          = 6

	MF_STRING       = 0x0
	MF_GRAYED       = 0x1
	MF_SEPARATOR    = 0x800
	TPM_RIGHTBUTTON = 0x2
	TPM_RETURNCMD   = 0x100

	VK_F5 = 0x74
	VK_F  = 0x46

	// list view
	LVM_FIRST                    = 0x1000
	LVM_SETITEMCOUNT             = LVM_FIRST + 47
	LVM_GETNEXTITEM              = LVM_FIRST + 12
	LVM_SETITEMSTATE             = LVM_FIRST + 43
	LVM_ENSUREVISIBLE            = LVM_FIRST + 19
	LVM_SETEXTENDEDLISTVIEWSTYLE = LVM_FIRST + 54
	LVM_INSERTCOLUMNW            = LVM_FIRST + 97
	LVM_SETCOLUMNW               = LVM_FIRST + 96
	LVS_REPORT                   = 0x0001
	LVS_SINGLESEL                = 0x0004
	LVS_SHOWSELALWAYS            = 0x0008
	LVS_OWNERDATA                = 0x1000
	LVS_EX_GRIDLINES             = 0x00000001
	LVS_EX_FULLROWSELECT         = 0x00000020
	LVS_EX_LABELTIP              = 0x00004000
	LVS_EX_DOUBLEBUFFER          = 0x00010000
	LVCF_FMT                     = 0x1
	LVCF_WIDTH                   = 0x2
	LVCF_TEXT                    = 0x4
	LVCF_SUBITEM                 = 0x8
	LVIF_TEXT                    = 0x1
	LVIF_STATE                   = 0x8
	LVIS_FOCUSED                 = 0x1
	LVIS_SELECTED                = 0x2
	LVNI_SELECTED                = 0x2

	// notifications (as uint32 two's complement)
	NM_DBLCLK        = 0xFFFFFFFD // -3
	NM_CUSTOMDRAW    = 0xFFFFFFF4 // -12
	LVN_ITEMCHANGED  = 0xFFFFFF9B // -101
	LVN_COLUMNCLICK  = 0xFFFFFF94 // -108
	LVN_GETDISPINFOW = 0xFFFFFF4F // -177
	TCN_SELCHANGE    = 0xFFFFFDD9 // -551

	CDDS_PREPAINT          = 0x1
	CDDS_ITEMPREPAINT      = 0x10001
	CDDS_SUBITEM           = 0x20000
	CDRF_DODEFAULT         = 0x0
	CDRF_NEWFONT           = 0x2
	CDRF_NOTIFYITEMDRAW    = 0x20
	CDRF_NOTIFYSUBITEMDRAW = 0x20

	// tab control
	TCM_FIRST       = 0x1300
	TCM_GETCURSEL   = TCM_FIRST + 11
	TCM_SETITEMW    = TCM_FIRST + 61
	TCM_INSERTITEMW = TCM_FIRST + 62
	TCIF_TEXT       = 0x1

	// progress / status
	PBS_MARQUEE    = 0x08
	PBM_SETMARQUEE = WM_USER + 10
	SBARS_SIZEGRIP = 0x100
	SB_SETTEXTW    = WM_USER + 11

	ICC_ALL = 0x0001 | 0x0004 | 0x0008 | 0x0020 | 0x4000

	GMEM_MOVEABLE  = 0x2
	CF_UNICODETEXT = 13

	OFN_OVERWRITEPROMPT = 0x2
	OFN_NOCHANGEDIR     = 0x8
	OFN_PATHMUSTEXIST   = 0x800
)

type RECT struct{ Left, Top, Right, Bottom int32 }
type POINT struct{ X, Y int32 }
type SIZE struct{ CX, CY int32 }

type WNDCLASSEXW struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}

type MSG struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      POINT
	Private uint32
}

type PAINTSTRUCT struct {
	Hdc         uintptr
	FErase      int32
	RcPaint     RECT
	FRestore    int32
	FIncUpdate  int32
	RgbReserved [32]byte
}

type MINMAXINFO struct {
	PtReserved, PtMaxSize, PtMaxPosition, PtMinTrackSize, PtMaxTrackSize POINT
}

type NMHDR struct {
	HwndFrom uintptr
	IdFrom   uintptr
	Code     uint32
}

type LVCOLUMNW struct {
	Mask       uint32
	Fmt        int32
	Cx         int32
	PszText    *uint16
	CchTextMax int32
	ISubItem   int32
	IImage     int32
	IOrder     int32
	CxMin      int32
	CxDefault  int32
	CxIdeal    int32
}

type LVITEMW struct {
	Mask       uint32
	IItem      int32
	ISubItem   int32
	State      uint32
	StateMask  uint32
	PszText    *uint16
	CchTextMax int32
	IImage     int32
	LParam     uintptr
	IIndent    int32
	IGroupId   int32
	CColumns   uint32
	PuColumns  uintptr
	PiColFmt   uintptr
	IGroup     int32
}

type NMLVDISPINFOW struct {
	Hdr  NMHDR
	Item LVITEMW
}

type NMLISTVIEW struct {
	Hdr       NMHDR
	IItem     int32
	ISubItem  int32
	UNewState uint32
	UOldState uint32
	UChanged  uint32
	PtAction  POINT
	LParam    uintptr
}

type NMCUSTOMDRAW struct {
	Hdr        NMHDR
	DrawStage  uint32
	Hdc        uintptr
	Rc         RECT
	ItemSpec   uintptr
	ItemState  uint32
	ItemlParam uintptr
}

type NMLVCUSTOMDRAW struct {
	Nmcd      NMCUSTOMDRAW
	ClrText   uint32
	ClrTextBk uint32
	ISubItem  int32
}

type TCITEMW struct {
	Mask        uint32
	DwState     uint32
	DwStateMask uint32
	PszText     *uint16
	CchTextMax  int32
	IImage      int32
	LParam      uintptr
}

type INITCOMMONCONTROLSEX struct{ DwSize, DwICC uint32 }

type OPENFILENAMEW struct {
	LStructSize       uint32
	HwndOwner         uintptr
	HInstance         uintptr
	LpstrFilter       *uint16
	LpstrCustomFilter *uint16
	NMaxCustFilter    uint32
	NFilterIndex      uint32
	LpstrFile         *uint16
	NMaxFile          uint32
	LpstrFileTitle    *uint16
	NMaxFileTitle     uint32
	LpstrInitialDir   *uint16
	LpstrTitle        *uint16
	Flags             uint32
	NFileOffset       uint16
	NFileExtension    uint16
	LpstrDefExt       *uint16
	LCustData         uintptr
	LpfnHook          uintptr
	LpTemplateName    *uint16
	PvReserved        uintptr
	DwReserved        uint32
	FlagsEx           uint32
}

// u16 converts to a NUL-terminated UTF-16 string (embedded NULs are dropped).
func u16(s string) *uint16 {
	p, _ := syscall.UTF16PtrFromString(strings.ReplaceAll(s, "\x00", ""))
	return p
}

// u16multi builds a double-NUL-terminated list (file dialog filters).
func u16multi(parts ...string) *uint16 {
	var u []uint16
	for _, p := range parts {
		u = append(u, utf16.Encode([]rune(p))...)
		u = append(u, 0)
	}
	u = append(u, 0)
	return &u[0]
}

// ptrFrom reinterprets an LPARAM as a typed pointer without tripping vet.
func ptrFrom[T any](l uintptr) *T { return *(**T)(unsafe.Pointer(&l)) }

func send(h uintptr, msg uint32, w, l uintptr) uintptr {
	r, _, _ := pSendMessageW.Call(h, uintptr(msg), w, l)
	return r
}

// sendp passes a pointer LPARAM; the conversion happens inside Call so the
// pointee stays alive and pinned for the duration of the call.
func sendp(h uintptr, msg uint32, w uintptr, l unsafe.Pointer) uintptr {
	r, _, _ := pSendMessageW.Call(h, uintptr(msg), w, uintptr(l))
	return r
}

func post(h uintptr, msg uint32, w, l uintptr) {
	pPostMessageW.Call(h, uintptr(msg), w, l)
}

func setText(h uintptr, s string) {
	pSetWindowTextW.Call(h, uintptr(unsafe.Pointer(u16(s))))
}

func getText(h uintptr) string {
	n, _, _ := pGetWindowTextLengthW.Call(h)
	buf := make([]uint16, n+1)
	pGetWindowTextW.Call(h, uintptr(unsafe.Pointer(&buf[0])), n+1)
	return syscall.UTF16ToString(buf)
}

func moveWindow(h uintptr, x, y, w, hgt int) {
	if w < 0 {
		w = 0
	}
	if hgt < 0 {
		hgt = 0
	}
	pMoveWindow.Call(h, uintptr(x), uintptr(y), uintptr(w), uintptr(hgt), 1)
}

func showWindow(h uintptr, show bool) {
	if show {
		pShowWindow.Call(h, SW_SHOW)
	} else {
		pShowWindow.Call(h, SW_HIDE)
	}
}

func enableWindow(h uintptr, on bool) {
	v := uintptr(0)
	if on {
		v = 1
	}
	pEnableWindow.Call(h, v)
}

func clientRect(h uintptr) RECT {
	var r RECT
	pGetClientRect.Call(h, uintptr(unsafe.Pointer(&r)))
	return r
}

func windowRect(h uintptr) RECT {
	var r RECT
	pGetWindowRect.Call(h, uintptr(unsafe.Pointer(&r)))
	return r
}

func messageBox(h uintptr, text, caption string, flags uint32) int {
	r, _, _ := pMessageBoxW.Call(h, uintptr(unsafe.Pointer(u16(text))), uintptr(unsafe.Pointer(u16(caption))), uintptr(flags))
	return int(r)
}

func rgb(r, g, b byte) uint32 { return uint32(r) | uint32(g)<<8 | uint32(b)<<16 }

func setClipboard(owner uintptr, text string) bool {
	if r, _, _ := pOpenClipboard.Call(owner); r == 0 {
		return false
	}
	defer pCloseClipboard.Call()
	pEmptyClipboard.Call()
	u := utf16.Encode([]rune(text))
	u = append(u, 0)
	h, _, _ := pGlobalAlloc.Call(GMEM_MOVEABLE, uintptr(len(u)*2))
	if h == 0 {
		return false
	}
	p, _, _ := pGlobalLock.Call(h)
	if p == 0 {
		return false
	}
	dst := unsafe.Slice(ptrFrom[uint16](p), len(u))
	copy(dst, u)
	pGlobalUnlock.Call(h)
	r, _, _ := pSetClipboardData.Call(CF_UNICODETEXT, h)
	return r != 0
}

// copyToBuf writes text into a control-provided UTF-16 buffer of n chars.
func copyToBuf(p *uint16, n int, text string) {
	if p == nil || n <= 0 {
		return
	}
	buf := unsafe.Slice(p, n)
	u := utf16.Encode([]rune(text))
	if len(u) > n-1 {
		u = u[:n-1]
	}
	copy(buf, u)
	buf[len(u)] = 0
}

func systemDPI() int {
	hdc, _, _ := pGetDC.Call(0)
	dpi, _, _ := pGetDeviceCaps.Call(hdc, LOGPIXELSY)
	pReleaseDC.Call(0, hdc)
	if dpi == 0 {
		return 96
	}
	return int(dpi)
}

func createFont(height int, weight int, face string) uintptr {
	h, _, _ := pCreateFontW.Call(uintptr(int32(-height)), 0, 0, 0, uintptr(weight), 0, 0, 0,
		1 /*DEFAULT_CHARSET*/, 0, 0, 5 /*CLEARTYPE_QUALITY*/, 0, uintptr(unsafe.Pointer(u16(face))))
	return h
}

func saveDialog(owner uintptr, title, defName, defExt string, filter ...string) (string, bool) {
	buf := make([]uint16, 1024)
	copy(buf, utf16.Encode([]rune(defName)))
	ofn := OPENFILENAMEW{
		HwndOwner:    owner,
		LpstrFilter:  u16multi(filter...),
		NFilterIndex: 1,
		LpstrFile:    &buf[0],
		NMaxFile:     uint32(len(buf)),
		LpstrTitle:   u16(title),
		LpstrDefExt:  u16(defExt),
		Flags:        OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR | OFN_PATHMUSTEXIST,
	}
	ofn.LStructSize = uint32(unsafe.Sizeof(ofn))
	r, _, _ := pGetSaveFileNameW.Call(uintptr(unsafe.Pointer(&ofn)))
	if r == 0 {
		return "", false
	}
	return syscall.UTF16ToString(buf), true
}
