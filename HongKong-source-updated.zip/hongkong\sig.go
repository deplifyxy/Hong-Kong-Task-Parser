package main

import (
	"bytes"
	"strings"
	"time"
)

// psSig is one row of the PowerShell Authenticode batch output.
type psSig struct {
	Path, Status, Message, Signer, Issuer, Root, Thumbprint, Type string
	Chain, Original, Company, RootThumb, RootNotBefore            string
	SelfSigned, Timestamped                                       bool
}

// mapSignature turns Get-AuthenticodeSignature + X509Chain output into a
// first-pass verdict. classify() then refines it with the native check and
// the machine's real root stores.
func mapSignature(r psSig) SigInfo {
	si := SigInfo{RawStatus: r.Status, Signer: r.Signer, Issuer: r.Issuer, ChainRoot: r.Root,
		ChainStatus: r.Chain, Thumbprint: r.Thumbprint, Type: r.Type, SelfSigned: r.SelfSigned,
		Timestamped: r.Timestamped, OriginalName: r.Original, Company: r.Company,
		RootThumb: strings.ToUpper(r.RootThumb)}
	if t, err := time.Parse(time.RFC3339, r.RootNotBefore); err == nil {
		si.RootNotBefore = t
	}
	chain := strings.ToLower(r.Chain)
	onlyTime := chain != "" && strings.Trim(strings.ReplaceAll(chain, "nottimevalid", ""), ", ") == ""
	switch r.Status {
	case "Valid":
		if r.SelfSigned {
			si.Status = SigSelfTrusted
		} else {
			si.Status = SigValid
		}
	case "NotSigned", "NotSupportedFileFormat":
		si.Status = SigUnsigned
	case "HashMismatch":
		si.Status = SigHashMismatch
	case "Error", "":
		si.Status = SigUnknown
	default: // UnknownError, NotTrusted, Incompatible
		switch {
		case r.Signer == "":
			si.Status = SigUnverified
		case r.SelfSigned:
			si.Status = SigSelfSigned
		case strings.Contains(chain, "notsignaturevalid"):
			si.Status = SigBadCert
		case strings.Contains(chain, "revoked") || strings.Contains(chain, "explicitdistrust"):
			si.Status = SigRevoked
		case strings.Contains(chain, "untrustedroot") || strings.Contains(chain, "partialchain"):
			si.Status = SigUntrustedRoot
		case onlyTime:
			si.Status = SigExpired // old but genuine signature without a timestamp
		case chain == "":
			si.Status = SigValid // Windows hiccup (e.g. revocation offline) with a clean chain
		default:
			si.Status = SigUnverified
		}
	}
	return si
}

// classify merges Windows' verdict with the native embedded-signature check
// and the root stores. This is where forged and self-made signatures that
// Windows was tricked into calling "Valid" get caught.
func classify(si SigInfo, es EmbeddedSig, db *TrustDB, now time.Time) SigInfo {
	winKnown := si.Status != SigUnknown && si.Status != SigSkipped && si.Status != ""
	if es.Present && es.ParseErr == "" && es.Signer != nil {
		si.Embedded = true
		if si.Signer == "" {
			si.Signer, si.Issuer = es.Signer.Subject.String(), es.Signer.Issuer.String()
		}
		switch {
		case !es.DigestOK:
			si.Status, si.Note = SigHashMismatch, "file contents do not match the signed hash"
			return finishSig(si, db)
		case !es.SignatureOK:
			si.Status, si.Note = SigBadCert, "signer's signature does not verify"
			return finishSig(si, db)
		case es.ChainBroken != "":
			si.Status, si.Note = SigBadCert, es.ChainBroken
			return finishSig(si, db)
		}
	}

	leaf := si.Signer
	type root struct {
		thumb, subject string
		nb             time.Time
	}
	var roots []root
	if si.RootThumb != "" {
		roots = append(roots, root{si.RootThumb, si.ChainRoot, si.RootNotBefore})
	}
	if es.Top != nil && es.TopSelf && es.TopThumb != si.RootThumb {
		roots = append(roots, root{es.TopThumb, es.Top.Subject.String(), es.Top.NotBefore})
		if si.ChainRoot == "" {
			si.ChainRoot, si.RootThumb, si.RootNotBefore = es.Top.Subject.String(), es.TopThumb, es.Top.NotBefore
		}
	}
	for _, r := range roots {
		if forged, _ := db.rootVerdict(r.thumb, r.subject, leaf, r.nb, now); forged {
			si.Status = SigForged
			si.ChainRoot, si.RootThumb, si.RootNotBefore = r.subject, r.thumb, r.nb
			si.Note = "chain claims Microsoft but ends in a fake root"
			return finishSig(si, db)
		}
	}

	leafSelf := si.SelfSigned || (es.Signer != nil && bytes.Equal(es.Signer.RawIssuer, es.Signer.RawSubject))
	if leafSelf && si.Signer != "" {
		si.SelfSigned = true
		if si.Status == SigValid || si.Status == SigSelfTrusted {
			si.Status = SigSelfTrusted
		} else {
			si.Status = SigSelfSigned
		}
		return finishSig(si, db)
	}

	if si.RootThumb != "" {
		if hive := db.UserRoots[si.RootThumb]; hive != "" {
			si.UserRoot = hive
		}
	}
	switch {
	case si.Status == SigValid && si.RootThumb != "":
		if _, local := db.rootVerdict(si.RootThumb, si.ChainRoot, leaf, si.RootNotBefore, now); local || si.UserRoot != "" {
			si.Status = SigLocalRoot
			si.Note = "root certificate is not publicly trusted"
			if si.UserRoot != "" {
				si.Note = "root certificate was added to the user store " + si.UserRoot
			}
		}
	case !winKnown && si.Embedded && es.TopSelf:
		// Windows gave no verdict; judge the embedded chain ourselves.
		if _, local := db.rootVerdict(es.TopThumb, es.Top.Subject.String(), leaf, es.Top.NotBefore, now); local {
			si.Status = SigUntrustedRoot
		} else if db.CTLLoaded {
			si.Status, si.Note = SigValid, "verified offline against Microsoft's root program"
		}
	case !winKnown && si.Embedded && db.CTLLoaded && !es.TopSelf:
		si.Note = "embedded signature intact; chain not verified (Windows verification unavailable)"
	}
	return finishSig(si, db)
}

func finishSig(si SigInfo, db *TrustDB) SigInfo {
	if si.RootThumb != "" && db.Disallowed[si.RootThumb] {
		si.Status, si.Note = SigRevoked, "root certificate is in the Disallowed store"
	}
	si.IsMicrosoft = si.Status == SigValid && claimsMicrosoft(si.Signer) &&
		(genuineMicrosoftRoots[si.RootThumb] != "" || (db.CTL[si.RootThumb] && claimsMicrosoft(si.ChainRoot)))
	return si
}

// sigSeverity orders statuses for picking the "worst" target to display.
func sigSeverity(status string) int {
	switch status {
	case SigValid:
		return 0
	case SigSkipped, SigUnknown, SigExpired:
		return 1
	case SigUnsigned, SigNotOnDisk, SigUnverified:
		return 2
	}
	return 3
}
