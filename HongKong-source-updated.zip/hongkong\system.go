package main

import (
	"fmt"
	"sort"
	"strings"
)

// Extra persistence locations, services/drivers and Windows security posture.

type WMIConsumer struct {
	Name, Kind, Command, Script, ScriptFile, Engine string
}

const keyServices = `SYSTEM\CurrentControlSet\Services`

// Drivers with known flaws that kernel cheats and BYOVD attacks load to get
// kernel read/write. Some ship with legitimate tools, hence "review".
var vulnerableDrivers = map[string]string{
	"iqvw64e.sys": "Intel NIC diagnostics (kdmapper)", "iqvw32.sys": "Intel NIC diagnostics",
	"gdrv.sys": "Gigabyte", "rtcore64.sys": "MSI Afterburner RTCore", "rtcore32.sys": "MSI Afterburner RTCore",
	"dbutil_2_3.sys": "Dell BIOS utility", "asio.sys": "ASUS", "asio2.sys": "ASUS", "asio3.sys": "ASUS", "asio64.sys": "ASUS",
	"ene.sys": "ENE RGB", "mhyprot.sys": "miHoYo anti-cheat", "mhyprot2.sys": "miHoYo anti-cheat", "mhyprot3.sys": "miHoYo anti-cheat",
	"capcom.sys": "Capcom", "winring0x64.sys": "WinRing0 (OpenLibSys)", "winring0.sys": "WinRing0 (OpenLibSys)",
	"atillk64.sys": "ATI", "amifldrv64.sys": "AMI flash", "bs_def64.sys": "Biostar", "glckio2.sys": "ASRock/GLCK",
	"msio64.sys": "MSI", "msio32.sys": "MSI", "ntiolib_x64.sys": "MSI NTIOLib", "ntiolib.sys": "MSI NTIOLib",
	"zam64.sys": "Zemana", "zamguard64.sys": "Zemana", "kprocesshacker.sys": "Process Hacker (process killer)",
	"physmem.sys": "physical memory access", "phymemx64.sys": "physical memory access", "echo_driver.sys": "Echo anti-cheat",
	"truesight.sys": "RogueKiller (process killer)", "aswarpot.sys": "Avast anti-rootkit (process killer)",
	"viragt64.sys": "TG Soft", "wnbios64.sys": "WinIO BIOS", "iobitunlocker.sys": "IObit Unlocker",
	"pdfwkrnl.sys": "AMD PDFW", "kevp64.sys": "PowerTool", "procexp152.sys": "Process Explorer (abused to kill AV)",
	"asrdrv10.sys": "ASRock", "asrdrv101.sys": "ASRock", "asrdrv102.sys": "ASRock", "asrdrv103.sys": "ASRock", "asrdrv104.sys": "ASRock",
	"elbycdio.sys": "Elaborate Bytes", "speedfan.sys": "SpeedFan", "lha.sys": "LG", "nvflash.sys": "NVIDIA flash",
}

// normalizeImagePath turns a service ImagePath into a Win32 path.
func normalizeImagePath(p, systemRoot string) string {
	p = strings.TrimSpace(p)
	low := strings.ToLower(p)
	switch {
	case strings.HasPrefix(low, `\systemroot\`):
		p = winJoin(systemRoot, p[len(`\systemroot\`):])
	case strings.HasPrefix(low, `%systemroot%\`):
		p = winJoin(systemRoot, p[len(`%systemroot%\`):])
	case strings.HasPrefix(low, `system32\`), strings.HasPrefix(low, `syswow64\`):
		p = winJoin(systemRoot, p)
	case strings.HasPrefix(low, `\??\`):
		p = p[4:]
	}
	return p
}

func (s *scanner) collectServices() []*Item {
	var items []*Item
	sr := s.res.systemRoot()
	names := s.subkeys("HKLM", keyServices)
	sort.Strings(names)
	for _, name := range names {
		vals := s.values("HKLM", keyServices+`\`+name)
		img := strings.TrimSpace(vals["imagepath"].String())
		start, okStart := vals["start"]
		typ := vals["type"].Num
		if img == "" || !okStart || start.Num > 2 {
			continue // only boot / system / automatic start
		}
		driver := typ&0x3 != 0 // kernel or file-system driver
		it := s.newItem("autostart")
		it.Name, it.Path = name, `HKLM\`+keyServices+`\`+name
		it.Description = vals["displayname"].String()
		startName := map[uint64]string{0: "Boot", 1: "System", 2: "Automatic"}[start.Num]
		if driver {
			it.Location = "Driver"
			it.Flags |= FlagDriver
		} else {
			it.Location = "Service"
		}
		it.Triggers = []string{startName}
		obj := strings.ToLower(vals["objectname"].String())
		if driver || obj == "" || obj == "localsystem" {
			it.Flags |= FlagHighPriv
		}
		it.RunAs = vals["objectname"].String()
		norm := normalizeImagePath(img, sr)
		if driver {
			it.Command = norm
			path := s.res.Resolve(norm, "")
			it.Targets = append(it.Targets, Target{Role: "action", Raw: img, Path: path})
			if desc, bad := vulnerableDrivers[strings.ToLower(winBase(path))]; bad {
				it.add(SevMedium, FlagDriver, "Known vulnerable driver ("+desc+"): abused by kernel cheats and BYOVD attacks to get kernel access")
			}
			for _, t := range pathTricks(path) {
				it.add(t.sev, FlagPathTrick, t.text)
			}
		} else {
			s.analyzeCommandLine(it, norm)
			it.Command = img
			// svchost-hosted services: the real code is the ServiceDll.
			if strings.Contains(strings.ToLower(img), `svchost.exe`) {
				dll := s.values("HKLM", keyServices+`\`+name+`\Parameters`)["servicedll"].String()
				if dll == "" {
					dll = vals["servicedll"].String()
				}
				if dll != "" {
					dp := s.res.Resolve(expandWinEnv(dll, s.p.Getenv), "")
					it.Targets = append(it.Targets, Target{Role: "service-dll", Raw: dll, Path: dp})
					it.Command = img + "  ->  " + dll
				}
				it.drop(FlagExecHost)
			}
		}
		items = append(items, it)
	}
	return items
}

// extraAutostart covers the less-known places code gets loaded from.
func (s *scanner) extraAutostart() []*Item {
	var items []*Item
	sr := s.res.systemRoot()
	sys32 := winJoin(sr, "System32")
	newEntry := func(loc, path, name string) *Item {
		it := s.newItem("autostart")
		it.Location, it.Path, it.Name = loc, path, name
		return it
	}
	dllEntry := func(loc, path, name, dll string, base Sev, why string) {
		dll = strings.TrimSpace(dll)
		if dll == "" {
			return
		}
		it := newEntry(loc, path, name)
		file := dll
		if winExt(file) == "" {
			file += ".dll"
		}
		if !strings.Contains(file, `\`) {
			file = winJoin(sys32, file)
		}
		it.Command = dll
		it.Targets = append(it.Targets, Target{Role: "action", Raw: dll, Path: s.res.Resolve(expandWinEnv(file, s.p.Getenv), "")})
		it.Flags |= FlagNonDefault
		it.add(base, 0, why)
		items = append(items, it)
	}

	// BootExecute: runs before Windows starts (default: autocheck autochk *)
	if v, ok := s.values("HKLM", `SYSTEM\CurrentControlSet\Control\Session Manager`)["bootexecute"]; ok {
		for _, e := range v.Strs {
			e = strings.TrimSpace(e)
			if e == "" || strings.EqualFold(strings.Join(strings.Fields(e), " "), "autocheck autochk *") {
				continue
			}
			it := newEntry("BootExecute", `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager`, "BootExecute")
			exe, args := s.res.SplitCommandLine(e)
			if winExt(exe) == "" {
				exe += ".exe"
			}
			it.Command = e
			it.Targets = append(it.Targets, Target{Role: "action", Raw: exe, Path: s.res.Resolve(exe, "")})
			_ = args
			it.add(SevMedium, FlagNonDefault, "Extra BootExecute program runs before Windows starts")
			items = append(items, it)
		}
	}
	// AppCertDlls: loaded into every process that calls CreateProcess
	for _, v := range s.values("HKLM", `SYSTEM\CurrentControlSet\Control\Session Manager\AppCertDlls`) {
		dllEntry("AppCertDlls", `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\AppCertDlls`, v.Name, v.String(), SevMedium,
			"AppCertDlls entry: loaded into every process that starts programs")
	}
	// LSA packages: loaded into lsass.exe (credential access / persistence)
	lsaDefaults := map[string]bool{"msv1_0": true, "scecli": true, "rassfm": true, "kerberos": true, "schannel": true,
		"wdigest": true, "tspkg": true, "pku2u": true, "cloudap": true, "negoexts": true, "livessp": true, "": true, `""`: true}
	for _, key := range []string{`SYSTEM\CurrentControlSet\Control\Lsa`, `SYSTEM\CurrentControlSet\Control\Lsa\OSConfig`} {
		vals := s.values("HKLM", key)
		for _, vn := range []string{"authentication packages", "notification packages", "security packages"} {
			v, ok := vals[vn]
			if !ok {
				continue
			}
			list := v.Strs
			if len(list) == 0 && v.Str != "" {
				list = strings.Fields(v.Str)
			}
			for _, pkg := range list {
				if lsaDefaults[strings.ToLower(strings.TrimSpace(pkg))] {
					continue
				}
				dllEntry("LSA", `HKLM\`+key, v.Name, pkg, SevMedium, "Non-default LSA package loaded into lsass.exe (password filter / credential persistence)")
			}
		}
	}
	// Print monitors and netsh helpers: DLLs loaded by system services
	for _, m := range s.subkeys("HKLM", `SYSTEM\CurrentControlSet\Control\Print\Monitors`) {
		d := s.values("HKLM", `SYSTEM\CurrentControlSet\Control\Print\Monitors\`+m)["driver"].String()
		dllEntry("Print monitor", `HKLM\SYSTEM\CurrentControlSet\Control\Print\Monitors\`+m, m, d, SevInfo, "Loaded by the print spooler as SYSTEM")
	}
	for _, v := range s.values("HKLM", `SOFTWARE\Microsoft\NetSh`) {
		dllEntry("Netsh helper", `HKLM\SOFTWARE\Microsoft\NetSh`, v.Name, v.String(), SevInfo, "Loaded whenever netsh.exe runs")
	}
	// cmd.exe AutoRun, legacy Load/Run, screensaver, Active Setup
	for _, root := range append([]string{"HKLM"}, s.userHives...) {
		if v, ok := s.values(root, `Software\Microsoft\Command Processor`)["autorun"]; ok && strings.TrimSpace(v.String()) != "" {
			it := newEntry("cmd AutoRun", root+`\Software\Microsoft\Command Processor`, "AutoRun")
			s.analyzeCommandLine(it, v.String())
			it.add(SevMedium, FlagNonDefault, "Runs every time cmd.exe starts")
			items = append(items, it)
		}
	}
	for _, h := range s.userHives {
		vals := s.values(h, `Software\Microsoft\Windows NT\CurrentVersion\Windows`)
		for _, n := range []string{"load", "run"} {
			if v, ok := vals[n]; ok && strings.TrimSpace(v.String()) != "" {
				it := newEntry("Legacy "+v.Name, h+`\Software\Microsoft\Windows NT\CurrentVersion\Windows`, v.Name)
				s.analyzeCommandLine(it, v.String())
				it.add(SevMedium, FlagNonDefault, "Legacy "+v.Name+" value: runs at logon and is rarely used by real software")
				items = append(items, it)
			}
		}
		if v, ok := s.values(h, `Control Panel\Desktop`)["scrnsave.exe"]; ok && strings.TrimSpace(v.String()) != "" {
			it := newEntry("Screensaver", h+`\Control Panel\Desktop`, "SCRNSAVE.EXE")
			s.analyzeCommandLine(it, `"`+expandWinEnv(v.String(), s.p.Getenv)+`"`)
			items = append(items, it)
		}
	}
	for _, id := range s.subkeys("HKLM", `SOFTWARE\Microsoft\Active Setup\Installed Components`) {
		k := `SOFTWARE\Microsoft\Active Setup\Installed Components\` + id
		vals := s.values("HKLM", k)
		stub := strings.TrimSpace(vals["stubpath"].String())
		if stub == "" {
			continue
		}
		it := newEntry("Active Setup", `HKLM\`+k, vals[""].String())
		if it.Name == "" {
			it.Name = id
		}
		s.analyzeCommandLine(it, expandWinEnv(stub, s.p.Getenv))
		it.drop(FlagExecHost)
		items = append(items, it)
	}
	// Startup folder redirection
	defaults := map[string]string{
		"startup":        `%userprofile%\appdata\roaming\microsoft\windows\start menu\programs\startup`,
		"common startup": `%programdata%\microsoft\windows\start menu\programs\startup`,
	}
	check := func(root, sub, name string) {
		v, ok := s.values(root, sub)[name]
		if !ok {
			return
		}
		cur := strings.ToLower(strings.TrimRight(v.String(), `\`))
		if cur == defaults[name] || cur == strings.ToLower(expandWinEnv(defaults[name], s.p.Getenv)) || strings.HasSuffix(cur, `\start menu\programs\startup`) {
			return
		}
		it := newEntry("Startup redirect", root+`\`+sub, v.Name)
		it.Command = v.String()
		it.add(SevHigh, FlagNonDefault, "Startup folder redirected to "+v.String()+": everything there runs at logon")
		items = append(items, it)
		dir := expandWinEnv(v.String(), s.p.Getenv)
		if names, err := s.p.ListDir(dir); err == nil {
			for _, n := range names {
				f := s.newItem("autostart")
				f.Location, f.Path, f.Name = "Startup redirect", dir, n
				f.Command = winJoin(dir, n)
				s.analyzeExec(f, winJoin(dir, n), "", "")
				f.add(SevHigh, FlagNonDefault, "Runs at logon from a redirected Startup folder")
				items = append(items, f)
			}
		}
	}
	for _, h := range s.userHives {
		check(h, `Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders`, "startup")
	}
	check("HKLM", `SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders`, "common startup")

	// Accessibility binaries: replacing them gives a SYSTEM shell at the logon screen.
	for _, n := range []string{"sethc.exe", "utilman.exe", "osk.exe", "narrator.exe", "magnify.exe", "displayswitch.exe", "atbroker.exe"} {
		p := winJoin(sys32, n)
		if st := s.p.Stat(p); !st.Exists {
			continue
		}
		it := newEntry("Accessibility", sys32, n)
		it.Command = p
		it.Targets = append(it.Targets, Target{Role: "action", Raw: p, Path: p})
		it.Flags |= FlagHighPriv
		items = append(items, it)
	}
	return items
}

// accessibilityCheck runs after signatures are known.
func accessibilityCheck(it *Item) {
	if it.Location != "Accessibility" || len(it.Targets) == 0 {
		return
	}
	t := it.Targets[0]
	orig := normOriginalName(t.Sig.OriginalName)
	switch {
	case orig != "" && orig != strings.ToLower(it.Name):
		it.add(SevHigh, FlagMasquerade, "Accessibility backdoor: "+it.Name+" was replaced with "+orig+" (gives a SYSTEM shell at the logon screen)")
	case knownBad(t.Sig):
		it.add(SevHigh, FlagMasquerade, "Accessibility binary "+it.Name+" is not a genuine Microsoft file (logon-screen backdoor)")
	}
}

func (s *scanner) wmiItems() []*Item {
	cons, err := s.p.WMIConsumers()
	if err != nil {
		return nil
	}
	var items []*Item
	for _, c := range cons {
		it := s.newItem("autostart")
		it.Location, it.Name, it.Path = "WMI", c.Name, `root\subscription\`+c.Kind
		it.Flags |= FlagHighPriv
		switch c.Kind {
		case "ActiveScriptEventConsumer":
			it.Command = c.Engine + ": " + firstNonEmpty(c.ScriptFile, trunc(c.Script, 300))
			it.add(SevHigh, FlagNonDefault, "WMI event subscription runs a script as SYSTEM (fileless persistence)")
			for _, h := range staticAnalysis(c.Script) {
				if h.strong {
					it.add(SevHigh, FlagStaticAnalysis, "Script: "+h.reason)
				}
			}
			if c.ScriptFile != "" {
				it.Targets = append(it.Targets, Target{Role: "argument", Raw: c.ScriptFile, Path: c.ScriptFile})
			}
		default:
			line := firstNonEmpty(c.Command, c.Script)
			s.analyzeCommandLine(it, line)
			it.add(SevMedium, FlagNonDefault, "WMI event subscription runs a program as SYSTEM")
		}
		items = append(items, it)
	}
	return items
}

func firstNonEmpty(v ...string) string {
	for _, s := range v {
		if strings.TrimSpace(s) != "" {
			return s
		}
	}
	return ""
}

func trunc(s string, n int) string {
	r := []rune(strings.Join(strings.Fields(s), " "))
	if len(r) <= n {
		return string(r)
	}
	return string(r[:n-1]) + "…"
}

// ---------------------------------------------------------------------------
// System tab: Windows settings that weaken protection (test signing,
// Defender off/exclusions, code-integrity protections).

func (s *scanner) collectSystem() []*Item {
	var items []*Item
	add := func(name, value, area string, sev Sev, finding string, flag uint64) {
		it := s.newItem("system")
		it.Name, it.Command, it.Location, it.Path = name, value, area, area
		it.SignatureStatus = "-"
		if finding != "" {
			it.add(sev, flag, finding)
		}
		items = append(items, it)
	}
	opts := strings.ToUpper(s.values("HKLM", `SYSTEM\CurrentControlSet\Control`)["systemstartoptions"].String())
	switch {
	case strings.Contains(opts, "TESTSIGNING"):
		add("Driver test signing", "ON", "Boot", SevHigh, "Test signing is ON: Windows loads drivers signed with self-made certificates (bcdedit /set testsigning off)", FlagSystemWeak|FlagSelfSigned)
	default:
		add("Driver test signing", "off", "Boot", SevInfo, "", 0)
	}
	if strings.Contains(opts, "DISABLE_INTEGRITY_CHECKS") || strings.Contains(opts, "NOINTEGRITYCHECKS") {
		add("Integrity checks", "DISABLED", "Boot", SevHigh, "Driver signature enforcement is disabled at boot", FlagSystemWeak)
	}
	if strings.Contains(opts, " DEBUG") || strings.HasPrefix(strings.TrimSpace(opts), "DEBUG") {
		add("Kernel debugging", "ON", "Boot", SevMedium, "Kernel debugging is enabled (used to bypass PatchGuard and anti-cheat)", FlagSystemWeak)
	}
	ci := s.values("HKLM", `SYSTEM\CurrentControlSet\Control\CI\Config`)
	if v, ok := ci["vulnerabledriverblocklistenable"]; ok && v.Num == 0 {
		add("Vulnerable driver blocklist", "disabled", "Code integrity", SevMedium, "Microsoft's vulnerable driver blocklist is turned off (lets BYOVD drivers load)", FlagSystemWeak|FlagDriver)
	} else {
		add("Vulnerable driver blocklist", "on", "Code integrity", SevInfo, "", 0)
	}
	hv := s.values("HKLM", `SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity`)
	if v, ok := hv["enabled"]; ok && v.Num == 1 {
		add("Memory integrity (HVCI)", "on", "Code integrity", SevInfo, "", 0)
	} else {
		add("Memory integrity (HVCI)", "off", "Code integrity", SevInfo, "Memory integrity is off (not a problem by itself, but unsigned or vulnerable drivers load more easily)", FlagSystemWeak)
	}

	// Defender: policy switches that disable it
	pol := `SOFTWARE\Policies\Microsoft\Windows Defender`
	if v, ok := s.values("HKLM", pol)["disableantispyware"]; ok && v.Num == 1 {
		add("Defender", "disabled by policy", "Defender", SevHigh, "Microsoft Defender is turned off by policy (DisableAntiSpyware)", FlagSystemWeak)
	}
	for _, n := range []string{"disablerealtimemonitoring", "disablebehaviormonitoring", "disableioavprotection", "disablescriptscanning"} {
		if v, ok := s.values("HKLM", pol+`\Real-Time Protection`)[n]; ok && v.Num == 1 {
			add("Defender "+v.Name, "1", "Defender", SevHigh, "Defender protection switched off by policy: "+v.Name, FlagSystemWeak)
		}
	}
	// Defender exclusions (policy keys are readable; the local ones may be SYSTEM-only)
	for _, base := range []string{pol + `\Exclusions`, `SOFTWARE\Microsoft\Windows Defender\Exclusions`} {
		for _, kind := range []string{"Paths", "Processes", "Extensions"} {
			for _, v := range s.values("HKLM", base+`\`+kind) {
				ex := v.Name
				if ex == "" {
					continue
				}
				sev, why := SevMedium, "Defender does not scan "+strings.ToLower(kind)+": "+ex
				l := strings.ToLower(strings.TrimRight(ex, `\`))
				switch kind {
				case "Paths":
					if len(l) <= 2 || isUserWritable(l+`\`) || strings.HasSuffix(l, `\users`) || strings.Contains(l, `\windows\temp`) || l == strings.ToLower(s.res.systemRoot()) {
						sev, why = SevHigh, "Defender exclusion covers a whole drive or a user-writable folder: "+ex
					}
				case "Extensions":
					if map[string]bool{"exe": true, ".exe": true, "dll": true, ".dll": true, "sys": true, ".sys": true, "ps1": true, ".ps1": true, "bat": true, ".bat": true, "scr": true, ".scr": true}[l] {
						sev, why = SevHigh, "Defender exclusion skips every "+ex+" file"
					}
				}
				add("Defender exclusion ("+strings.ToLower(kind)+")", ex, "Defender", sev, why, FlagSystemWeak)
			}
		}
	}
	// Hosts file redirections of security / update domains
	hosts := winJoin(s.res.systemRoot(), `System32\drivers\etc\hosts`)
	if b, err := s.p.ReadFile(hosts, 1<<20); err == nil {
		blocked := 0
		var sample []string
		for _, line := range strings.Split(string(b), "\n") {
			line = strings.TrimSpace(line)
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			l := strings.ToLower(line)
			for _, d := range []string{"microsoft.com", "windowsupdate", "update.microsoft", "virustotal", "defender", "smartscreen", "malwarebytes",
				"kaspersky", "eset.com", "avast", "bitdefender", "battleye", "easyanticheat", "vanguard", "faceit", "riotgames"} {
				if strings.Contains(l, d) {
					blocked++
					if len(sample) < 3 {
						sample = append(sample, line)
					}
					break
				}
			}
		}
		if blocked > 0 {
			add("Hosts file", fmt.Sprintf("%d redirects", blocked), "Network", SevHigh,
				"Hosts file redirects security / update / anti-cheat domains: "+strings.Join(sample, "; "), FlagSystemWeak)
		}
	}
	return items
}
