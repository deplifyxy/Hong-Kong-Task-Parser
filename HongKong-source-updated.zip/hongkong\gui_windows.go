//go:build windows

package main

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"runtime/debug"
	"sort"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

func init() { runtime.LockOSThread() } // all UI work stays on the main OS thread

// Palette: Hong Kong at night. Warm near-black, flag red, signage gold, jade.
var (
	cBg0    = hexc(0x0E0A0B) // window
	cBg1    = hexc(0x150F11) // panels
	cBg2    = hexc(0x1D1517) // inputs / hover
	cBg3    = hexc(0x281C1F)
	cLine   = hexc(0x2B1F22)
	cLineHi = hexc(0x45312F)
	cSelRow = hexc(0x2A1214)
	cText   = hexc(0xF4ECE4) // paper white
	cText2  = hexc(0xBBAEA6)
	cDim    = hexc(0x7D6E68)
	cNeon   = hexc(0xDE2910) // Hong Kong flag red
	cNeonHi = hexc(0xF4452A)
	cNeonDk = hexc(0x5C130B)
	cGold   = hexc(0xF2B33D) // signage gold
	cSus    = hexc(0xEE3B24)
	cRev    = hexc(0xF2B33D)
	cClean  = hexc(0x3CC28E) // jade
	cInfo   = hexc(0x5AA9E6) // MTR blue
)

const (
	idScan = 100 + iota
	idExport
	idSearch
	idShowClean
	idList
	idDetail
	idTabBase    = 150
	idFilterBase = 200

	idmOpenLoc = 400 + iota
	idmCopyPath
	idmCopyHash
	idmVirusTotal
	idmCopyDetails
	idmRun
	idmEnable
	idmDisable
	idmExportXML
	idmDelete
	idmExportCSV
	idmExportJSON
	idmCopyThumb
	idmCopyRemove
	idmCertMgr
	idmTrust
	idmUntrust

	wmScanProgress = WM_APP + 1
	wmScanDone     = WM_APP + 2
	timerAnim      = 1
	timerCaret     = 2
)

const (
	scTasks = 1 << iota
	scAuto
	scCerts
	scSystem
	scAll = scTasks | scAuto | scCerts | scSystem
)

type filterDef struct {
	key, label string
	scope      int
	pred       func(*Item) bool
}

// Chinese labels shown on the main filter chips (MTR-style bilingual).
var filterCJK = map[string]string{"all": "全部", "suspicious": "威脅", "review": "待查"}

func flagPred(f uint64) func(*Item) bool { return func(it *Item) bool { return it.Flags&f != 0 } }

var filterDefs = []filterDef{
	{"all", "ALL", scAll, func(*Item) bool { return true }},
	{"suspicious", "THREATS", scAll, func(it *Item) bool { return it.Risk == RiskSuspicious }},
	{"review", "REVIEW", scAll, func(it *Item) bool { return it.Risk == RiskReview }},
	{"selfsigned", "SELF-SIGNED / FORGED", scTasks | scAuto, flagPred(FlagSelfSigned | FlagImpersonation)},
	{"tampered", "TAMPERED", scTasks | scAuto, flagPred(FlagBadSignature | FlagSmuggled)},
	{"unsigned", "UNSIGNED", scTasks | scAuto, flagPred(FlagUnsigned)},
	{"driver", "DRIVERS", scAuto, flagPred(FlagDriver)},
	{"hidden", "HIDDEN TASK", scTasks, flagPred(FlagSDMissing | FlagHiddenSetting)},
	{"registry", "TASKCACHE", scTasks, flagPred(FlagActionMismatch | FlagTaskCacheMismatch | FlagTreeMissingID | FlagOrphan)},
	{"ifeo", "IFEO", scTasks | scAuto, flagPred(FlagIFEO)},
	{"com", "COM HIJACK", scTasks, flagPred(FlagCOMHijack)},
	{"static", "CMDLINE", scTasks | scAuto, flagPred(FlagStaticAnalysis)},
	{"masq", "MASQUERADE", scTasks | scAuto, flagPred(FlagMasquerade)},
	{"timestomp", "TIMESTOMP", scTasks | scAuto, flagPred(FlagTimestomp)},
	{"trick", "PATH TRICK", scTasks | scAuto, flagPred(FlagPathTrick)},
	{"userwritable", "USER FOLDER", scTasks | scAuto, flagPred(FlagUserWritable)},
	{"missing", "MISSING", scTasks | scAuto, flagPred(FlagNotOnDisk)},
	{"logonboot", "LOGON / BOOT", scTasks, func(it *Item) bool { return it.BootTrigger || it.LogonTrig }},
	{"nondefault", "NON-DEFAULT", scAuto, flagPred(FlagNonDefault)},
	{"fake", "FAKE / IMPERSONATING", scCerts, flagPred(FlagImpersonation)},
	{"userroot", "USER-INSTALLED", scCerts, flagPred(FlagUserRoot)},
	{"codesign", "CODE-SIGNING", scCerts, flagPred(FlagCodeSigningRoot)},
	{"signs", "SIGNS RUNNING FILE", scCerts, flagPred(FlagSignsTarget)},
	{"recent", "RECENT", scCerts, flagPred(FlagRecent)},
	{"weak", "WEAKENED", scSystem, flagPred(FlagSystemWeak)},
	{"trusted", "TRUSTED BY YOU", scAll, func(it *Item) bool { return it.Trusted }},
}

var tabNames = []string{"TASKS", "AUTOSTART", "CERTS", "SYSTEM"}
var tabCJK = []string{"排程", "自啟", "證書", "系統"}

var columnTitles = [][]string{
	{"RISK", "TASK", "RUNS", "TRIGGER", "SIGNATURE", "FINDINGS"},
	{"RISK", "ENTRY", "RUNS", "WHERE", "SIGNATURE", "FINDINGS"},
	{"RISK", "CERTIFICATE", "THUMBPRINT", "STORE", "ISSUED BY", "FINDINGS"},
	{"RISK", "CHECK", "VALUE", "AREA", "", "FINDING"},
}

type btnKind int

const (
	bkScan btnKind = iota
	bkExport
	bkTab
	bkChip
	bkToggle
)

type btnInfo struct {
	kind  btnKind
	label string
	index int
	count int
}

type app struct {
	hwnd, hInst uintptr
	scale       float64

	fBrand, fCJK, fLabel, fTab, fNum, fName, fBody, fBodyB, fMono, fMonoB uintptr
	fCJKTab, fCJKLabel, fCJKSeal, fCJKSealBig, fSub                       uintptr
	iconBig, iconSmall, iconBanner                                        uintptr
	editBrush, cursorHand, cursorArrow                                    uintptr

	scanBtn, exportBtn, cleanBtn, search, list, header uintptr
	tabBtns, chipBtns                                  []uintptr
	btns                                               map[uintptr]*btnInfo
	detail                                             *detailPanel
	hover                                              uintptr
	searchFocus                                        bool
	textW                                              map[string]int

	cells                           []RECT
	hoverCell                       int
	searchLine, listFrame, detFrame RECT
	beacons                         []POINT // aircraft warning lights on the skyline

	mu           sync.Mutex
	progressText string
	pending      *ScanResult
	pendingErr   string
	scanning     bool
	animPhase    float64
	caretOn      bool

	trust    *UserTrust
	res      *ScanResult
	tabIdx   int
	filter   string
	query    string
	clean    bool
	view     []*Item
	sortCol  int
	sortDesc bool
	selected *Item
	selIdx   int
	status   string
}

func main() {
	defer func() {
		if r := recover(); r != nil {
			messageBox(0, fmt.Sprintf("HongKong hit an unexpected error:\n\n%v\n\n%s", r, debug.Stack()), "HongKong", MB_ICONERROR)
			os.Exit(1)
		}
	}()
	(&app{filter: "all", sortCol: -1, selIdx: -1, hoverCell: -1, textW: map[string]int{}, btns: map[uintptr]*btnInfo{}}).run()
}

func (a *app) px(n int) int { return int(float64(n)*a.scale + 0.5) }

func (a *app) loadIcon(size int) uintptr {
	h, _, _ := pLoadImageW.Call(a.hInst, 1, IMAGE_ICON, uintptr(size), uintptr(size), 0)
	return h
}

var mainProc, btnSubProc, listSubProc uintptr

func trustPath() string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		base = os.TempDir()
	}
	return filepath.Join(base, "HongKong", "trusted.json")
}

func (a *app) run() {
	icc := INITCOMMONCONTROLSEX{DwSize: 8, DwICC: ICC_ALL}
	pInitCommonControlsEx.Call(uintptr(unsafe.Pointer(&icc)))
	gdipStartup()
	a.hInst, _, _ = pGetModuleHandleW.Call(0)
	a.scale = float64(systemDPI()) / 96
	a.trust = loadUserTrust(trustPath())

	const fixed = 0x31 // FIXED_PITCH | FF_MODERN
	cjk := []string{"Microsoft JhengHei UI", "Microsoft JhengHei", "PMingLiU", "Microsoft YaHei UI"}
	latinBold := []string{"Bahnschrift SemiBold", "Bahnschrift", "Segoe UI Semibold"}
	a.fCJK = pickFont(a.px(26), 700, 136, 0, cjk...)
	a.fCJKTab = pickFont(a.px(15), 700, 136, 0, cjk...)
	a.fCJKLabel = pickFont(a.px(12), 400, 136, 0, cjk...)
	a.fCJKSeal = pickFont(a.px(12), 700, 136, 0, cjk...)
	a.fCJKSealBig = pickFont(a.px(22), 700, 136, 0, cjk...)
	a.fBrand = pickFont(a.px(24), 600, 1, 0, latinBold...)
	a.fLabel = pickFont(a.px(10), 600, 1, 0, latinBold...)
	a.fTab = pickFont(a.px(12), 600, 1, 0, latinBold...)
	a.fName = pickFont(a.px(21), 600, 1, 0, latinBold...)
	a.fNum = pickFont(a.px(28), 300, 1, 0, "Bahnschrift Light", "Bahnschrift", "Segoe UI Light")
	a.fSub = pickFont(a.px(12), 400, 1, 0, "Segoe UI", "Tahoma")
	a.fMono = pickFont(a.px(12), 400, 1, fixed, "Cascadia Mono", "Consolas", "Courier New")
	a.fMonoB = pickFont(a.px(12), 700, 1, fixed, "Cascadia Mono", "Consolas", "Courier New")
	a.fBody = pickFont(a.px(13), 400, 1, 0, "Segoe UI", "Tahoma")
	a.fBodyB = pickFont(a.px(13), 600, 1, 0, "Segoe UI Semibold", "Segoe UI", "Tahoma")
	big, _, _ := pGetSystemMetrics.Call(SM_CXICON)
	small, _, _ := pGetSystemMetrics.Call(SM_CXSMICON)
	a.iconBig, a.iconSmall, a.iconBanner = a.loadIcon(int(big)), a.loadIcon(int(small)), a.loadIcon(a.px(44))
	a.editBrush, _, _ = pCreateSolidBrush.Call(uintptr(cBg0.ref()))
	a.cursorHand, _, _ = pLoadCursorW.Call(0, IDC_HAND)
	a.cursorArrow, _, _ = pLoadCursorW.Call(0, IDC_ARROW)

	mainProc = syscall.NewCallback(a.wndProc)
	btnSubProc = syscall.NewCallback(a.btnSubclass)
	listSubProc = syscall.NewCallback(a.listSubclass)
	bg, _, _ := pCreateSolidBrush.Call(uintptr(cBg0.ref()))
	wc := WNDCLASSEXW{
		LpfnWndProc: mainProc, HInstance: a.hInst, HIcon: a.iconBig, HCursor: a.cursorArrow,
		HbrBackground: bg, LpszClassName: u16("HongKongMainWindow"), HIconSm: a.iconSmall,
	}
	wc.CbSize = uint32(unsafe.Sizeof(wc))
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	a.hwnd, _, _ = pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(wc.LpszClassName)), uintptr(unsafe.Pointer(u16("HongKong"))),
		WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN, 0x80000000, 0x80000000, uintptr(a.px(1440)), uintptr(a.px(900)), 0, 0, a.hInst, 0)
	if a.hwnd == 0 {
		messageBox(0, "Could not create the main window.", "HongKong", MB_ICONERROR)
		return
	}
	darkTitleBar(a.hwnd, cBg0)
	a.createControls()
	a.layout()
	pShowWindow.Call(a.hwnd, 1)
	pUpdateWindow.Call(a.hwnd)
	pSetTimer.Call(a.hwnd, timerCaret, 900, 0)
	a.showOverview()
	a.startScan()

	var msg MSG
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		if msg.Message == WM_KEYDOWN {
			switch {
			case msg.WParam == VK_F5:
				a.startScan()
				continue
			case msg.WParam == VK_F && keyDown(0x11):
				pSetFocus.Call(a.search)
				continue
			}
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
	}
}

var pGetKeyState = user32.NewProc("GetKeyState")

func keyDown(vk uintptr) bool {
	r, _, _ := pGetKeyState.Call(vk)
	return int16(r) < 0
}

func (a *app) child(class, text string, style, exStyle uint32, id int) uintptr {
	h, _, _ := pCreateWindowExW.Call(uintptr(exStyle), uintptr(unsafe.Pointer(u16(class))), uintptr(unsafe.Pointer(u16(text))),
		uintptr(WS_CHILD|WS_VISIBLE|style), 0, 0, 10, 10, a.hwnd, uintptr(id), a.hInst, 0)
	send(h, WM_SETFONT, a.fBody, 1)
	return h
}

func (a *app) ownerButton(kind btnKind, label string, id, index int) uintptr {
	h := a.child("BUTTON", label, BS_OWNERDRAW|WS_TABSTOP, 0, id)
	a.btns[h] = &btnInfo{kind: kind, label: label, index: index}
	pSetWindowSubclass.Call(h, btnSubProc, 1, 0)
	return h
}

func (a *app) createControls() {
	a.scanBtn = a.ownerButton(bkScan, "SCAN", idScan, 0)
	a.exportBtn = a.ownerButton(bkExport, "EXPORT", idExport, 0)
	for i, n := range tabNames {
		a.tabBtns = append(a.tabBtns, a.ownerButton(bkTab, n, idTabBase+i, i))
	}
	for i, d := range filterDefs {
		a.chipBtns = append(a.chipBtns, a.ownerButton(bkChip, d.label, idFilterBase+i, i))
	}
	a.cleanBtn = a.ownerButton(bkToggle, "Show clean", idShowClean, 0)

	a.search = a.child("EDIT", "", WS_TABSTOP|ES_AUTOHSCROLL, 0, idSearch)
	send(a.search, WM_SETFONT, a.fBody, 1)
	sendp(a.search, EM_SETCUEBANNER, 1, unsafe.Pointer(u16("name, path, signer, SHA-256")))

	a.list = a.child("SysListView32", "", WS_TABSTOP|LVS_REPORT|LVS_SINGLESEL|LVS_SHOWSELALWAYS|LVS_OWNERDATA, 0, idList)
	ex := uintptr(LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER)
	send(a.list, LVM_SETEXTENDEDLISTVIEWSTYLE, ex, ex)
	pSetWindowTheme.Call(a.list, uintptr(unsafe.Pointer(u16("DarkMode_Explorer"))), 0)
	send(a.list, LVM_SETBKCOLOR, 0, uintptr(cBg1.ref()))
	send(a.list, LVM_SETTEXTBKCOLOR, 0, uintptr(cBg1.ref()))
	send(a.list, LVM_SETTEXTCOLOR, 0, uintptr(cText.ref()))
	il, _, _ := pImageListCreate.Call(1, uintptr(a.px(36)), ILC_COLOR32, 1, 1) // row height
	send(a.list, LVM_SETIMAGELIST, 1, il)
	for i, t := range columnTitles[0] {
		col := LVCOLUMNW{Mask: LVCF_TEXT | LVCF_WIDTH | LVCF_SUBITEM, Cx: int32(a.px(120)), PszText: u16(t), ISubItem: int32(i)}
		sendp(a.list, LVM_INSERTCOLUMNW, uintptr(i), unsafe.Pointer(&col))
	}
	a.header = send(a.list, LVM_GETHEADER, 0, 0)
	pSetWindowSubclass.Call(a.list, listSubProc, 2, 0)

	a.createDetailPanel()
}

func (a *app) textWidth(s string, font uintptr) int {
	key := fmt.Sprintf("%d|%s", font, s)
	if w, ok := a.textW[key]; ok {
		return w
	}
	hdc, _, _ := pGetDC.Call(a.hwnd)
	w, _ := measure(hdc, s, font, 4000, false)
	pReleaseDC.Call(a.hwnd, hdc)
	a.textW[key] = w
	return w
}

// tracked width: letter-spaced caps add `spacing` per character.
func (a *app) capsWidth(s string, font uintptr, spacing int) int {
	return a.textWidth(s, font) + spacing*len([]rune(s))
}

// ---------------------------------------------------------------------------
// layout

func (a *app) chipVisible(i int) bool {
	d := filterDefs[i]
	if d.scope&(1<<a.tabIdx) == 0 {
		return false
	}
	if d.key == "all" || d.key == "suspicious" || d.key == "review" || d.key == a.filter {
		return true
	}
	return a.btns[a.chipBtns[i]].count > 0
}

// fitColumns sizes the columns to the list so nothing scrolls sideways.
func (a *app) fitColumns(total int) {
	sbw, _, _ := pGetSystemMetrics.Call(2) // SM_CXVSCROLL
	avail := total - int(sbw) - a.px(4)
	frac := [][]float64{
		{0.125, 0.18, 0.22, 0.11, 0.16, 0.20},
		{0.125, 0.17, 0.22, 0.11, 0.16, 0.21},
		{0.125, 0.19, 0.21, 0.11, 0.15, 0.21},
		{0.125, 0.24, 0.17, 0.12, 0.00, 0.34},
	}[a.tabIdx]
	mins := []int{124, 120, 110, 70, 0, 130}
	ws := make([]int, 6)
	used := 0
	for i, f := range frac {
		if f == 0 {
			continue
		}
		ws[i] = int(float64(avail) * f)
		if ws[i] < a.px(mins[i]) {
			ws[i] = a.px(mins[i])
		}
		used += ws[i]
	}
	if diff := avail - used; diff < 0 {
		ws[2] += diff
		if ws[2] < a.px(mins[2]) {
			ws[2] = a.px(mins[2])
		}
	} else {
		ws[5] += diff
	}
	for i, w := range ws {
		send(a.list, 0x101E /*LVM_SETCOLUMNWIDTH*/, uintptr(i), uintptr(w))
	}
}

// ---------------------------------------------------------------------------
// window procedure

func (a *app) wndProc(hwnd uintptr, msg uint32, wparam, lparam uintptr) uintptr {
	switch msg {
	case WM_ERASEBKGND:
		return 1
	case WM_SIZE:
		a.layout()
		return 0
	case WM_GETMINMAXINFO:
		mmi := ptrFrom[MINMAXINFO](lparam)
		mmi.PtMinTrackSize = POINT{int32(a.px(1100)), int32(a.px(700))}
		return 0
	case WM_PAINT:
		a.paintMain(hwnd)
		return 0
	case WM_DRAWITEM:
		a.drawItem(ptrFrom[DRAWITEMSTRUCT](lparam))
		return 1
	case WM_CTLCOLOREDIT:
		pSetTextColor.Call(wparam, uintptr(cText.ref()))
		pSetBkColor.Call(wparam, uintptr(cBg0.ref()))
		return a.editBrush
	case WM_COMMAND:
		a.onCommand(int(wparam&0xFFFF), uint32(wparam>>16&0xFFFF))
		return 0
	case WM_NOTIFY:
		if r, handled := a.onNotify(lparam); handled {
			return r
		}
	case WM_CONTEXTMENU:
		if wparam == a.list {
			a.contextMenu()
			return 0
		}
	case WM_MOUSEMOVE:
		x, y := int32(int16(lparam&0xFFFF)), int32(int16(lparam>>16&0xFFFF))
		if hc := a.cellAt(x, y); hc != a.hoverCell {
			a.hoverCell = hc
			a.invalidateHUD()
			tme := TRACKMOUSEEVENT{DwFlags: TME_LEAVE, HwndTrack: hwnd}
			tme.CbSize = uint32(unsafe.Sizeof(tme))
			pTrackMouseEvent.Call(uintptr(unsafe.Pointer(&tme)))
		}
	case WM_MOUSELEAVE:
		if a.hoverCell != -1 {
			a.hoverCell = -1
			a.invalidateHUD()
		}
	case WM_SETCURSOR:
		if a.hoverCell >= 0 && wparam == hwnd {
			pSetCursor.Call(a.cursorHand)
			return 1
		}
	case WM_LBUTTONDOWN:
		x, y := int32(int16(lparam&0xFFFF)), int32(int16(lparam>>16&0xFFFF))
		a.clickCell(a.cellAt(x, y))
		return 0
	case WM_TIMER:
		switch wparam {
		case timerAnim:
			a.animPhase += 0.014
			if a.animPhase > 1.5 {
				a.animPhase = -0.5
			}
			rc := clientRect(hwnd)
			r := RECT{0, int32(a.headerH() - a.px(3)), rc.Right, int32(a.headerH() + 1)}
			pInvalidateRect.Call(hwnd, uintptr(unsafe.Pointer(&r)), 0)
		case timerCaret:
			a.caretOn = !a.caretOn
			a.invalidateFooter()
			a.invalidateBeacons()
		}
		return 0
	case wmScanProgress:
		a.mu.Lock()
		t := a.progressText
		a.mu.Unlock()
		a.setStatus(t + " …")
		return 0
	case wmScanDone:
		a.onScanDone()
		return 0
	case WM_DESTROY:
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, uintptr(msg), wparam, lparam)
	return r
}

func (a *app) cellAt(x, y int32) int {
	for i, r := range a.cells {
		if x >= r.Left && x < r.Right && y >= r.Top && y < r.Bottom {
			return i
		}
	}
	return -1
}

func (a *app) invalidateHUD() {
	rc := clientRect(a.hwnd)
	r := RECT{0, int32(a.headerH()), rc.Right, int32(a.headerH() + a.hudH())}
	pInvalidateRect.Call(a.hwnd, uintptr(unsafe.Pointer(&r)), 0)
}

func (a *app) invalidateFooter() {
	rc := clientRect(a.hwnd)
	r := RECT{0, rc.Bottom - int32(a.footerH()), rc.Right, rc.Bottom}
	pInvalidateRect.Call(a.hwnd, uintptr(unsafe.Pointer(&r)), 0)
}

func (a *app) clickCell(i int) {
	switch {
	case i >= 0 && i <= 3:
		a.switchTab(i)
	case i == 4:
		a.filter = "suspicious"
		a.refresh()
	case i == 5:
		a.filter = "review"
		a.refresh()
	}
}

func (a *app) btnSubclass(hwnd uintptr, msg uint32, w, l, id, ref uintptr) uintptr {
	switch msg {
	case WM_MOUSEMOVE:
		if a.hover != hwnd {
			old := a.hover
			a.hover = hwnd
			if old != 0 {
				pInvalidateRect.Call(old, 0, 0)
			}
			pInvalidateRect.Call(hwnd, 0, 0)
			tme := TRACKMOUSEEVENT{DwFlags: TME_LEAVE, HwndTrack: hwnd}
			tme.CbSize = uint32(unsafe.Sizeof(tme))
			pTrackMouseEvent.Call(uintptr(unsafe.Pointer(&tme)))
		}
	case WM_MOUSELEAVE:
		if a.hover == hwnd {
			a.hover = 0
			pInvalidateRect.Call(hwnd, 0, 0)
		}
	case WM_SETCURSOR:
		pSetCursor.Call(a.cursorHand)
		return 1
	case WM_ERASEBKGND:
		return 1
	}
	r, _, _ := pDefSubclassProc.Call(hwnd, uintptr(msg), w, l)
	return r
}

func (a *app) listSubclass(hwnd uintptr, msg uint32, w, l, id, ref uintptr) uintptr {
	if msg == WM_NOTIFY {
		hdr := ptrFrom[NMHDR](l)
		if hdr.HwndFrom == a.header && hdr.Code == NM_CUSTOMDRAW {
			return a.drawHeader(ptrFrom[NMCUSTOMDRAW](l))
		}
	}
	r, _, _ := pDefSubclassProc.Call(hwnd, uintptr(msg), w, l)
	return r
}

// ---------------------------------------------------------------------------
// painting

// ---------------------------------------------------------------------------
// events

func (a *app) setStatus(s string) {
	a.status = s
	a.invalidateFooter()
}

func (a *app) onCommand(id int, code uint32) {
	click := code == BN_CLICKED || code == BN_DOUBLECLICKED
	switch {
	case id == idScan && click:
		a.startScan()
	case id == idExport && click:
		a.exportMenu()
	case id == idShowClean && click:
		a.clean = !a.clean
		pInvalidateRect.Call(a.cleanBtn, 0, 0)
		a.refresh()
	case id == idSearch && code == EN_CHANGE:
		a.query = strings.TrimSpace(getText(a.search))
		a.applyView()
	case id == idSearch && (code == EN_SETFOCUS || code == EN_KILLFOCUS):
		a.searchFocus = code == EN_SETFOCUS
		r := a.searchLine
		pInvalidateRect.Call(a.hwnd, uintptr(unsafe.Pointer(&r)), 0)
	case id >= idTabBase && id < idTabBase+len(tabNames) && click:
		a.switchTab(id - idTabBase)
	case id >= idFilterBase && id < idFilterBase+len(filterDefs) && click:
		a.filter = filterDefs[id-idFilterBase].key
		if a.filter == "trusted" && !a.clean {
			a.clean = true // trusted items are clean by definition
			pInvalidateRect.Call(a.cleanBtn, 0, 0)
		}
		a.refresh()
	}
}

func (a *app) switchTab(i int) {
	if i == a.tabIdx {
		return
	}
	a.tabIdx = i
	a.filter, a.selected, a.selIdx, a.sortCol = "all", nil, -1, -1
	for c, t := range columnTitles[i] {
		col := LVCOLUMNW{Mask: LVCF_TEXT, PszText: u16(t)}
		sendp(a.list, LVM_SETCOLUMNW, uintptr(c), unsafe.Pointer(&col))
	}
	for _, h := range a.tabBtns {
		pInvalidateRect.Call(h, 0, 0)
	}
	pInvalidateRect.Call(a.header, 0, 0)
	a.refresh()
	a.showOverview()
}

func (a *app) onNotify(lparam uintptr) (uintptr, bool) {
	hdr := ptrFrom[NMHDR](lparam)
	if hdr.HwndFrom != a.list {
		return 0, false
	}
	switch hdr.Code {
	case LVN_GETDISPINFOW:
		di := ptrFrom[NMLVDISPINFOW](lparam)
		if di.Item.Mask&LVIF_TEXT != 0 && int(di.Item.IItem) >= 0 && int(di.Item.IItem) < len(a.view) {
			copyToBuf(di.Item.PszText, int(di.Item.CchTextMax), a.cellText(a.view[di.Item.IItem], int(di.Item.ISubItem)))
		}
		return 0, true
	case NM_CUSTOMDRAW:
		cd := ptrFrom[NMLVCUSTOMDRAW](lparam)
		switch cd.Nmcd.DrawStage {
		case CDDS_PREPAINT:
			return CDRF_NOTIFYITEMDRAW, true
		case CDDS_ITEMPREPAINT:
			return a.paintRow(cd), true
		}
		return CDRF_DODEFAULT, true
	case LVN_ITEMCHANGED:
		a.onSelect()
		return 0, true
	case LVN_COLUMNCLICK:
		nm := ptrFrom[NMLISTVIEW](lparam)
		col := int(nm.ISubItem)
		if a.sortCol == col {
			a.sortDesc = !a.sortDesc
		} else {
			a.sortCol, a.sortDesc = col, false
		}
		pInvalidateRect.Call(a.header, 0, 0)
		a.applyView()
		return 0, true
	case NM_DBLCLK:
		if it := a.selected; it != nil {
			a.openLocation(it)
		}
		return 0, true
	}
	return 0, false
}

// ---------------------------------------------------------------------------
// data & view

func (a *app) itemsFor(tab int) []*Item {
	if a.res == nil {
		return nil
	}
	switch tab {
	case 0:
		return a.res.Tasks
	case 1:
		return a.res.Autostart
	case 2:
		return a.res.Certs
	}
	return a.res.System
}

func (a *app) base() []*Item {
	var out []*Item
	for _, it := range a.itemsFor(a.tabIdx) {
		if a.clean || it.Risk != RiskClean {
			out = append(out, it)
		}
	}
	return out
}

func (a *app) refresh() {
	base := a.base()
	for i, d := range filterDefs {
		n := 0
		for _, it := range base {
			if d.pred(it) {
				n++
			}
		}
		a.btns[a.chipBtns[i]].count = n
		pInvalidateRect.Call(a.chipBtns[i], 0, 0)
	}
	for i, h := range a.tabBtns {
		n := 0
		for _, it := range a.itemsFor(i) {
			if it.Risk != RiskClean {
				n++
			}
		}
		a.btns[h].count = n
		pInvalidateRect.Call(h, 0, 0)
	}
	a.applyView()
	a.layout()
}

func (a *app) currentFilter() filterDef {
	for _, d := range filterDefs {
		if d.key == a.filter && d.scope&(1<<a.tabIdx) != 0 {
			return d
		}
	}
	a.filter = "all"
	return filterDefs[0]
}

func (a *app) matchesQuery(it *Item) bool {
	if a.query == "" {
		return true
	}
	hay := []string{it.Name, it.Path, it.Command, it.Location, it.Author, it.Signer, it.SHA256, it.SignatureStatus}
	for _, t := range it.Targets {
		hay = append(hay, t.Path, t.Sig.Signer, t.SHA256, t.Sig.RootThumb)
	}
	for _, f := range it.Findings {
		hay = append(hay, f.Text)
	}
	return strings.Contains(strings.ToLower(strings.Join(hay, "\n")), strings.ToLower(a.query))
}

func (a *app) applyView() {
	d := a.currentFilter()
	a.view = a.view[:0]
	for _, it := range a.base() {
		if d.pred(it) && a.matchesQuery(it) {
			a.view = append(a.view, it)
		}
	}
	if a.sortCol >= 0 {
		col, desc := a.sortCol, a.sortDesc
		sort.SliceStable(a.view, func(i, j int) bool {
			var less bool
			if col == 0 {
				less = riskRank(a.view[i].Risk) < riskRank(a.view[j].Risk)
			} else {
				less = strings.ToLower(a.cellText(a.view[i], col)) < strings.ToLower(a.cellText(a.view[j], col))
			}
			if desc {
				return !less
			}
			return less
		})
	}
	a.selIdx = -1
	for i, it := range a.view {
		if it == a.selected {
			a.selIdx = i
		}
	}
	send(a.list, LVM_SETITEMCOUNT, uintptr(len(a.view)), 0)
	if a.selIdx >= 0 {
		st := LVITEMW{StateMask: LVIS_SELECTED | LVIS_FOCUSED, State: LVIS_SELECTED | LVIS_FOCUSED}
		sendp(a.list, LVM_SETITEMSTATE, uintptr(a.selIdx), unsafe.Pointer(&st))
	} else if a.selected != nil {
		a.selected = nil
		a.showOverview()
	}
	pInvalidateRect.Call(a.list, 0, 0)
}

func (a *app) cellText(it *Item, col int) string {
	switch col {
	case 0:
		return it.Risk
	case 1:
		return it.Name
	case 2:
		return it.Command
	case 3:
		if it.Kind == "task" {
			t := strings.Join(it.Triggers, ", ")
			if !it.Enabled {
				t = "disabled · " + t
			}
			return t
		}
		return it.Location
	case 4:
		return it.SignatureStatus
	case 5:
		if it.Trusted {
			return "trusted by you"
		}
		if h := it.headline(); h != "" {
			return h
		}
		if len(it.Findings) > 0 {
			return it.Findings[0].Text
		}
	}
	return ""
}

func (a *app) onSelect() {
	r := send(a.list, LVM_GETNEXTITEM, ^uintptr(0), LVNI_SELECTED)
	i := int(int32(r))
	if i < 0 || i >= len(a.view) {
		return
	}
	if i == a.selIdx && a.view[i] == a.selected {
		return
	}
	a.selIdx = i
	a.selected = a.view[i]
	pInvalidateRect.Call(a.list, 0, 0)
	a.showItem(a.selected)
}

// ---------------------------------------------------------------------------
// scanning

func (a *app) startScan() {
	if a.scanning {
		return
	}
	a.scanning = true
	a.animPhase = -0.5
	pSetTimer.Call(a.hwnd, timerAnim, 16, 0)
	enableWindow(a.scanBtn, false)
	enableWindow(a.exportBtn, false)
	a.setStatus("Scanning …")
	go func() {
		var r *ScanResult
		errText := ""
		func() {
			defer func() {
				if p := recover(); p != nil {
					errText = fmt.Sprintf("%v\n\n%s", p, debug.Stack())
				}
			}()
			r = Scan(newPlatform(), ScanOptions{Tasks: true, Autostart: true, Signatures: true, Hashes: true, RecentDays: 7,
				Progress: func(s string) {
					a.mu.Lock()
					a.progressText = s
					a.mu.Unlock()
					post(a.hwnd, wmScanProgress, 0, 0)
				}})
		}()
		a.mu.Lock()
		a.pending, a.pendingErr = r, errText
		a.mu.Unlock()
		post(a.hwnd, wmScanDone, 0, 0)
	}()
}

func (a *app) onScanDone() {
	a.mu.Lock()
	r, errText := a.pending, a.pendingErr
	a.pending, a.pendingErr = nil, ""
	a.mu.Unlock()
	a.scanning = false
	pKillTimer.Call(a.hwnd, timerAnim)
	pInvalidateRect.Call(a.hwnd, 0, 0)
	if errText != "" || r == nil {
		enableWindow(a.scanBtn, true)
		a.setStatus("Scan failed")
		messageBox(a.hwnd, "The scan failed:\n\n"+errText, "HongKong", MB_ICONERROR)
		return
	}
	r.applyUserTrust(a.trust)
	a.res = r
	enableWindow(a.exportBtn, true)
	enableWindow(a.scanBtn, true)
	pInvalidateRect.Call(a.scanBtn, 0, 0)
	a.selected, a.selIdx = nil, -1
	a.refresh()
	a.showOverview()
	a.setStatus(fmt.Sprintf("Scan complete   ·   %d threats   ·   %d to review   ·   %d tasks · %d autostart · %d certificates · %d checks   ·   %.1fs",
		r.Summary.Suspicious, r.Summary.Review, r.Summary.Tasks, r.Summary.Autostart, r.Summary.Certs, r.Summary.System, r.Duration.Seconds()))
}

// ---------------------------------------------------------------------------
// plain-text details (clipboard)

func detailText(it *Item) string {
	var b strings.Builder
	nl := "\r\n"
	kv := func(k, v string) {
		if v = strings.TrimSpace(v); v != "" {
			fmt.Fprintf(&b, "  %-15s %s%s", k+":", strings.ReplaceAll(v, "\n", nl+strings.Repeat(" ", 18)), nl)
		}
	}
	b.WriteString(it.Name + nl + it.Path + nl + "Risk: " + it.Risk + nl + nl + "FINDINGS" + nl)
	for _, f := range it.Findings {
		b.WriteString("  [" + f.Sev.String() + "] " + f.Text + nl)
	}
	b.WriteString(nl + "DETAILS" + nl)
	kv("Command", it.Command)
	kv("Triggers", strings.Join(it.Triggers, ", "))
	kv("Run as", strings.TrimSpace(it.RunAs+" "+it.RunLevel))
	kv("Location", it.Location)
	kv("Source", it.Source)
	kv("Author", it.Author)
	kv("Registered", it.RegDate)
	for _, d := range it.Details {
		kv(d.K, d.V)
	}
	for _, t := range it.Targets {
		b.WriteString(nl + "TARGET (" + t.Role + ")" + nl)
		kv("Path", t.Path)
		kv("Signature", t.Sig.Status)
		kv("Signer", t.Sig.Signer)
		kv("Chain root", t.Sig.ChainRoot)
		kv("Root thumb", t.Sig.RootThumb)
		kv("Note", t.Sig.Note)
		kv("SHA-256", t.SHA256)
	}
	return b.String()
}

// ---------------------------------------------------------------------------
// actions

func (a *app) primaryTarget(it *Item) *Target {
	for i := range it.Targets {
		if it.Targets[i].Path != "" {
			return &it.Targets[i]
		}
	}
	return nil
}

func (a *app) contextMenu() {
	it := a.selected
	if it == nil {
		return
	}
	m, _, _ := pCreatePopupMenu.Call()
	defer pDestroyMenu.Call(m)
	add := func(id int, text string, enabled bool) {
		flags := uintptr(MF_STRING)
		if !enabled {
			flags |= MF_GRAYED
		}
		pAppendMenuW.Call(m, flags, uintptr(id), uintptr(unsafe.Pointer(u16(text))))
	}
	sep := func() { pAppendMenuW.Call(m, MF_SEPARATOR, 0, 0) }
	switch it.Kind {
	case "cert":
		add(idmCopyThumb, "Copy thumbprint", true)
		add(idmCopyRemove, "Copy removal command (certutil)", true)
		add(idmCertMgr, "Open certificate manager", true)
		add(idmCopyDetails, "Copy details", true)
	case "system":
		add(idmCopyDetails, "Copy details", true)
	default:
		t := a.primaryTarget(it)
		add(idmOpenLoc, "Open file location", t != nil && t.Exists)
		add(idmCopyPath, "Copy target path", t != nil)
		add(idmCopyHash, "Copy SHA-256", it.SHA256 != "")
		add(idmVirusTotal, "Look up SHA-256 on VirusTotal", it.SHA256 != "")
		add(idmCopyDetails, "Copy details", true)
		if it.Kind == "task" {
			sep()
			add(idmRun, "Run task now", true)
			add(idmEnable, "Enable task", !it.Enabled)
			add(idmDisable, "Disable task", it.Enabled)
			add(idmExportXML, "Export task XML...", true)
			add(idmDelete, "Delete task (backup first)...", true)
		}
	}
	sep()
	if it.Trusted {
		add(idmUntrust, "Remove trust", true)
	} else {
		add(idmTrust, "Mark as trusted (until the file changes)", it.Risk != RiskClean)
	}
	var pt POINT
	pGetCursorPos.Call(uintptr(unsafe.Pointer(&pt)))
	cmd, _, _ := pTrackPopupMenu.Call(m, TPM_RETURNCMD|TPM_RIGHTBUTTON, uintptr(pt.X), uintptr(pt.Y), 0, a.hwnd, 0)
	a.runMenu(int(cmd), it)
}

func (a *app) runMenu(cmd int, it *Item) {
	t := a.primaryTarget(it)
	userStore := strings.HasPrefix(it.Location, "User")
	switch cmd {
	case idmTrust, idmUntrust:
		a.trust.setTrusted(it, cmd == idmTrust)
		if err := a.trust.save(); err != nil {
			messageBox(a.hwnd, "Could not save the trust list: "+err.Error(), "HongKong", MB_ICONERROR)
		}
		a.res.summarize()
		a.refresh()
		a.showItem(it)
		pInvalidateRect.Call(a.hwnd, 0, 0)
	case idmOpenLoc:
		a.openLocation(it)
	case idmCopyPath:
		if t != nil {
			setClipboard(a.hwnd, t.Path)
		}
	case idmCopyHash:
		setClipboard(a.hwnd, it.SHA256)
	case idmVirusTotal:
		shellExecute(a.hwnd, "open", "https://www.virustotal.com/gui/file/"+it.SHA256, "")
	case idmCopyDetails:
		setClipboard(a.hwnd, detailText(it))
	case idmCopyThumb:
		setClipboard(a.hwnd, it.Command)
	case idmCopyRemove:
		store := "Root"
		if strings.Contains(it.Location, "TrustedPublisher") {
			store = "TrustedPublisher"
		}
		cmdline := "certutil -delstore " + store + " " + it.Command
		if userStore {
			cmdline = "certutil -user -delstore " + store + " " + it.Command
		}
		setClipboard(a.hwnd, cmdline)
		messageBox(a.hwnd, "Copied:\n\n"+cmdline+"\n\nRun it in a terminal"+map[bool]string{true: " as the user who owns the store.", false: " as administrator."}[userStore],
			"HongKong", MB_ICONINFO)
	case idmCertMgr:
		if userStore {
			shellExecute(a.hwnd, "open", "certmgr.msc", "")
		} else {
			shellExecute(a.hwnd, "open", "certlm.msc", "")
		}
	case idmRun:
		a.schtasks(it, "Run", "/run", "/tn", it.Path)
	case idmEnable:
		if a.schtasks(it, "Enable", "/change", "/tn", it.Path, "/enable") {
			it.Enabled = true
			pInvalidateRect.Call(a.list, 0, 0)
		}
	case idmDisable:
		if a.schtasks(it, "Disable", "/change", "/tn", it.Path, "/disable") {
			it.Enabled = false
			pInvalidateRect.Call(a.list, 0, 0)
		}
	case idmExportXML:
		name := regexp.MustCompile(`[^A-Za-z0-9_.-]+`).ReplaceAllString(it.Name, "_") + ".xml"
		if p, ok := saveDialog(a.hwnd, "Export task XML", name, "xml", "Task XML (*.xml)", "*.xml"); ok {
			data, err := a.taskXML(it)
			if err == nil {
				err = os.WriteFile(p, data, 0o644)
			}
			if err != nil {
				messageBox(a.hwnd, "Export failed: "+err.Error(), "HongKong", MB_ICONERROR)
			}
		}
	case idmDelete:
		a.deleteTask(it)
	}
}

func (a *app) openLocation(it *Item) {
	t := a.primaryTarget(it)
	if t == nil || !t.Exists {
		return
	}
	shellExecute(a.hwnd, "open", "explorer.exe", `/select,"`+t.Path+`"`)
}

func (a *app) schtasks(it *Item, what string, args ...string) bool {
	out, err := runSchtasks(args...)
	if err != nil {
		msg := strings.TrimSpace(out)
		if it.has(FlagSDMissing) {
			msg += "\n\nThis task's security descriptor was removed, so Task Scheduler cannot see it. Remove its TaskCache keys manually (as SYSTEM) instead."
		}
		messageBox(a.hwnd, what+" failed for "+it.Path+":\n\n"+msg, "HongKong", MB_ICONERROR)
		return false
	}
	messageBox(a.hwnd, strings.TrimSpace(out), "HongKong - "+what, MB_ICONINFO)
	return true
}

func (a *app) taskXML(it *Item) ([]byte, error) {
	if it.XMLFile != "" {
		if b, err := os.ReadFile(it.XMLFile); err == nil {
			return b, nil
		}
	}
	out, err := runSchtasks("/query", "/tn", it.Path, "/xml")
	if err != nil {
		return nil, fmt.Errorf("%s", strings.TrimSpace(out))
	}
	return []byte(out), nil
}

func (a *app) deleteTask(it *Item) {
	if messageBox(a.hwnd, "Delete scheduled task\n\n"+it.Path+"\n\nA backup of its XML is saved first. Continue?",
		"HongKong - Delete task", MB_YESNO|MB_ICONWARNING|MB_DEFBUTTON2) != IDYES {
		return
	}
	data, err := a.taskXML(it)
	if err != nil {
		messageBox(a.hwnd, "Could not back up the task, nothing was deleted:\n\n"+err.Error(), "HongKong", MB_ICONERROR)
		return
	}
	dir := "HongKong_backups"
	if exe, err := os.Executable(); err == nil {
		dir = filepath.Join(filepath.Dir(exe), dir)
	}
	os.MkdirAll(dir, 0o755)
	safe := regexp.MustCompile(`[^A-Za-z0-9_.-]+`).ReplaceAllString(strings.Trim(it.Path, `\`), "_")
	backup := filepath.Join(dir, safe+"_"+time.Now().Format("20060102_150405")+".xml")
	if err := os.WriteFile(backup, data, 0o644); err != nil {
		messageBox(a.hwnd, "Could not write the backup, nothing was deleted:\n\n"+err.Error(), "HongKong", MB_ICONERROR)
		return
	}
	out, err := runSchtasks("/delete", "/tn", it.Path, "/f")
	if err != nil {
		messageBox(a.hwnd, "Delete failed:\n\n"+strings.TrimSpace(out), "HongKong", MB_ICONERROR)
		return
	}
	messageBox(a.hwnd, "Task deleted.\n\nBackup: "+backup+"\nRestore with:\nschtasks /create /tn \""+it.Path+"\" /xml \""+backup+"\"",
		"HongKong", MB_ICONINFO)
	a.startScan()
}

func (a *app) exportMenu() {
	if a.res == nil {
		return
	}
	m, _, _ := pCreatePopupMenu.Call()
	defer pDestroyMenu.Call(m)
	pAppendMenuW.Call(m, MF_STRING, idmExportCSV, uintptr(unsafe.Pointer(u16("Current view as CSV..."))))
	pAppendMenuW.Call(m, MF_STRING, idmExportJSON, uintptr(unsafe.Pointer(u16("Full scan as JSON..."))))
	r := windowRect(a.exportBtn)
	cmd, _, _ := pTrackPopupMenu.Call(m, TPM_RETURNCMD|TPM_RIGHTBUTTON, uintptr(r.Left), uintptr(r.Bottom+2), 0, a.hwnd, 0)
	stamp := a.res.Generated.Format("20060102_150405")
	var err error
	switch int(cmd) {
	case idmExportCSV:
		if p, ok := saveDialog(a.hwnd, "Export CSV", "HongKong_"+stamp+".csv", "csv", "CSV (*.csv)", "*.csv"); ok {
			err = writeCSV(a.view, p)
		}
	case idmExportJSON:
		if p, ok := saveDialog(a.hwnd, "Export JSON", "HongKong_"+stamp+".json", "json", "JSON (*.json)", "*.json"); ok {
			err = writeJSON(a.res, p)
		}
	}
	if err != nil {
		messageBox(a.hwnd, "Export failed: "+err.Error(), "HongKong", MB_ICONERROR)
	}
}
