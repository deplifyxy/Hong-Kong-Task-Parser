package main

import (
	"bytes"
	"encoding/binary"
	"encoding/xml"
	"errors"
	"io"
	"strings"
	"unicode/utf16"
)

// Task Scheduler 2.0 XML, as stored under %SystemRoot%\System32\Tasks.
// Tags carry no namespace so they match the default task namespace.
type taskXML struct {
	RegistrationInfo struct {
		Author      string `xml:"Author"`
		Description string `xml:"Description"`
		Date        string `xml:"Date"`
		URI         string `xml:"URI"`
		Source      string `xml:"Source"`
	} `xml:"RegistrationInfo"`
	Triggers struct {
		Any []triggerXML `xml:",any"`
	} `xml:"Triggers"`
	Principals struct {
		Principal []struct {
			ID        string `xml:"id,attr"`
			UserID    string `xml:"UserId"`
			GroupID   string `xml:"GroupId"`
			LogonType string `xml:"LogonType"`
			RunLevel  string `xml:"RunLevel"`
		} `xml:"Principal"`
	} `xml:"Principals"`
	Settings struct {
		Hidden  string `xml:"Hidden"`
		Enabled string `xml:"Enabled"`
	} `xml:"Settings"`
	Actions struct {
		Context string `xml:"Context,attr"`
		Any     []struct {
			XMLName          xml.Name
			Command          string `xml:"Command"`
			Arguments        string `xml:"Arguments"`
			WorkingDirectory string `xml:"WorkingDirectory"`
			ClassID          string `xml:"ClassId"`
			Data             string `xml:"Data"`
		} `xml:",any"`
	} `xml:"Actions"`
}

type triggerXML struct {
	XMLName       xml.Name
	Enabled       string `xml:"Enabled"`
	StartBoundary string `xml:"StartBoundary"`
	Delay         string `xml:"Delay"`
	UserID        string `xml:"UserId"`
	StateChange   string `xml:"StateChange"`
	Subscription  string `xml:"Subscription"`
}

type ParsedTask struct {
	Author, Description, Date, URI string
	Enabled, Hidden                bool
	RunAs, RunLevel                string
	Triggers                       []string
	Boot, Logon                    bool
	Actions                        []Action
}

var triggerLabels = map[string]string{
	"BootTrigger":               "Boot",
	"LogonTrigger":              "Logon",
	"TimeTrigger":               "Time",
	"CalendarTrigger":           "Calendar",
	"IdleTrigger":               "Idle",
	"EventTrigger":              "Event",
	"RegistrationTrigger":       "Registration",
	"SessionStateChangeTrigger": "Session state",
	"WnfStateChangeTrigger":     "WNF state",
}

// decodeText turns UTF-16 (with or without BOM) or UTF-8 bytes into a UTF-8 string.
func decodeText(b []byte) string {
	switch {
	case len(b) >= 2 && b[0] == 0xFF && b[1] == 0xFE:
		return utf16le(b[2:])
	case len(b) >= 2 && b[0] == 0xFE && b[1] == 0xFF:
		u := make([]uint16, len(b[2:])/2)
		for i := range u {
			u[i] = binary.BigEndian.Uint16(b[2+2*i:])
		}
		return string(utf16.Decode(u))
	case len(b) >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF:
		return string(b[3:])
	case len(b) >= 2 && b[1] == 0 && b[0] != 0:
		return utf16le(b)
	}
	return string(b)
}

func utf16le(b []byte) string {
	u := make([]uint16, len(b)/2)
	for i := range u {
		u[i] = binary.LittleEndian.Uint16(b[2*i:])
	}
	return string(utf16.Decode(u))
}

func parseTaskXML(raw []byte) (*ParsedTask, error) {
	text := decodeText(raw)
	if strings.TrimSpace(text) == "" {
		return nil, errors.New("empty task file")
	}
	var tx taskXML
	dec := xml.NewDecoder(strings.NewReader(text))
	// The content is already UTF-8; ignore the "UTF-16" declaration.
	dec.CharsetReader = func(_ string, in io.Reader) (io.Reader, error) { return in, nil }
	if err := dec.Decode(&tx); err != nil {
		return nil, err
	}
	pt := &ParsedTask{
		Author:      strings.TrimSpace(tx.RegistrationInfo.Author),
		Description: strings.TrimSpace(tx.RegistrationInfo.Description),
		Date:        strings.TrimSpace(tx.RegistrationInfo.Date),
		URI:         strings.TrimSpace(tx.RegistrationInfo.URI),
		Enabled:     !strings.EqualFold(strings.TrimSpace(tx.Settings.Enabled), "false"),
		Hidden:      strings.EqualFold(strings.TrimSpace(tx.Settings.Hidden), "true"),
	}
	// Principal referenced by the Actions context (or the first one).
	for i, p := range tx.Principals.Principal {
		if i == 0 || p.ID == tx.Actions.Context {
			pt.RunAs = strings.TrimSpace(p.UserID)
			if pt.RunAs == "" {
				pt.RunAs = strings.TrimSpace(p.GroupID)
			}
			pt.RunLevel = strings.TrimSpace(p.RunLevel)
		}
	}
	for _, t := range tx.Triggers.Any {
		if strings.EqualFold(strings.TrimSpace(t.Enabled), "false") {
			continue
		}
		name := t.XMLName.Local
		label, ok := triggerLabels[name]
		if !ok {
			label = strings.TrimSuffix(name, "Trigger")
		}
		switch name {
		case "BootTrigger":
			pt.Boot = true
		case "LogonTrigger":
			pt.Logon = true
		case "SessionStateChangeTrigger":
			if t.StateChange != "" {
				label += " (" + t.StateChange + ")"
			}
		}
		if t.Delay != "" {
			label += " +" + t.Delay
		}
		pt.Triggers = append(pt.Triggers, label)
	}
	for _, a := range tx.Actions.Any {
		switch a.XMLName.Local {
		case "Exec":
			pt.Actions = append(pt.Actions, Action{Kind: "Exec", Command: strings.TrimSpace(a.Command),
				Arguments: strings.TrimSpace(a.Arguments), WorkingDir: strings.TrimSpace(a.WorkingDirectory)})
		case "ComHandler":
			pt.Actions = append(pt.Actions, Action{Kind: "ComHandler", ClassID: strings.TrimSpace(a.ClassID),
				Data: strings.TrimSpace(a.Data)})
		case "SendEmail":
			pt.Actions = append(pt.Actions, Action{Kind: "Email"})
		case "ShowMessage":
			pt.Actions = append(pt.Actions, Action{Kind: "Message"})
		}
	}
	return pt, nil
}

// ---------------------------------------------------------------------------
// TaskCache\Tasks\{GUID}\Actions binary blob.
//
//   u16 version (1 or 3)
//   u32 contextLen  + UTF-16LE context (principal id, e.g. "Author", "LocalSystem")
//   repeated:
//     u16 magic   0x6666 Exec | 0x7777 ComHandler | 0x8888 Email | 0x9999 Message
//     u32 idLen   + UTF-16LE id
//     Exec:       cmd, args, workdir (each u32 len + UTF-16LE); version 3 adds u16 flags
//     ComHandler: 16-byte CLSID, u32 len + UTF-16LE data
//
// Lengths are in bytes. The parser is strict; any inconsistency returns an
// error so callers never raise a mismatch from a half-parsed blob.

type blobReader struct {
	b   []byte
	off int
}

var errBlob = errors.New("malformed actions blob")

func (r *blobReader) u16() (uint16, error) {
	if r.off+2 > len(r.b) {
		return 0, errBlob
	}
	v := binary.LittleEndian.Uint16(r.b[r.off:])
	r.off += 2
	return v, nil
}

func (r *blobReader) u32() (uint32, error) {
	if r.off+4 > len(r.b) {
		return 0, errBlob
	}
	v := binary.LittleEndian.Uint32(r.b[r.off:])
	r.off += 4
	return v, nil
}

func (r *blobReader) wstr() (string, error) {
	n, err := r.u32()
	if err != nil {
		return "", err
	}
	if n%2 != 0 || int(n) > len(r.b)-r.off || n > 1<<20 {
		return "", errBlob
	}
	s := utf16le(r.b[r.off : r.off+int(n)])
	r.off += int(n)
	return strings.TrimRight(s, "\x00"), nil
}

func formatGUID(b []byte) string {
	d1 := binary.LittleEndian.Uint32(b[0:])
	d2 := binary.LittleEndian.Uint16(b[4:])
	d3 := binary.LittleEndian.Uint16(b[6:])
	var buf bytes.Buffer
	buf.WriteString("{")
	buf.WriteString(hex32(d1))
	buf.WriteString("-")
	buf.WriteString(hex16(d2))
	buf.WriteString("-")
	buf.WriteString(hex16(d3))
	buf.WriteString("-")
	for i := 8; i < 16; i++ {
		if i == 10 {
			buf.WriteString("-")
		}
		buf.WriteString(hex8(b[i]))
	}
	buf.WriteString("}")
	return strings.ToUpper(buf.String())
}

const hexdigits = "0123456789abcdef"

func hex8(v byte) string    { return string([]byte{hexdigits[v>>4], hexdigits[v&15]}) }
func hex16(v uint16) string { return hex8(byte(v>>8)) + hex8(byte(v)) }
func hex32(v uint32) string { return hex16(uint16(v>>16)) + hex16(uint16(v)) }

// parseActionsBlob parses strictly, first with the version-3 per-action
// flags field and then without it (layouts differ between Windows builds).
func parseActionsBlob(b []byte) (context string, actions []Action, err error) {
	context, actions, err = parseActionsBlobVariant(b, true)
	if err != nil {
		if c2, a2, err2 := parseActionsBlobVariant(b, false); err2 == nil {
			return c2, a2, nil
		}
	}
	return context, actions, err
}

func parseActionsBlobVariant(b []byte, v3flags bool) (context string, actions []Action, err error) {
	r := &blobReader{b: b}
	ver, err := r.u16()
	if err != nil {
		return "", nil, err
	}
	if ver < 1 || ver > 3 {
		return "", nil, errBlob
	}
	if context, err = r.wstr(); err != nil {
		return "", nil, err
	}
	for r.off < len(r.b) {
		magic, err := r.u16()
		if err != nil {
			return "", nil, err
		}
		if _, err := r.wstr(); err != nil { // action id
			return "", nil, err
		}
		switch magic {
		case 0x6666:
			var a Action
			a.Kind = "Exec"
			if a.Command, err = r.wstr(); err != nil {
				return "", nil, err
			}
			if a.Arguments, err = r.wstr(); err != nil {
				return "", nil, err
			}
			if a.WorkingDir, err = r.wstr(); err != nil {
				return "", nil, err
			}
			if ver == 3 && v3flags {
				if _, err = r.u16(); err != nil {
					return "", nil, err
				}
			}
			actions = append(actions, a)
		case 0x7777:
			if r.off+16 > len(r.b) {
				return "", nil, errBlob
			}
			a := Action{Kind: "ComHandler", ClassID: formatGUID(r.b[r.off : r.off+16])}
			r.off += 16
			if a.Data, err = r.wstr(); err != nil {
				return "", nil, err
			}
			actions = append(actions, a)
		case 0x8888, 0x9999:
			// Deprecated email / message actions: layout varies, stop here but
			// report as unparsed so no mismatch is inferred.
			return context, actions, errors.New("deprecated action type in blob")
		default:
			return "", nil, errBlob
		}
	}
	return context, actions, nil
}

// actionsEqual compares XML actions with the TaskCache actions.
func actionsEqual(xmlActs, cacheActs []Action) bool {
	prog, args := actionsDiff(xmlActs, cacheActs)
	return !prog && !args
}

// actionsDiff reports whether the program (or action set) differs, and whether
// only the arguments differ.
func actionsDiff(xmlActs, cacheActs []Action) (program, argsOnly bool) {
	norm := func(s string) string {
		s = strings.ToLower(strings.ReplaceAll(s, `"`, ""))
		s = strings.ReplaceAll(s, "%systemroot%", "%windir%")
		return strings.Join(strings.Fields(s), " ")
	}
	var a, b []Action
	for _, x := range xmlActs {
		if x.Kind == "Exec" || x.Kind == "ComHandler" {
			a = append(a, x)
		}
	}
	for _, x := range cacheActs {
		if x.Kind == "Exec" || x.Kind == "ComHandler" {
			b = append(b, x)
		}
	}
	if len(a) != len(b) {
		return true, false
	}
	for i := range a {
		if a[i].Kind != b[i].Kind {
			return true, false
		}
		if a[i].Kind == "Exec" {
			if norm(a[i].Command) != norm(b[i].Command) {
				return true, false
			}
			if norm(a[i].Arguments) != norm(b[i].Arguments) {
				argsOnly = true
			}
		} else if !strings.EqualFold(strings.Trim(a[i].ClassID, "{}"), strings.Trim(b[i].ClassID, "{}")) {
			return true, false
		}
	}
	return false, argsOnly
}

// recoverBlobActions pulls a plausible program path (and its arguments) out of
// an Actions blob whose layout was not recognised, by reading the UTF-16
// strings it contains.
func recoverBlobActions(b []byte) []Action {
	var strs []string
	var cur []uint16
	flush := func() {
		if len(cur) >= 3 {
			strs = append(strs, string(utf16.Decode(cur)))
		}
		cur = cur[:0]
	}
	for i := 0; i+1 < len(b); i += 2 {
		c := binary.LittleEndian.Uint16(b[i:])
		if c >= 0x20 && c < 0xD800 && c != 0x7F {
			cur = append(cur, c)
		} else {
			flush()
		}
	}
	flush()
	var out []Action
	for i, s := range strs {
		l := strings.ToLower(s)
		if (strings.Contains(l, `:\`) || strings.HasPrefix(l, "%") || strings.HasPrefix(l, `\\`)) && execExts[winExt(strings.Trim(s, `" `))] {
			a := Action{Kind: "Exec", Command: s}
			if i+1 < len(strs) && !strings.Contains(strs[i+1], `:\`) {
				a.Arguments = strs[i+1]
			}
			out = append(out, a)
		}
	}
	return out
}
