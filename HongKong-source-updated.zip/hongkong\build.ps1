# Build and self-sign HongKong.exe on Windows.
#   needs: Go 1.22+ on PATH (https://go.dev/dl/)
#   usage: powershell -ExecutionPolicy Bypass -File .\build.ps1
# A code-signing certificate "CN=HongKong" is created once in Cert:\CurrentUser\My
# and reused. To make Windows show the signature as trusted on THIS machine only,
# run with -TrustLocally (adds the certificate to CurrentUser Root + TrustedPublisher).
param([switch]$TrustLocally)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

go vet ./...
go test ./...
New-Item -ItemType Directory -Force dist | Out-Null
$env:GOOS = 'windows'; $env:GOARCH = 'amd64'; $env:CGO_ENABLED = '0'
go build -trimpath -ldflags "-H windowsgui -s -w" -o dist\HongKong.exe .   # icon/manifest come from rsrc_windows_amd64.syso
Remove-Item Env:GOOS, Env:GOARCH, Env:CGO_ENABLED

$cert = Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert | Where-Object Subject -eq 'CN=HongKong, O=HongKong, C=HK' | Select-Object -First 1
if (-not $cert) {
  $cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject 'CN=HongKong, O=HongKong, C=HK' `
    -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 -NotAfter (Get-Date).AddYears(5) `
    -CertStoreLocation Cert:\CurrentUser\My
}
if ($TrustLocally) {
  foreach ($store in 'Root', 'TrustedPublisher') {
    $s = New-Object System.Security.Cryptography.X509Certificates.X509Store($store, 'CurrentUser')
    $s.Open('ReadWrite'); $s.Add($cert); $s.Close()
  }
}
try {
  Set-AuthenticodeSignature dist\HongKong.exe -Certificate $cert -HashAlgorithm SHA256 -TimestampServer 'http://timestamp.digicert.com' | Out-Null
} catch {
  Write-Warning "Timestamp server unreachable, signing without timestamp"
  Set-AuthenticodeSignature dist\HongKong.exe -Certificate $cert -HashAlgorithm SHA256 | Out-Null
}
Get-AuthenticodeSignature dist\HongKong.exe | Format-List Status, StatusMessage, SignerCertificate
