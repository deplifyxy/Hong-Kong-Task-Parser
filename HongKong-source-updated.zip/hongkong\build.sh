#!/usr/bin/env bash
# Build and self-sign HongKong.exe from Linux/macOS.
#   needs: go 1.22+, openssl, osslsigncode; python3 + pillow only to regenerate the icon
#   (rsrc_windows_amd64.syso is checked in, so the icon/manifest/version are embedded either way)
#   usage: ./build.sh            -> dist/HongKong.exe (self-signed, timestamped when reachable)
# The signing key is created once in ./signing and reused, so every build carries
# the same certificate (CN=HongKong). Keep signing/HongKong.key private.
set -euo pipefail
cd "$(dirname "$0")"

go vet ./...
go test ./...
GOOS=windows GOARCH=amd64 go vet ./...

mkdir -p dist signing
if command -v python3 >/dev/null && python3 -c "import PIL" 2>/dev/null; then
  python3 tools/logo.py assets
  python3 tools/mkres.py assets 5.0.0 rsrc_windows_amd64.syso
fi
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-H windowsgui -s -w" -o dist/HongKong.unsigned.exe .

if [[ ! -f signing/HongKong.key ]]; then
  openssl req -x509 -newkey rsa:3072 -sha256 -days 1825 -nodes \
    -subj "/C=HK/O=HongKong/CN=HongKong" \
    -addext "keyUsage=critical,digitalSignature" \
    -addext "extendedKeyUsage=codeSigning" \
    -keyout signing/HongKong.key -out signing/HongKong.crt
  openssl x509 -in signing/HongKong.crt -outform DER -out signing/HongKong.cer
fi

sign() {
  osslsigncode sign -certs signing/HongKong.crt -key signing/HongKong.key \
    -n "HongKong - scheduled task & autostart forensics" -h sha256 "$@" \
    -in dist/HongKong.unsigned.exe -out dist/HongKong.exe
}
rm -f dist/HongKong.exe
sign -ts http://timestamp.digicert.com 2>/dev/null || { echo "timestamp server unreachable, signing without timestamp"; sign; }
rm -f dist/HongKong.unsigned.exe
osslsigncode verify -CAfile signing/HongKong.crt -in dist/HongKong.exe | tail -n 3
echo "built dist/HongKong.exe"
