package main

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"
)

const (
	regSZ       = 1
	regExpandSZ = 2
	regBinary   = 3
	regDWORD    = 4
	regMultiSZ  = 7
	regQWORD    = 11
)

type RegValue struct {
	Name string
	Type uint32
	Str  string
	Strs []string
	Bin  []byte
	Num  uint64
}

func (v RegValue) String() string {
	switch v.Type {
	case regSZ, regExpandSZ:
		return v.Str
	case regMultiSZ:
		return strings.Join(v.Strs, ",")
	case regDWORD, regQWORD:
		return strconv.FormatUint(v.Num, 10)
	}
	return ""
}

type FileStat struct {
	Exists  bool
	IsDir   bool
	Denied  bool // exists as far as we can tell, but access was refused
	Size    int64
	ModTime time.Time
	CTime   time.Time // creation time (Windows)
}

type TaskFile struct {
	RelPath string
	Data    []byte
	ModTime time.Time
	Err     error
}

// Platform is everything the scanner needs from Windows. The real
// implementation lives in platform_windows.go; tests use a fake.
type Platform interface {
	Getenv(string) string
	Stat(path string) FileStat
	ReadFile(path string, max int64) ([]byte, error)
	HashFile(path string) (string, error)
	ListDir(path string) ([]string, error)
	TaskFiles() ([]TaskFile, error)
	RegSubkeys(root, path string) ([]string, error)
	RegValues(root, path string) (map[string]RegValue, error) // keys lower-cased
	RegKeyModTime(root, path string) time.Time               // registry key last write time (zero when unavailable)
	CheckSignatures(paths []string) (map[string]SigInfo, error)
	WMIConsumers() ([]WMIConsumer, error)
	Hostname() string
	Username() string
	Elevated() bool
}

type ScanOptions struct {
	Tasks      bool
	Autostart  bool
	Signatures bool
	Hashes     bool
	RecentDays int
	Now        time.Time
	Progress   func(string)
}

const (
	keyTaskCache = `SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache`
	keyIFEO      = `SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options`
	keyIFEOWow   = `SOFTWARE\WOW6432Node\Microsoft\Windows NT\CurrentVersion\Image File Execution Options`
	keySilentPE  = `SOFTWARE\Microsoft\Windows NT\CurrentVersion\SilentProcessExit`
	keyWinlogon  = `SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon`
	keyWindows   = `SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows`
	keyWindowsW  = `SOFTWARE\WOW6432Node\Microsoft\Windows NT\CurrentVersion\Windows`
)

type treeEntry struct {
	path       string
	id         string
	hasSD      bool
	readOK     bool
	hasSubkeys bool
	matched    bool
	lastWrite  time.Time
}

type cacheTask struct {
	id, path, author, date, description string
	actionsBlob                         []byte
	referenced                          bool
	lastWrite                           time.Time
}

type ifeoHit struct{ key, value, data string }

type scanner struct {
	p          Platform
	o          ScanOptions
	res        Resolver
	notes      []string
	userHives  []string
	classHives []string
	ifeo       map[string]ifeoHit
	trust      *TrustDB
	rootUse    map[string][]string // root thumbprint -> files it signs
	refTimes   map[string]FileStat
	seq        int
	// for mass-anomaly suppression
	compared, sdChecked int
}

func Scan(p Platform, o ScanOptions) *ScanResult {
	start := time.Now()
	if o.Now.IsZero() {
		o.Now = time.Now()
	}
	if o.Progress == nil {
		o.Progress = func(string) {}
	}
	s := &scanner{p: p, o: o, ifeo: map[string]ifeoHit{}, rootUse: map[string][]string{}, res: Resolver{Getenv: p.Getenv, Exists: func(x string) bool {
		st := p.Stat(x)
		return st.Exists && !st.IsDir
	}}}
	r := &ScanResult{Tool: appName, Version: appVersion, Generated: o.Now, Host: p.Hostname(),
		User: p.Username(), Elevated: p.Elevated()}
	if !r.Elevated {
		s.note("Not running as administrator: TaskCache, protected task files and other users' hives may be hidden.")
	}
	s.loadHives()
	s.trust = s.loadTrust()
	s.loadIFEO()
	if o.Tasks {
		o.Progress("Reading scheduled tasks and TaskCache")
		r.Tasks = s.collectTasks()
	}
	if o.Autostart {
		o.Progress("Reading autostart locations")
		r.Autostart = s.collectAutostart()
	}
	all := append(append([]*Item{}, r.Tasks...), r.Autostart...)
	s.finalize(all, r.Tasks)
	o.Progress("Auditing trusted root certificates")
	r.Certs = s.collectCerts()
	if o.Autostart {
		r.System = s.collectSystem()
		for _, it := range r.System {
			it.computeRisk()
		}
	}
	sortItems(r.Tasks)
	sortItems(r.Autostart)
	sortItems(r.Certs)
	sortItems(r.System)
	r.Notes = s.notes
	r.summarize()
	r.Duration = time.Since(start)
	return r
}

func (s *scanner) note(n string) { s.notes = append(s.notes, n) }

func (s *scanner) newItem(kind string) *Item {
	s.seq++
	return &Item{Kind: kind, ID: fmt.Sprintf("%s-%d", kind, s.seq), Enabled: true}
}

func (s *scanner) loadHives() {
	subs, err := s.p.RegSubkeys("HKU", "")
	if err != nil || len(subs) == 0 {
		s.userHives = []string{"HKCU"}
		return
	}
	for _, k := range subs {
		if strings.HasSuffix(strings.ToLower(k), "_classes") {
			s.classHives = append(s.classHives, `HKU\`+k)
		} else {
			s.userHives = append(s.userHives, `HKU\`+k)
		}
	}
}

func splitRoot(full string) (string, string) {
	if i := strings.Index(full, `\`); i >= 0 {
		return full[:i], full[i+1:]
	}
	return full, ""
}

func joinKey(prefix, sub string) string {
	if prefix == "" {
		return sub
	}
	return prefix + `\` + sub
}

func (s *scanner) values(full, sub string) map[string]RegValue {
	root, prefix := splitRoot(full)
	v, err := s.p.RegValues(root, joinKey(prefix, sub))
	if err != nil {
		return nil
	}
	return v
}

func (s *scanner) subkeys(full, sub string) []string {
	root, prefix := splitRoot(full)
	k, _ := s.p.RegSubkeys(root, joinKey(prefix, sub))
	return k
}

func (s *scanner) loadIFEO() {
	for _, base := range []string{keyIFEO, keyIFEOWow} {
		for _, name := range s.subkeys("HKLM", base) {
			vals := s.values("HKLM", base+`\`+name)
			if _, seen := s.ifeo[strings.ToLower(name)]; seen {
				continue
			}
			if d, ok := vals["debugger"]; ok && strings.TrimSpace(d.String()) != "" {
				s.ifeo[strings.ToLower(name)] = ifeoHit{key: `HKLM\` + base + `\` + name, value: "Debugger", data: d.String()}
			}
		}
	}
	for _, name := range s.subkeys("HKLM", keySilentPE) {
		vals := s.values("HKLM", keySilentPE+`\`+name)
		if d, ok := vals["monitorprocess"]; ok && strings.TrimSpace(d.String()) != "" {
			if _, exists := s.ifeo[strings.ToLower(name)]; !exists {
				s.ifeo[strings.ToLower(name)] = ifeoHit{key: `HKLM\` + keySilentPE + `\` + name, value: "MonitorProcess", data: d.String()}
			}
		}
	}
}

// ---------------------------------------------------------------------------
// Scheduled tasks (VigilsTaskParser side)

func (s *scanner) walkTree(path string, depth int, out map[string]*treeEntry) {
	if depth > 40 {
		return
	}
	subs, err := s.p.RegSubkeys("HKLM", keyTaskCache+`\Tree`+path)
	if err != nil {
		return
	}
	for _, name := range subs {
		child := path + `\` + name
		e := &treeEntry{path: child, lastWrite: s.p.RegKeyModTime("HKLM", keyTaskCache+`\Tree`+child)}
		vals, err := s.p.RegValues("HKLM", keyTaskCache+`\Tree`+child)
		e.readOK = err == nil
		if v, ok := vals["id"]; ok {
			e.id = strings.ToUpper(strings.TrimSpace(v.String()))
		}
		_, e.hasSD = vals["sd"]
		grand, _ := s.p.RegSubkeys("HKLM", keyTaskCache+`\Tree`+child)
		e.hasSubkeys = len(grand) > 0
		out[strings.ToLower(child)] = e
		if e.hasSubkeys {
			s.walkTree(child, depth+1, out)
		}
	}
}

func (s *scanner) collectTasks() []*Item {
	tree := map[string]*treeEntry{}
	s.walkTree("", 0, tree)
	treeOK := len(tree) > 0
	if !treeOK {
		s.note("TaskCache could not be read, so hidden, mismatched and registry-only task checks were skipped.")
	}
	cache := map[string]*cacheTask{}
	for _, id := range s.subkeys("HKLM", keyTaskCache+`\Tasks`) {
		vals := s.values("HKLM", keyTaskCache+`\Tasks\`+id)
		ct := &cacheTask{id: strings.ToUpper(id), lastWrite: s.p.RegKeyModTime("HKLM", keyTaskCache+`\Tasks\`+id)}
		if v, ok := vals["path"]; ok {
			ct.path = v.String()
		}
		if v, ok := vals["actions"]; ok {
			ct.actionsBlob = v.Bin
		}
		if v, ok := vals["author"]; ok {
			ct.author = v.String()
		}
		if v, ok := vals["date"]; ok {
			ct.date = v.String()
		}
		if v, ok := vals["description"]; ok {
			ct.description = v.String()
		}
		cache[ct.id] = ct
	}

	files, err := s.p.TaskFiles()
	if err != nil {
		s.note("Task folder could not be listed: " + err.Error())
	}
	var items []*Item
	unreadable := 0
	for _, f := range files {
		it := s.newItem("task")
		it.Path = `\` + strings.TrimLeft(f.RelPath, `\`)
		it.Name = winBase(it.Path)
		it.XMLFile = winJoin(winJoin(s.res.systemRoot(), `System32\Tasks`), f.RelPath)
		it.Modified = f.ModTime
		it.Source = "XML"
		if f.Err != nil {
			unreadable++
			it.detail("XML", "unreadable: "+f.Err.Error())
		} else if pt, perr := parseTaskXML(f.Data); perr != nil {
			it.detail("XML", "parse error: "+perr.Error())
		} else {
			it.Author, it.Description, it.RegDate = pt.Author, pt.Description, pt.Date
			it.Enabled, it.Hidden = pt.Enabled, pt.Hidden
			it.RunAs, it.RunLevel = pt.RunAs, pt.RunLevel
			it.Triggers, it.BootTrigger, it.LogonTrig = pt.Triggers, pt.Boot, pt.Logon
			it.XMLActions = pt.Actions
		}
		if te, ok := tree[strings.ToLower(it.Path)]; ok {
			te.matched = true
			it.Source = "XML + TaskCache"
			s.correlate(it, te, cache)
		} else if treeOK {
			it.add(SevInfo, FlagOrphan, "XML file is not registered in TaskCache (will not run)")
		}
		items = append(items, it)
	}
	if unreadable > 0 {
		s.note(fmt.Sprintf("%d task files could not be read (access denied).", unreadable))
	}

	keys := make([]string, 0, len(tree))
	for k := range tree {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		te := tree[k]
		if te.matched || te.id == "" {
			continue
		}
		it := s.newItem("task")
		it.Path, it.Name, it.Source = te.path, winBase(te.path), "TaskCache only"
		xml := winJoin(winJoin(s.res.systemRoot(), `System32\Tasks`), strings.TrimLeft(te.path, `\`))
		if st := s.p.Stat(xml); st.Exists || st.Denied {
			// Protected folder (e.g. UpdateOrchestrator, WaaSMedic): the XML is there, we just can't list it.
			it.Source = "TaskCache (XML protected)"
			it.XMLFile = xml
			it.add(SevInfo, 0, "Task XML exists but is in a folder administrators cannot read")
		} else {
			it.add(SevHigh, FlagTaskCacheMismatch, "Registered in TaskCache with no XML file on disk")
		}
		// The XML file is gone, so the registry key last write is the only
		// reliable "when was this planted / tampered with" timestamp.
		if lw := te.lastWrite; !lw.IsZero() {
			it.Modified = lw
			it.detail("Registry last write", lw.Format("2006-01-02 15:04:05"))
		}
		s.correlate(it, te, cache)
		items = append(items, it)
	}
	if treeOK {
		for _, ct := range cache {
			if ct.referenced {
				continue
			}
			it := s.newItem("task")
			it.Path = ct.path
			if it.Path == "" {
				it.Path = `\(unknown) ` + ct.id
			}
			it.Name, it.Source, it.TaskCacheID = winBase(it.Path), `TaskCache\Tasks only`, ct.id
			it.Author, it.RegDate, it.Description = ct.author, ct.date, ct.description
			if lw := ct.lastWrite; !lw.IsZero() {
				it.Modified = lw
				it.detail("Registry last write", lw.Format("2006-01-02 15:04:05"))
			}
			it.add(SevInfo, FlagOrphan, `TaskCache\Tasks entry is not referenced by any Tree key`)
			s.applyBlob(it, ct)
			items = append(items, it)
		}
	}
	for _, it := range items {
		s.analyzeTask(it)
	}
	return items
}

func (s *scanner) correlate(it *Item, te *treeEntry, cache map[string]*cacheTask) {
	if te.id == "" {
		if te.readOK {
			it.add(SevHigh, FlagTreeMissingID, "TaskCache Tree key has no Id value")
		}
		return
	}
	it.TaskCacheID = te.id
	it.detail("TaskCache Id", te.id)
	if lw := te.lastWrite; !lw.IsZero() && it.Modified.IsZero() {
		it.Modified = lw // XML mod time missing: fall back to the registry
	}
	if lw := te.lastWrite; !lw.IsZero() {
		it.detail("Registry last write", lw.Format("2006-01-02 15:04:05"))
	}
	if te.readOK {
		s.sdChecked++
		if !te.hasSD {
			it.add(SevHigh, FlagSDMissing, "Security descriptor removed from the Tree key: task is hidden from schtasks and Task Scheduler")
		}
	}
	ct, ok := cache[te.id]
	if !ok {
		if len(cache) > 0 {
			it.add(SevInfo, FlagTaskCacheMismatch, `Tree Id points to a missing TaskCache\Tasks entry (broken registration)`)
		}
		return
	}
	ct.referenced = true
	if ct.path != "" && !strings.EqualFold(ct.path, te.path) {
		it.add(SevInfo, FlagTaskCacheMismatch, "TaskCache path differs from Tree path")
		it.detail("TaskCache detail", `Tasks\`+te.id+" Path = "+ct.path)
	}
	if it.Author == "" {
		it.Author, it.RegDate, it.Description = ct.author, ct.date, ct.description
	}
	s.applyBlob(it, ct)
}

func (s *scanner) applyBlob(it *Item, ct *cacheTask) {
	if len(ct.actionsBlob) == 0 {
		return
	}
	ctx, acts, err := parseActionsBlob(ct.actionsBlob)
	if err != nil {
		if len(it.XMLActions) == 0 {
			if rec := recoverBlobActions(ct.actionsBlob); len(rec) > 0 {
				it.TaskCacheActions = rec
				it.detail("TaskCache actions", "recovered from an unrecognised blob layout")
				return
			}
		}
		it.detail("TaskCache actions", "not parsed ("+err.Error()+")")
		return
	}
	it.TaskCacheActions = acts
	if ctx != "" {
		it.detail("TaskCache context", ctx)
	}
	if len(it.XMLActions) > 0 {
		s.compared++
		if prog, argsOnly := actionsDiff(it.XMLActions, acts); prog || argsOnly {
			if prog {
				it.add(SevHigh, FlagActionMismatch, "XML / TaskCache action mismatch: the registry runs a different program than the task XML shows")
			} else {
				it.add(SevMedium, FlagActionMismatch, "XML / TaskCache arguments differ: the registry passes different arguments than the task XML shows")
			}
			it.detail("XML action(s)", joinActions(it.XMLActions, "\n"))
			it.detail("TaskCache action(s) (effective)", joinActions(acts, "\n"))
		}
	}
}

func joinActions(a []Action, sep string) string {
	var parts []string
	for _, x := range a {
		parts = append(parts, x.display())
	}
	return strings.Join(parts, sep)
}

func (it *Item) effectiveActions() []Action {
	if len(it.TaskCacheActions) > 0 {
		return it.TaskCacheActions
	}
	return it.XMLActions
}

func (s *scanner) analyzeTask(it *Item) {
	acts := it.effectiveActions()
	it.Command = joinActions(acts, " ; ")
	for _, a := range acts {
		switch a.Kind {
		case "Exec":
			s.analyzeExec(it, a.Command, a.Arguments, a.WorkingDir)
		case "ComHandler":
			s.analyzeCOM(it, a.ClassID)
		}
	}
	if it.Hidden {
		it.add(SevInfo, FlagHiddenSetting, "Task has the Hidden setting")
	}
	if isPrivileged(it.RunAs, it.RunLevel) {
		it.Flags |= FlagHighPriv
	}
	// Startup scheduling context: hosts / LOLBins wired directly into boot or
	// logon triggers are the classic persistence shape.
	if it.Kind == "task" && (it.BootTrigger || it.LogonTrig) {
		var hosts []string
		seenHost := map[string]bool{}
		for _, a := range acts {
			if a.Kind != "Exec" {
				continue
			}
			b := strings.ToLower(winBase(s.res.Resolve(a.Command, a.WorkingDir)))
			if execHosts[b] && !seenHost[b] {
				seenHost[b] = true
				hosts = append(hosts, b)
			}
		}
		if len(hosts) > 0 {
			it.Flags |= FlagExecHost
			it.add(SevMedium, FlagExecHost, "Boot/logon trigger starts a script host or LOLBin directly: "+strings.Join(hosts, ", "))
		}
	}
}

func (s *scanner) analyzeExec(it *Item, cmd, args, workDir string) {
	path := s.res.Resolve(cmd, workDir)
	base := strings.ToLower(winBase(path))
	if execHosts[base] {
		it.add(SevInfo, FlagExecHost, "Runs through script host / LOLBin "+base)
	}
	if isMasquerading(path) {
		it.add(SevHigh, FlagMasquerade, "System binary name outside the Windows directory: "+path)
	}
	for _, trick := range pathTricks(path) {
		it.add(trick.sev, FlagPathTrick, trick.text)
	}
	ext := winExt(path)
	if ext != "" && !execExts[ext] {
		it.add(SevMedium, FlagUnusualExt, "Action file has unusual extension "+ext)
	}
	if hit, ok := s.ifeo[base]; ok && it.Kind == "task" {
		it.add(SevHigh, FlagIFEO, "IFEO "+hit.value+" redirects "+base+" to "+hit.data)
		it.detail("IFEO registry path", hit.key)
	}
	it.Targets = append(it.Targets, Target{Role: "action", Raw: cmd, Path: path})

	staticInput := cmd + " " + args
	if ext == ".lnk" {
		it.add(SevMedium, FlagHeurLnk, "Action launches a shortcut (.lnk)")
		if b, err := s.p.ReadFile(path, 1<<20); err == nil {
			if li, err := parseLnk(b); err == nil && li.Target != "" {
				tgt := li.Target
				if !isAbsWin(expandWinEnv(tgt, s.p.Getenv)) {
					tgt = winJoin(winDir(path), tgt)
				}
				lp := s.res.Resolve(tgt, li.WorkingDir)
				it.Targets = append(it.Targets, Target{Role: "lnk-target", Raw: li.Target, Path: lp})
				it.detail("LNK target", strings.TrimSpace(li.Target+" "+li.Arguments))
				staticInput += " " + li.Arguments
				if execHosts[strings.ToLower(winBase(lp))] {
					it.add(SevInfo, FlagExecHost, "Shortcut runs script host "+strings.ToLower(winBase(lp)))
				}
				for _, f := range argumentFiles(li.Arguments) {
					fp := s.res.Resolve(normalizeDllArg(f), li.WorkingDir)
					it.Targets = append(it.Targets, Target{Role: "argument", Raw: f, Path: fp})
					it.Flags |= FlagHeurArgs
				}
			}
		}
	}
	argStart := len(it.Targets)
	for _, f := range argumentFiles(args) {
		fp := s.res.Resolve(normalizeDllArg(f), workDir)
		it.Targets = append(it.Targets, Target{Role: "argument", Raw: f, Path: fp})
		it.Flags |= FlagHeurArgs
	}
	for _, h := range staticAnalysis(staticInput) {
		sev := SevInfo
		if h.strong {
			sev = SevHigh
		}
		it.add(sev, FlagStaticAnalysis, "Command line: "+h.reason)
	}
	// A bare "script host / LOLBin" note alone was never enough: tasks that
	// stage payloads or hide behind conhost/cmd walked past SevInfo. Score the
	// actual shapes here; score() escalates further once signatures are in.
	if execHosts[base] {
		for _, q := range execHostQuirks(base, args) {
			it.add(q.sev, FlagExecHost, q.text)
		}
		if host, rest := s.res.chainedHost(base, args); host != "" {
			it.add(SevMedium, FlagExecHost, "Host "+base+" chains into "+host+": "+rest)
		}
		for _, t := range it.Targets[argStart:] {
			if isUserWritable(t.Path) {
				it.add(SevMedium, FlagExecHost, base+" runs a payload from a user-writable folder: "+t.Path)
			}
		}
	}
	if e := shannon(args); e > it.Entropy {
		it.Entropy = e
	}
	if len(args) >= 80 && it.Entropy >= 5.2 {
		it.add(SevInfo, FlagStaticAnalysis, fmt.Sprintf("Command line: high-entropy arguments (%.2f bits/char)", it.Entropy))
	}
}

func (s *scanner) comServer(full, sub string) string {
	for _, k := range []string{"InprocServer32", "LocalServer32"} {
		if v, ok := s.values(full, sub+`\`+k)[""]; ok && strings.TrimSpace(v.String()) != "" {
			return v.String()
		}
	}
	return ""
}

func (s *scanner) analyzeCOM(it *Item, clsid string) {
	id := "{" + strings.Trim(strings.ToUpper(clsid), "{}") + "}"
	if server := s.comServer("HKLM", `SOFTWARE\Classes\CLSID\`+id); server != "" {
		exe, _ := s.res.SplitCommandLine(server)
		it.Targets = append(it.Targets, Target{Role: "com-server", Raw: server, Path: s.res.Resolve(exe, "")})
		it.detail("COM server", server)
	} else {
		it.detail("COM server", "CLSID "+id+" not registered in HKLM")
	}
	for _, h := range s.classHives {
		if srv := s.comServer(h, `CLSID\`+id); srv != "" {
			exe, _ := s.res.SplitCommandLine(srv)
			it.add(SevHigh, FlagCOMHijack, "COM handler "+id+" is overridden in user hive "+h)
			it.Targets = append(it.Targets, Target{Role: "com-server", Raw: srv, Path: s.res.Resolve(exe, "")})
			it.detail("COM override", h+`\CLSID\`+id+" -> "+srv)
		}
	}
}

// ---------------------------------------------------------------------------
// Autostart (ClubhouseAnchor side)

var runKeys = []struct{ sub, label string }{
	{`Software\Microsoft\Windows\CurrentVersion\Run`, "Run"},
	{`Software\Microsoft\Windows\CurrentVersion\RunOnce`, "RunOnce"},
	{`Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run`, "Policies Run"},
	{`Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run`, "Run (WOW64)"},
	{`Software\WOW6432Node\Microsoft\Windows\CurrentVersion\RunOnce`, "RunOnce (WOW64)"},
}

func (s *scanner) collectAutostart() []*Item {
	var items []*Item
	for _, root := range append([]string{"HKLM"}, s.userHives...) {
		for _, rk := range runKeys {
			vals := s.values(root, rk.sub)
			for _, n := range sortedKeys(vals) {
				v := vals[n]
				if (v.Type != regSZ && v.Type != regExpandSZ) || strings.TrimSpace(v.Str) == "" {
					continue
				}
				it := s.newItem("autostart")
				it.Location, it.Path, it.Name = rk.label, root+`\`+rk.sub, v.Name
				if it.Name == "" {
					it.Name = "(Default)"
				}
				s.analyzeCommandLine(it, v.Str)
				items = append(items, it)
			}
		}
	}
	items = append(items, s.winlogon()...)
	items = append(items, s.appInit()...)
	items = append(items, s.ifeoItems()...)
	items = append(items, s.startupFolders()...)
	s.o.Progress("Reading services and drivers")
	items = append(items, s.collectServices()...)
	items = append(items, s.extraAutostart()...)
	items = append(items, s.wmiItems()...)
	return items
}

func sortedKeys(m map[string]RegValue) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

func (s *scanner) analyzeCommandLine(it *Item, line string) {
	it.Command = line
	exe, args := s.res.SplitCommandLine(line)
	s.analyzeExec(it, exe, args, "")
}

func (s *scanner) winlogon() []*Item {
	var items []*Item
	vals := s.values("HKLM", keyWinlogon)
	sr := strings.ToLower(s.res.systemRoot())
	isDefault := map[string]func(string) bool{
		"shell": func(e string) bool {
			e = strings.ToLower(unquote(e))
			return e == "explorer.exe" || e == sr+`\explorer.exe`
		},
		"userinit": func(e string) bool {
			e = strings.ToLower(unquote(e))
			return e == "userinit.exe" || e == sr+`\system32\userinit.exe`
		},
	}
	for _, name := range []string{"shell", "userinit"} {
		v, ok := vals[name]
		if !ok {
			continue
		}
		for _, entry := range strings.Split(v.String(), ",") {
			if entry = strings.TrimSpace(entry); entry == "" {
				continue
			}
			it := s.newItem("autostart")
			it.Location, it.Path, it.Name = "Winlogon", `HKLM\`+keyWinlogon, v.Name
			s.analyzeCommandLine(it, entry)
			if !isDefault[name](entry) {
				it.add(SevHigh, FlagNonDefault, "Winlogon "+v.Name+" contains a non-default entry")
			}
			items = append(items, it)
		}
	}
	for _, h := range s.userHives {
		if v, ok := s.values(h, `Software\Microsoft\Windows NT\CurrentVersion\Winlogon`)["shell"]; ok && strings.TrimSpace(v.String()) != "" {
			it := s.newItem("autostart")
			it.Location, it.Path, it.Name = "Winlogon (user)", h+`\Software\Microsoft\Windows NT\CurrentVersion\Winlogon`, v.Name
			s.analyzeCommandLine(it, v.String())
			it.add(SevHigh, FlagNonDefault, "Per-user Winlogon Shell override")
			items = append(items, it)
		}
	}
	return items
}

func (s *scanner) appInit() []*Item {
	var items []*Item
	for _, k := range []string{keyWindows, keyWindowsW} {
		vals := s.values("HKLM", k)
		v, ok := vals["appinit_dlls"]
		if !ok || strings.TrimSpace(v.String()) == "" {
			continue
		}
		l, ok := vals["loadappinit_dlls"]
		active := ok && l.Num != 0
		for _, dll := range strings.FieldsFunc(v.String(), func(r rune) bool { return r == ',' || r == ' ' }) {
			it := s.newItem("autostart")
			it.Location, it.Path, it.Name = "AppInit_DLLs", `HKLM\`+k, "AppInit_DLLs"
			s.analyzeCommandLine(it, dll)
			if active {
				it.add(SevHigh, FlagNonDefault, "AppInit_DLLs is active: the DLL loads into every GUI process")
			} else {
				it.add(SevInfo, FlagNonDefault, "AppInit_DLLs is set but inactive (LoadAppInit_DLLs=0)")
			}
			items = append(items, it)
		}
	}
	return items
}

func (s *scanner) ifeoItems() []*Item {
	var items []*Item
	names := make([]string, 0, len(s.ifeo))
	for k := range s.ifeo {
		names = append(names, k)
	}
	sort.Strings(names)
	for _, n := range names {
		hit := s.ifeo[n]
		it := s.newItem("autostart")
		it.Location, it.Path, it.Name = "IFEO", hit.key, n
		s.analyzeCommandLine(it, hit.data)
		it.add(SevHigh, FlagIFEO, "IFEO "+hit.value+" hijacks every launch of "+n)
		items = append(items, it)
	}
	return items
}

func (s *scanner) startupFolders() []*Item {
	var dirs []string
	if pd := s.p.Getenv("ProgramData"); pd != "" {
		dirs = append(dirs, winJoin(pd, `Microsoft\Windows\Start Menu\Programs\StartUp`))
	}
	drive := s.p.Getenv("SystemDrive")
	if drive == "" {
		drive = "C:"
	}
	if users, err := s.p.ListDir(drive + `\Users`); err == nil {
		for _, u := range users {
			dirs = append(dirs, winJoin(winJoin(drive+`\Users`, u), `AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup`))
		}
	}
	var items []*Item
	for _, d := range dirs {
		names, err := s.p.ListDir(d)
		if err != nil {
			continue
		}
		for _, n := range names {
			if strings.EqualFold(n, "desktop.ini") {
				continue
			}
			full := winJoin(d, n)
			st := s.p.Stat(full)
			if st.IsDir {
				continue
			}
			it := s.newItem("autostart")
			it.Location, it.Path, it.Name, it.Modified = "Startup folder", d, n, st.ModTime
			if winExt(n) == ".lnk" {
				b, err := s.p.ReadFile(full, 1<<20)
				var li *LnkInfo
				if err == nil {
					li, err = parseLnk(b)
				}
				if err != nil || li.Target == "" {
					it.Command = full
					it.detail("Shortcut", "could not be parsed")
					it.Targets = append(it.Targets, Target{Role: "action", Raw: full, Path: full})
				} else {
					it.Command = strings.TrimSpace(`"` + li.Target + `" ` + li.Arguments)
					it.detail("Shortcut", full)
					s.analyzeExec(it, li.Target, li.Arguments, li.WorkingDir)
				}
			} else {
				it.Command = full
				s.analyzeExec(it, full, "", "")
				it.add(SevInfo, 0, "File placed directly in the Startup folder")
			}
			items = append(items, it)
		}
	}
	return items
}

// ---------------------------------------------------------------------------
// Signatures, hashes, scoring

func (s *scanner) finalize(items, tasks []*Item) {
	stats := map[string]FileStat{}
	var toSign []string
	for _, it := range items {
		for i := range it.Targets {
			t := &it.Targets[i]
			if t.Path == "" {
				continue
			}
			k := strings.ToLower(t.Path)
			st, ok := stats[k]
			if !ok {
				st = s.p.Stat(t.Path)
				stats[k] = st
				if st.Exists && !st.IsDir {
					toSign = append(toSign, t.Path)
				}
			}
			t.Exists = st.Exists && !st.IsDir
			t.Size = st.Size
			t.ModTime, t.CTime = st.ModTime, st.CTime
			t.UserWritable = isUserWritable(t.Path)
		}
	}
	sigs := map[string]SigInfo{}
	if s.o.Signatures && len(toSign) > 0 {
		s.o.Progress(fmt.Sprintf("Verifying signatures of %d files", len(toSign)))
		got, err := s.p.CheckSignatures(toSign)
		if err != nil {
			s.note("Windows signature check unavailable (" + err.Error() + "); HongKong's built-in verifier was used instead.")
		}
		for k, v := range got {
			sigs[strings.ToLower(k)] = v
		}
		s.o.Progress("Inspecting embedded signatures")
		for _, p := range toSign {
			k := strings.ToLower(p)
			base, ok := sigs[k]
			if !ok {
				base = SigInfo{Status: SigUnknown}
			}
			var es EmbeddedSig
			if st := stats[k]; st.Size <= 200<<20 {
				if b, err := s.p.ReadFile(p, 200<<20); err == nil && int64(len(b)) == st.Size && len(b) > 2 && b[0] == 'M' && b[1] == 'Z' {
					es = VerifyEmbedded(b)
					base.Smuggled = es.Smuggled
					base.CompileTime = peTimestamp(b)
					if base.Company == "" && base.OriginalName == "" {
						base.Company, base.OriginalName = versionStrings(b)
					}
				}
			}
			cl := classify(base, es, s.trust, s.o.Now)
			cl.Smuggled, cl.CompileTime = base.Smuggled, base.CompileTime
			sigs[k] = cl
			if rt := sigs[k].RootThumb; rt != "" {
				s.rootUse[rt] = append(s.rootUse[rt], p)
			}
		}
	}
	hashes := map[string]string{}
	if s.o.Hashes {
		s.o.Progress(fmt.Sprintf("Hashing %d files", len(toSign)))
		for _, p := range toSign {
			if stats[strings.ToLower(p)].Size > 256<<20 {
				continue
			}
			if h, err := s.p.HashFile(p); err == nil {
				hashes[strings.ToLower(p)] = h
			}
		}
	}
	s.o.Progress("Scoring")
	for _, it := range items {
		s.score(it, sigs, hashes)
	}
	s.suppressMassAnomalies(items, tasks)
	for _, it := range items {
		it.computeRisk()
	}
}

func (s *scanner) score(it *Item, sigs map[string]SigInfo, hashes map[string]string) {
	sr := s.res.systemRoot()
	allTrusted, allMS := len(it.Targets) > 0, len(it.Targets) > 0
	payloadUntrustedWritable := false
	payloadMissingWritable := false
	for i := range it.Targets {
		t := &it.Targets[i]
		k := strings.ToLower(t.Path)
		t.SHA256 = hashes[k]
		switch {
		case t.Path == "":
			t.Sig = SigInfo{Status: SigUnknown}
		case !t.Exists:
			t.Sig = SigInfo{Status: SigNotOnDisk}
		case !s.o.Signatures:
			t.Sig = SigInfo{Status: SigSkipped}
		default:
			if si, ok := sigs[k]; ok {
				t.Sig = si
			} else {
				t.Sig = SigInfo{Status: SigUnknown}
			}
		}
		if t.Sig.Status == SigUnsigned && binaryExts[winExt(t.Path)] && inWindowsDir(t.Path, sr) {
			t.Sig.Status = SigUnsignedWinDir
		}
		if !t.Sig.trusted() {
			allTrusted = false
		}
		if !(t.Sig.trusted() && t.Sig.IsMicrosoft) {
			allMS = false
		}
		s.scoreTarget(it, t)
		// Exec-host payload audit: a missing payload is as telling as a bad
		// signature one (staged tasks run the host before anything is dropped),
		// and only genuinely signed payloads keep the host quiet.
		if t.Role == "argument" && t.UserWritable {
			switch {
			case !t.Exists:
				payloadMissingWritable = true
			case t.Sig.trusted():
			case knownBad(t.Sig) || t.Sig.Status == SigUnknown || t.Sig.Status == SigSkipped:
				payloadUntrustedWritable = true
			}
		}
	}

	// Trust-aware adjustments: these are where most false positives used to come from.
	if allTrusted {
		if it.has(FlagExecHost) {
			it.adjust(FlagTaskCacheMismatch, capAt(SevMedium)) // registry-only, runs a script host
		} else {
			it.adjust(FlagTaskCacheMismatch, capAt(SevInfo)) // registry-only but runs a trusted program
		}
		it.adjust(FlagUnusualExt, capAt(SevInfo))
	}
	if allMS {
		// A genuine Microsoft binary under a system name (WinSxS / servicing copies) is fine;
		// a renamed system binary stays Suspicious.
		for i := range it.Findings {
			if strings.HasPrefix(it.Findings[i].Text, "System binary name outside") {
				it.Findings[i].Sev = SevInfo
			}
		}
		if strings.HasPrefix(strings.ToLower(it.Path), `\microsoft\`) {
			it.adjust(FlagStaticAnalysis, func(s Sev) Sev {
				if s == SevMedium {
					return SevInfo
				}
				return s
			})
		}
	}
	if it.Location == "IFEO" && allTrusted {
		it.adjust(FlagIFEO, capAt(SevMedium)) // e.g. Process Explorer replacing Task Manager
	}
	if it.has(FlagCOMHijack) {
		trustedOverride := true
		for _, t := range it.Targets {
			if t.Role == "com-server" && !t.Sig.trusted() {
				trustedOverride = false
			}
		}
		if trustedOverride {
			it.adjust(FlagCOMHijack, capAt(SevInfo))
		}
	}
	if it.Hidden && anyKnownBad(it) {
		it.adjust(FlagHiddenSetting, func(Sev) Sev { return SevMedium })
		for i := range it.Findings {
			if it.Findings[i].Flag == FlagHiddenSetting {
				it.Findings[i].Text = "Hidden task running an untrusted file"
			}
		}
	}
	if it.Source == "TaskCache only" {
		msFolder := strings.HasPrefix(strings.ToLower(it.Path), `\microsoft\`)
		switch {
		case len(it.Targets) == 0 && msFolder:
			it.drop(FlagTaskCacheMismatch)
			it.add(SevInfo, FlagOrphan, "Stale TaskCache registration (no XML and nothing runnable): leftover from a Windows upgrade")
		case len(it.Targets) == 0:
			it.adjust(FlagTaskCacheMismatch, capAt(SevMedium))
		case allMS:
			it.drop(FlagTaskCacheMismatch)
			it.add(SevInfo, FlagOrphan, "TaskCache-only registration that runs a genuine Microsoft file (leftover)")
		case allTrusted:
			it.adjust(FlagTaskCacheMismatch, capAt(SevMedium))
		}
	}
	if it.Kind == "task" && strings.HasPrefix(strings.ToLower(it.Path), `\microsoft\`) && anyKnownBad(it) {
		for _, t := range it.Targets {
			if knownBad(t.Sig) && binaryExts[winExt(t.Path)] && t.Exists {
				it.add(SevMedium, 0, "Non-Microsoft program hiding in a Microsoft task folder: "+winBase(t.Path))
				break
			}
		}
	}
	if it.has(FlagExecHost) {
		startup := it.Kind == "task" && (it.BootTrigger || it.LogonTrig)
		switch {
		case payloadUntrustedWritable:
			it.add(SevHigh, FlagExecHost, "Script host runs an untrusted payload from a user-writable folder")
		case payloadMissingWritable && startup:
			it.add(SevHigh, FlagExecHost, "Startup task points a script host at a missing payload in a writable folder (staged drop)")
		case payloadMissingWritable:
			it.add(SevMedium, FlagExecHost, "Script host points at a missing payload in a user-writable folder (staged drop?)")
		case startup && !allTrusted:
			// Boot/logon trigger + exec host, and the run chain is not fully
			// signed: escalate the startup-trigger finding to Suspicious.
			upgraded := false
			for i := range it.Findings {
				if strings.HasPrefix(it.Findings[i].Text, "Boot/logon trigger starts a script host") {
					it.Findings[i].Sev = SevHigh
					upgraded = true
				}
			}
			if !upgraded {
				it.add(SevHigh, FlagExecHost, "Boot/logon task runs a script host or LOLBin with untrusted files")
			}
		}
	}

	if s.o.RecentDays > 0 && !allTrusted {
		cut := s.o.Now.AddDate(0, 0, -s.o.RecentDays)
		recent := !it.Modified.IsZero() && it.Modified.After(cut)
		if t, err := time.Parse("2006-01-02T15:04:05", trimFrac(it.RegDate)); err == nil && t.After(cut) {
			recent = true
		}
		if recent {
			it.add(SevInfo, FlagRecent, fmt.Sprintf("Created or changed in the last %d days", s.o.RecentDays))
		}
	}

	if it.Kind == "task" && len(it.Targets) == 0 {
		it.adjust(FlagSDMissing, capAt(SevInfo)) // hidden, but there is nothing to run
	}
	if it.Location == "Driver" && len(it.Targets) > 0 {
		t := it.Targets[0]
		switch {
		case !t.Exists:
			it.drop(FlagNotOnDisk)
			it.add(SevInfo, FlagNotOnDisk, "Driver file not present (service entry left behind)")
		case t.Sig.Status == SigUnsigned:
			it.add(SevHigh, FlagDriver|FlagUnsigned, "Unsigned kernel driver: it only loads with test signing or an exploit")
		}
	}
	accessibilityCheck(it)
	if len(it.Targets) > 0 {
		p := it.Targets[0]
		for _, t := range it.Targets[1:] {
			if sigSeverity(t.Sig.Status) > sigSeverity(p.Sig.Status) {
				p = t
			}
		}
		it.SignatureStatus, it.Signer, it.SHA256 = p.Sig.Status, firstCN(p.Sig.Signer), p.SHA256
	} else {
		it.SignatureStatus = "-"
	}
}

// knownBad is a definite negative verdict; "Unknown"/"Not checked" (verification
// unavailable) never escalates an item on its own.
func knownBad(s SigInfo) bool { return sigSeverity(s.Status) >= 2 }

func anyKnownBad(it *Item) bool {
	for _, t := range it.Targets {
		if knownBad(t.Sig) {
			return true
		}
	}
	return false
}

func capAt(max Sev) func(Sev) Sev {
	return func(s Sev) Sev {
		if s > max {
			return max
		}
		return s
	}
}

// scoreTarget applies the ClubhouseAnchor-style signature verdicts to one file.
func (s *scanner) scoreTarget(it *Item, t *Target) {
	what := roleLabel[t.Role]
	ext := winExt(t.Path)
	switch t.Sig.Status {
	case SigNotOnDisk:
		if it.Enabled && it.has(FlagHighPriv) && t.UserWritable && t.Role == "action" {
			it.add(SevMedium, FlagNotOnDisk, "Privileged task points to a missing file in a writable folder (anyone could plant it): "+t.Path)
		} else {
			it.add(SevInfo, FlagNotOnDisk, "Missing "+what+" (leftover from an uninstalled app?): "+t.Path)
		}
	case SigUnsignedWinDir:
		it.add(SevHigh, FlagBadSignature, "Unsigned "+what+" inside the Windows directory (Windows files are always signed: likely replaced or dropped)")
	case SigUnsigned:
		switch {
		case scriptExts[ext] && !t.UserWritable:
			it.add(SevInfo, FlagUnsigned, "Unsigned script "+winBase(t.Path))
		case scriptExts[ext]:
			it.add(SevMedium, FlagUnsigned, "Unsigned script in a user-writable folder: "+t.Path)
		default:
			it.add(SevMedium, FlagUnsigned, "Unsigned "+what+" "+winBase(t.Path))
		}
	case SigUnverified:
		it.add(SevMedium, FlagUnsigned, "Signature on "+what+" could not be verified ("+t.Sig.RawStatus+")")
	case SigForged:
		it.add(SevHigh, FlagSelfSigned|FlagImpersonation, "Forged signature on "+what+": claims \""+firstCN(t.Sig.Signer)+
			"\" but chains to a fake root ("+firstCN(t.Sig.ChainRoot)+", "+t.Sig.RootThumb+")")
	case SigLocalRoot:
		fresh := !t.Sig.RootNotBefore.IsZero() && t.Sig.RootNotBefore.After(s.o.Now.AddDate(-3, 0, 0))
		if t.Sig.UserRoot != "" || fresh || impersonatedVendor(t.Sig.ChainRoot) != "" {
			it.add(SevHigh, FlagSelfSigned, "Self-made signature on "+what+": "+t.Sig.Note+" ("+firstCN(t.Sig.ChainRoot)+")")
		} else {
			it.add(SevMedium, FlagSelfSigned, "Signature on "+what+" chains to a root outside Microsoft's root program (old or private CA: "+firstCN(t.Sig.ChainRoot)+")")
		}
		if v := impersonatedVendor(t.Sig.Signer); v != "" {
			it.add(SevHigh, FlagImpersonation, "Locally trusted certificate claims to be "+v+": "+firstCN(t.Sig.Signer))
		}
	case SigSelfSigned, SigSelfTrusted, SigUntrustedRoot:
		it.add(SevHigh, FlagSelfSigned, t.Sig.Status+" "+what+" (signer: "+firstCN(t.Sig.Signer)+")")
		if v := impersonatedVendor(t.Sig.Signer); v != "" {
			it.add(SevHigh, FlagImpersonation, "Untrusted certificate claims to be "+v+": "+firstCN(t.Sig.Signer))
		}
	case SigExpired:
		it.add(SevInfo, 0, "Signature on "+what+" uses an expired certificate without timestamp ("+firstCN(t.Sig.Signer)+")")
	case SigHashMismatch:
		it.add(SevHigh, FlagBadSignature, "Tampered "+what+": file was modified after it was signed")
	case SigBadCert:
		it.add(SevHigh, FlagBadSignature, "Tampered "+what+": certificate signature is invalid")
	case SigRevoked:
		it.add(SevHigh, FlagBadSignature, "Signer certificate of "+what+" is revoked or explicitly distrusted")
	}
	if t.Sig.Smuggled > 0 {
		it.add(SevHigh, FlagSmuggled, fmt.Sprintf("%d bytes of data hidden inside the signature block of %s (not covered by the signature)", t.Sig.Smuggled, winBase(t.Path)))
	}
	if t.Exists && !t.Sig.trusted() && sigSeverity(t.Sig.Status) >= 2 {
		if ref := s.clonedTimesFrom(t); ref != "" {
			it.add(SevHigh, FlagTimestomp, "File timestamps were copied from "+ref+" (timestomping)")
		} else if ct := t.Sig.CompileTime; !ct.IsZero() && ct.Year() >= 2015 && ct.Before(s.o.Now.Add(24*time.Hour)) &&
			!t.ModTime.IsZero() && t.ModTime.Before(ct.Add(-48*time.Hour)) {
			it.add(SevMedium, FlagTimestomp, "File date ("+t.ModTime.Format("2006-01-02")+") is older than when it was built ("+ct.Format("2006-01-02")+"): timestamps were faked")
		}
	}
	// Version info that claims Microsoft on a file Microsoft did not sign.
	if t.Exists && strings.Contains(strings.ToLower(t.Sig.Company), "microsoft") && !t.Sig.IsMicrosoft && knownBad(t.Sig) {
		it.add(SevHigh, FlagImpersonation, "Version info claims \""+t.Sig.Company+"\" ("+t.Sig.OriginalName+") but the file is not signed by Microsoft")
	}
	// Renamed system binary: Microsoft-signed file whose original name is a LOLBin.
	if orig := normOriginalName(t.Sig.OriginalName); orig != "" && t.Sig.IsMicrosoft && lolbinOriginal[orig] &&
		!strings.EqualFold(winBase(t.Path), orig) && !(orig == "pwsh.dll" && strings.EqualFold(winBase(t.Path), "pwsh.exe")) {
		it.add(SevHigh, FlagMasquerade, "Renamed system binary: "+winBase(t.Path)+" is really "+orig)
	}
	if t.UserWritable && t.Exists {
		switch {
		case t.Sig.trusted():
			it.add(SevInfo, FlagUserWritable, "Runs from a user-writable folder (signed by "+firstCN(t.Sig.Signer)+")")
		case it.has(FlagHighPriv) && knownBad(t.Sig) && t.Sig.Status != SigUnsigned && t.Sig.Status != SigUnverified:
			it.add(SevHigh, FlagUserWritable, "Privileged task runs an untrusted file from a user-writable folder: "+winDir(t.Path))
		case it.has(FlagHighPriv) && knownBad(t.Sig):
			it.add(SevMedium, FlagUserWritable, "Runs with high privileges from a folder normal users can write to: "+winDir(t.Path))
		default:
			it.add(SevMedium, FlagUserWritable, "Untrusted file in a user-writable folder: "+winDir(t.Path))
		}
	}
	if t.Role == "argument" && t.Exists && knownBad(t.Sig) && !scriptExts[ext] {
		it.add(SevMedium, FlagHeurArgs, "Arguments load untrusted "+winBase(t.Path))
	}
}

// suppressMassAnomalies switches off registry heuristics that fire on an
// implausible share of tasks (unknown TaskCache format or access problems).
func (s *scanner) suppressMassAnomalies(items, tasks []*Item) {
	count := func(flag uint64) int {
		n := 0
		for _, it := range tasks {
			if it.has(flag) {
				n++
			}
		}
		return n
	}
	if n := count(FlagActionMismatch); n > 5 && float64(n) > 0.25*float64(s.compared) {
		for _, it := range tasks {
			it.drop(FlagActionMismatch)
		}
		s.note(fmt.Sprintf("XML/TaskCache action comparison disabled: %d of %d tasks differed, which points to an unrecognised TaskCache format rather than tampering.", n, s.compared))
	}
	if n := count(FlagSDMissing); n > 5 && float64(n) > 0.25*float64(s.sdChecked) {
		for _, it := range tasks {
			it.drop(FlagSDMissing)
		}
		s.note(fmt.Sprintf("Hidden-task (SD) check disabled: %d of %d Tree keys lacked SD, which points to restricted registry access.", n, s.sdChecked))
	}
	local, signed := 0, 0
	for _, it := range items {
		for _, t := range it.Targets {
			switch t.Sig.Status {
			case SigLocalRoot:
				local++
				signed++
			case SigValid:
				signed++
			}
		}
	}
	if local > 8 && float64(local) > 0.4*float64(signed) {
		for _, it := range items {
			for i := range it.Findings {
				if strings.HasPrefix(it.Findings[i].Text, "Self-made signature on") {
					it.Findings[i].Sev = SevInfo
				}
			}
		}
		s.note(fmt.Sprintf("Root-program check disabled: %d of %d signed files looked locally rooted, which points to an unreadable root list.", local, signed))
	}
	winUnsigned, winTotal := 0, 0
	for _, it := range items {
		for _, t := range it.Targets {
			if t.Exists && binaryExts[winExt(t.Path)] && inWindowsDir(t.Path, s.res.systemRoot()) {
				winTotal++
				if t.Sig.Status == SigUnsignedWinDir {
					winUnsigned++
				}
			}
		}
	}
	if winUnsigned > 10 && float64(winUnsigned) > 0.3*float64(winTotal) {
		for _, it := range items {
			for i := range it.Findings {
				if strings.Contains(it.Findings[i].Text, "inside the Windows directory") {
					it.Findings[i].Sev = SevInfo
				}
			}
		}
		s.note("Catalog signature verification seems unavailable (most Windows files reported unsigned); the unsigned-Windows-file check was downgraded.")
	}
}

func trimFrac(s string) string {
	if i := strings.IndexAny(s, ".+Z"); i > 0 {
		return s[:i]
	}
	return s
}

// firstCN pulls "CN=..." out of an X.500 subject for compact display.
func firstCN(subject string) string {
	for _, part := range splitDN(subject) {
		if strings.HasPrefix(strings.ToUpper(part), "CN=") {
			return strings.Trim(part[3:], `"`)
		}
	}
	return subject
}

func splitDN(s string) []string {
	var out []string
	var cur strings.Builder
	inQ := false
	for _, r := range s {
		switch {
		case r == '"':
			inQ = !inQ
			cur.WriteRune(r)
		case r == ',' && !inQ:
			out = append(out, strings.TrimSpace(cur.String()))
			cur.Reset()
		default:
			cur.WriteRune(r)
		}
	}
	if cur.Len() > 0 {
		out = append(out, strings.TrimSpace(cur.String()))
	}
	return out
}

var timestompRefs = []string{`System32\kernel32.dll`, `System32\ntdll.dll`, `System32\user32.dll`, `System32\notepad.exe`,
	`System32\cmd.exe`, `System32\svchost.exe`, `explorer.exe`, `System32\calc.exe`, `System32\conhost.exe`,
	`System32\taskhostw.exe`, `System32\rundll32.exe`, `System32\winlogon.exe`, `System32\lsass.exe`, `System32\services.exe`}

// clonedTimesFrom reports a system file whose exact write (and creation)
// times match t: a tell-tale of SetFileTime-based timestomping.
func (s *scanner) clonedTimesFrom(t *Target) string {
	if s.refTimes == nil {
		s.refTimes = map[string]FileStat{}
		for _, r := range timestompRefs {
			p := winJoin(s.res.systemRoot(), r)
			if st := s.p.Stat(p); st.Exists && !st.ModTime.IsZero() {
				s.refTimes[p] = st
			}
		}
	}
	for p, st := range s.refTimes {
		if strings.EqualFold(p, t.Path) {
			continue
		}
		if t.ModTime.Equal(st.ModTime) && (t.CTime.IsZero() || st.CTime.IsZero() || t.CTime.Equal(st.CTime)) {
			return winBase(p)
		}
	}
	return ""
}
