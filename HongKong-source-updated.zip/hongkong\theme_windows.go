//go:build windows

package main

import (
	"fmt"
	"strings"
	"unsafe"
)

// Hong Kong theme: neon signboard, Victoria Harbour skyline with blinking
// aircraft-warning lights, bilingual MTR-style labels, seal-stamp risk tags
// and a gold LED status board.

var pGdipFillPolygonI = gdiplus.NewProc("GdipFillPolygonI")

func (c *canvas) poly(pts []POINT, col Color) {
	g := c.gfx()
	if g == 0 || len(pts) < 3 {
		return
	}
	b := solidBrush(col)
	pGdipFillPolygonI.Call(g, b, uintptr(unsafe.Pointer(&pts[0])), uintptr(len(pts)), 0)
	pGdipDeleteBrush.Call(b)
}

// line draws an anti-aliased thin line as a 1px-wide quad (no pen floats).
func (c *canvas) line(x1, y1, x2, y2 int, col Color) {
	c.poly([]POINT{{int32(x1), int32(y1)}, {int32(x2), int32(y2)}, {int32(x2 + 1), int32(y2)}, {int32(x1 + 1), int32(y1)}}, col)
}

func (a *app) headerH() int { return a.px(96) }
func (a *app) hudH() int    { return a.px(74) }
func (a *app) footerH() int { return a.px(30) }

var hudCJK = []string{"排程任務", "自啟動", "證書", "系統", "威脅", "待查"}
var hudEN = []string{"TASKS", "AUTOSTART", "CERTS", "SYSTEM", "THREATS", "REVIEW"}

// ---------------------------------------------------------------------------
// layout

func (a *app) chipWidth(h uintptr) int {
	b := a.btns[h]
	w := a.capsWidth(b.label, a.fTab, a.px(1)) + a.px(26)
	if cjk := filterCJK[filterDefs[b.index].key]; cjk != "" {
		w += a.textWidth(cjk, a.fCJKSeal) + a.px(6)
	}
	if a.res != nil {
		w += a.textWidth(fmt.Sprint(b.count), a.fMonoB) + a.px(18)
	}
	return w
}

func (a *app) tabWidth(i int) int {
	w := a.textWidth(tabCJK[i], a.fCJKTab) + a.px(8) + a.capsWidth(tabNames[i], a.fTab, a.px(2)) + a.px(10)
	if a.res != nil {
		w += a.textWidth("000", a.fMonoB) + a.px(10)
	}
	return w
}

func (a *app) layout() {
	if a.list == 0 {
		return
	}
	rc := clientRect(a.hwnd)
	W, H := int(rc.Right), int(rc.Bottom)
	pad := a.px(24)
	hh := a.headerH()

	bw, bh := a.px(128), a.px(36)
	by := a.px(22)
	moveWindow(a.scanBtn, W-pad-bw, by, bw, bh)
	moveWindow(a.exportBtn, W-pad-2*bw-a.px(12), by, bw, bh)

	y := hh
	n := 6
	cw := (W - 2*pad) / n
	a.cells = a.cells[:0]
	for i := 0; i < n; i++ {
		x := pad + i*cw
		a.cells = append(a.cells, RECT{int32(x), int32(y), int32(x + cw), int32(y + a.hudH())})
	}
	y += a.hudH() + a.px(16)

	tabH := a.px(36)
	tx := pad
	for i, h := range a.tabBtns {
		w := a.tabWidth(i)
		moveWindow(h, tx, y, w, tabH)
		tx += w + a.px(18)
	}
	sw := a.px(340)
	a.searchLine = RECT{int32(W - pad - sw), int32(y + a.px(2)), int32(W - pad), int32(y + tabH - a.px(2))}
	moveWindow(a.search, W-pad-sw+a.px(52), y+(tabH-a.px(20))/2, sw-a.px(62), a.px(20))
	tw := a.textWidth("Show clean", a.fBody) + a.px(54)
	moveWindow(a.cleanBtn, W-pad-sw-a.px(18)-tw, y+(tabH-a.px(26))/2, tw, a.px(26))
	y += tabH + a.px(14)

	x, chipH := pad, a.px(28)
	for i, h := range a.chipBtns {
		if !a.chipVisible(i) {
			showWindow(h, false)
			continue
		}
		showWindow(h, true)
		w := a.chipWidth(h)
		if x+w > W-pad && x > pad {
			x = pad
			y += chipH + a.px(8)
		}
		moveWindow(h, x, y, w, chipH)
		x += w + a.px(8)
	}
	y += chipH + a.px(16)

	bottom := H - a.footerH() - a.px(10)
	detW := W * 35 / 100
	if detW < a.px(420) {
		detW = a.px(420)
	}
	listW := W - 2*pad - detW - a.px(14)
	a.listFrame = RECT{int32(pad), int32(y), int32(pad + listW), int32(bottom)}
	a.detFrame = RECT{int32(pad + listW + a.px(14)), int32(y), int32(W - pad), int32(bottom)}
	in := a.px(4)
	moveWindow(a.list, pad+in, y+in, listW-2*in, bottom-y-2*in)
	moveWindow(a.detail.hwnd, int(a.detFrame.Left)+in, y+in, detW-2*in, bottom-y-2*in)
	a.fitColumns(listW - 2*in)
	pInvalidateRect.Call(a.hwnd, 0, 0)
}

// ---------------------------------------------------------------------------
// header: skyline + neon sign

func (a *app) headerBg(y int) Color {
	t := float64(y) / float64(a.headerH())
	return hexc(0x1E0B0E).mix(cBg0, t)
}

type tower struct {
	x, w, h int
	kind    int // 0 block, 1 IFC, 2 Bank of China, 3 The Center, 4 antenna block
}

// skyline lays out a Victoria Harbour silhouette for a given width.
func (a *app) skyline(W, maxH, start int) []tower {
	var out []tower
	seed := uint32(2046)
	rnd := func(n int) int {
		seed = seed*1664525 + 1013904223
		return int(seed>>8) % n
	}
	x := start
	for x < W {
		w := a.px(14 + rnd(26))
		h := maxH*30/100 + rnd(maxH*45/100)
		kind := 0
		if rnd(6) == 0 {
			kind = 4
		}
		out = append(out, tower{x, w, h, kind})
		x += w + a.px(rnd(4))
	}
	land := func(frac float64, w, hPct, kind int) {
		out = append(out, tower{int(float64(W) * frac), a.px(w), maxH * hPct / 100, kind})
	}
	span := float64(W - start)
	at := func(f float64) float64 { return (float64(start) + span*f) / float64(W) }
	land(at(0.22), 22, 100, 1) // IFC
	land(at(0.40), 26, 94, 3)  // The Center
	land(at(0.55), 34, 98, 2)  // Bank of China Tower
	land(at(0.78), 20, 80, 4)
	return out
}

func (a *app) drawSkyline(c *canvas, W, base, start int) {
	maxH := a.px(62)
	body := hexc(0x1C1013)
	edge := hexc(0x2E1A1E)
	a.beacons = a.beacons[:0]
	seed := uint32(77)
	rnd := func(n int) int {
		seed = seed*1103515245 + 12345
		return int(seed>>16) % n
	}
	for _, t := range a.skyline(W, maxH, start) {
		top := base - t.h
		switch t.kind {
		case 1: // IFC: tall shaft, tapered crown with fins
			c.fillRect(t.x, top+a.px(8), t.w, t.h-a.px(8), body)
			c.poly([]POINT{{int32(t.x), int32(top + a.px(8))}, {int32(t.x + a.px(4)), int32(top + a.px(2))},
				{int32(t.x + t.w - a.px(4)), int32(top + a.px(2))}, {int32(t.x + t.w), int32(top + a.px(8))}}, body)
			for i := 0; i < 3; i++ {
				c.fillRect(t.x+a.px(5)+i*a.px(5), top-a.px(2)+i*a.px(1), a.px(2), a.px(5), body)
			}
			for i := 0; i < t.h/a.px(5); i++ {
				c.fillRect(t.x+a.px(3), top+a.px(12)+i*a.px(5), t.w-a.px(6), 1, edge)
			}
			a.beacons = append(a.beacons, POINT{int32(t.x + t.w/2), int32(top - a.px(3))})
		case 2: // Bank of China: slanted facets, X bracing, twin masts
			pts := []POINT{{int32(t.x), int32(base)}, {int32(t.x), int32(top + t.h*40/100)},
				{int32(t.x + t.w*55/100), int32(top + t.h*8/100)}, {int32(t.x + t.w), int32(top + t.h*22/100)}, {int32(t.x + t.w), int32(base)}}
			c.poly(pts, body)
			for yy := top + t.h*40/100; yy < base-a.px(10); yy += a.px(12) {
				c.line(t.x, yy, t.x+t.w, yy+a.px(12), edge)
				c.line(t.x+t.w, yy, t.x, yy+a.px(12), edge)
			}
			mx := t.x + t.w*55/100
			c.fillRect(mx-a.px(4), top-a.px(6), 1, t.h*8/100+a.px(6), edge)
			c.fillRect(mx+a.px(3), top-a.px(3), 1, t.h*8/100+a.px(3), edge)
			a.beacons = append(a.beacons, POINT{int32(mx - a.px(4)), int32(top - a.px(7))})
		case 3: // The Center: stepped top outlined in neon
			steps := []int{0, a.px(5), a.px(10)}
			for i, st := range steps {
				c.fillRect(t.x+i*a.px(3), top+st, t.w-2*i*a.px(3), t.h-st, body)
			}
			for i, st := range steps {
				c.fillRect(t.x+i*a.px(3), top+st, t.w-2*i*a.px(3), 1, cNeon.alpha(170))
			}
			for yy := top + a.px(16); yy < base-a.px(4); yy += a.px(7) {
				c.fillRect(t.x+a.px(2), yy, t.w-a.px(4), 1, cNeon.alpha(38))
			}
			a.beacons = append(a.beacons, POINT{int32(t.x + t.w/2), int32(top - a.px(2))})
		default:
			c.fillRect(t.x, top, t.w, t.h, body)
			c.fillRect(t.x, top, t.w, 1, edge)
			if t.kind == 4 {
				c.fillRect(t.x+t.w/2, top-a.px(10), 1, a.px(10), edge)
			}
			// lit windows
			for wy := top + a.px(5); wy < base-a.px(3); wy += a.px(4) {
				for wx := t.x + a.px(3); wx < t.x+t.w-a.px(3); wx += a.px(4) {
					switch rnd(14) {
					case 0:
						c.fillRect(wx, wy, a.px(2), a.px(1)+1, cGold.alpha(120))
					case 1:
						c.fillRect(wx, wy, a.px(2), a.px(1)+1, hexc(0xFFE6C8).alpha(70))
					}
				}
			}
		}
	}
	// harbour glow along the waterline
	c.gradientRect(0, base-a.px(14), W, a.px(14), cNeon.alpha(0), cNeon.alpha(26), true)
}

func (a *app) invalidateBeacons() {
	for _, b := range a.beacons {
		r := RECT{b.X - int32(a.px(8)), b.Y - int32(a.px(8)), b.X + int32(a.px(8)), b.Y + int32(a.px(8))}
		pInvalidateRect.Call(a.hwnd, uintptr(unsafe.Pointer(&r)), 0)
	}
}

func (a *app) paintMain(hwnd uintptr) {
	var ps PAINTSTRUCT
	hdc, _, _ := pBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	rc := clientRect(hwnd)
	W, H := int(rc.Right), int(rc.Bottom)
	bb := newBackBuffer(hdc, W, H)
	c := newCanvas(bb.dc)
	c.fillRect(0, 0, W, H, cBg0)

	hh := a.headerH()
	c.gradientRect(0, 0, W, hh, hexc(0x1E0B0E), cBg0, true)
	iconSz := a.px(44)
	ix, iy := a.px(24), (hh-iconSz)/2-a.px(4)
	sx := ix + iconSz + a.px(16)
	sw := a.textWidth("香港", a.fCJK) + a.px(22)
	tx := sx + sw + a.px(18)
	wordEnd := tx + a.capsWidth("SCHEDULED TASK · AUTOSTART · SIGNATURE FORENSICS", a.fLabel, a.px(2)) + a.px(40)
	if wordEnd < W*36/100 {
		wordEnd = W * 36 / 100
	}
	a.drawSkyline(c, W, hh-1, wordEnd)
	for _, b := range a.beacons {
		if a.caretOn {
			c.dot(int(b.X), int(b.Y), a.px(5), cNeon.alpha(60))
			c.dot(int(b.X), int(b.Y), a.px(2), hexc(0xFF6A4D))
		} else {
			c.dot(int(b.X), int(b.Y), a.px(1)+1, cNeonDk)
		}
	}
	c.fillRect(0, hh-1, W, 1, cLine)
	if a.scanning {
		seg := W / 4
		x := int(a.animPhase * float64(W))
		c.gradientRect(x-seg, hh-a.px(2), seg, a.px(2), cNeon.alpha(0), cNeon, false)
		c.gradientRect(x, hh-a.px(2), seg/3, a.px(2), cGold, cGold.alpha(0), false)
	}

	// app icon
	c.close()
	pDrawIconEx.Call(bb.dc, uintptr(ix), uintptr(iy), a.iconBanner, uintptr(iconSz), uintptr(iconSz), 0, 0, DI_NORMAL)

	// neon signboard with 香港
	sh := a.px(44)
	sy := iy
	c.glow(sx, sy, sw, sh, a.px(6), cNeon)
	c.strokeRound(sx, sy, sw, sh, a.px(6), cNeon, hexc(0x140608))
	c.strokeRound(sx+a.px(3), sy+a.px(3), sw-a.px(6), sh-a.px(6), a.px(4), cNeon.alpha(90), hexc(0x140608))
	c.neonText("香港", sx, sy, sw, sh, a.fCJK, hexc(0xFF8A70), cNeon, DT_SINGLELINE|DT_VCENTER|DT_CENTER, 0)

	// wordmark
	c.textX("HONG KONG", tx, sy-a.px(1), a.px(320), a.px(28), a.fBrand, cText, DT_SINGLELINE, a.px(5))
	c.text("排程任務 · 自啟動 · 數碼簽名鑑證", tx, sy+a.px(27), a.px(360), a.px(18), a.fCJKLabel, cGold, DT_SINGLELINE)
	c.textX("SCHEDULED TASK · AUTOSTART · SIGNATURE FORENSICS", tx, sy+a.px(45), a.px(460), a.px(14), a.fLabel, cDim, DT_SINGLELINE, a.px(2))

	a.paintHUD(c, W)

	// search box
	s := a.searchLine
	border := cLine
	if a.searchFocus {
		border = cNeon
	}
	c.strokeRound(int(s.Left), int(s.Top), int(s.Right-s.Left), int(s.Bottom-s.Top), a.px(4), border, cBg0)
	c.text("搜尋", int(s.Left)+a.px(12), int(s.Top), a.px(40), int(s.Bottom-s.Top), a.fCJKSeal, cGold, DT_SINGLELINE|DT_VCENTER)

	// content panels
	for _, r := range []RECT{a.listFrame, a.detFrame} {
		x, y, w, h := int(r.Left), int(r.Top), int(r.Right-r.Left), int(r.Bottom-r.Top)
		c.strokeRound(x, y, w, h, a.px(6), cLine, cBg1)
		c.fillRect(x+a.px(12), y, a.px(28), a.px(2), cNeon)
	}

	a.paintFooter(c, W, H)
	c.close()
	bb.flush(0, 0)
	pEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
}

// paintFooter draws the gold LED status board.
func (a *app) paintFooter(c *canvas, W, H int) {
	fy := H - a.footerH()
	c.fillRect(0, fy, W, a.footerH(), hexc(0x0A0708))
	c.fillRect(0, fy, W, 1, cLine)
	// faint LED grid
	for x := 0; x < W; x += a.px(3) {
		c.fillRect(x, fy+1, 1, a.footerH()-1, argb(10, 0, 0, 0))
	}
	px := a.px(24)
	dot := cGold.alpha(70)
	if a.scanning || a.caretOn {
		dot = cGold
	}
	c.dot(px, fy+a.footerH()/2, a.px(3), dot)
	c.text("狀態", px+a.px(12), fy, a.px(40), a.footerH(), a.fCJKLabel, cGold, DT_SINGLELINE|DT_VCENTER)
	lx := px + a.px(12) + a.textWidth("狀態", a.fCJKLabel) + a.px(10)
	c.text(a.status, lx, fy, W-lx-a.px(260), a.footerH(), a.fMono, cGold.mix(cBg0, 0.15), DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPS)
	right := "v" + appVersion
	if isElevated() {
		right = "管理員 ADMIN   " + right
	} else {
		right = "受限 LIMITED   " + right
	}
	c.text(right, W-a.px(280), fy, a.px(256), a.footerH(), a.fCJKLabel, cDim, DT_SINGLELINE|DT_VCENTER|DT_RIGHT)
}

func (a *app) paintHUD(c *canvas, W int) {
	flagged := func(list []*Item) int {
		n := 0
		for _, it := range list {
			if it.Risk != RiskClean {
				n++
			}
		}
		return n
	}
	vals := []int{-1, -1, -1, -1, -1, -1}
	subs := make([]string, 6)
	if a.res != nil {
		s := a.res.Summary
		vals = []int{s.Tasks, s.Autostart, s.Certs, s.System, s.Suspicious, s.Review}
		subs = []string{fmt.Sprintf("%d flagged", flagged(a.res.Tasks)), fmt.Sprintf("%d flagged", flagged(a.res.Autostart)),
			fmt.Sprintf("%d flagged", flagged(a.res.Certs)), fmt.Sprintf("%d flagged", flagged(a.res.System)), "suspicious", "to review"}
	}
	y0 := a.headerH()
	c.fillRect(0, y0+a.hudH()-1, W, 1, cLine)
	for i, r := range a.cells {
		x, y, w, h := int(r.Left), int(r.Top), int(r.Right-r.Left), int(r.Bottom-r.Top)
		if i == a.hoverCell {
			c.fillRect(x, y, w, h-1, cBg1)
		}
		if i > 0 {
			c.fillRect(x, y+a.px(16), 1, h-a.px(32), cLine)
		}
		active := (i <= 3 && i == a.tabIdx) || (i == 4 && a.filter == "suspicious") || (i == 5 && a.filter == "review")
		if active {
			c.fillRect(x+a.px(16), y+h-a.px(3), w-a.px(32), a.px(3), cNeon)
		}
		lx := x + a.px(18)
		cw := a.textWidth(hudCJK[i], a.fCJKLabel)
		c.text(hudCJK[i], lx, y+a.px(10), cw+a.px(4), a.px(18), a.fCJKLabel, cText2, DT_SINGLELINE|DT_VCENTER)
		c.textX(hudEN[i], lx+cw+a.px(8), y+a.px(10), w, a.px(18), a.fLabel, cDim, DT_SINGLELINE|DT_VCENTER, a.px(2))
		val := "—"
		if vals[i] >= 0 {
			val = fmt.Sprint(vals[i])
		}
		col := cText
		switch {
		case i == 4 && vals[i] > 0:
			col = cSus
		case i == 5 && vals[i] > 0:
			col = cRev
		}
		c.text(val, lx, y+a.px(28), w/2, a.px(38), a.fNum, col, DT_SINGLELINE|DT_VCENTER)
		nw := a.textWidth(val, a.fNum)
		c.text(subs[i], lx+nw+a.px(10), y+a.px(38), w-nw-a.px(44), a.px(22), a.fSub, cDim, DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPS)
	}
}

// ---------------------------------------------------------------------------
// owner-drawn controls

func (a *app) drawItem(dis *DRAWITEMSTRUCT) {
	b := a.btns[dis.HwndItem]
	if b == nil {
		return
	}
	rc := dis.RcItem
	w, h := int(rc.Right-rc.Left), int(rc.Bottom-rc.Top)
	bb := newBackBuffer(dis.HDC, w, h)
	c := newCanvas(bb.dc)
	hot := a.hover == dis.HwndItem
	pressed := dis.ItemState&ODS_SELECTED != 0
	disabled := dis.ItemState&ODS_DISABLED != 0
	vc := uint32(DT_SINGLELINE | DT_VCENTER)

	// bilingual label centered: CJK + English caps
	bilingual := func(cjk, en string, x0, w int, cjkFont uintptr, col, enCol Color) {
		cw := a.textWidth(cjk, cjkFont)
		ew := a.capsWidth(en, a.fTab, a.px(2))
		x := x0 + (w-cw-a.px(8)-ew)/2
		c.text(cjk, x, 0, cw+a.px(4), h, cjkFont, col, vc)
		c.textX(en, x+cw+a.px(8), 0, ew+a.px(4), h, a.fTab, enCol, vc, a.px(2))
	}

	switch b.kind {
	case bkScan:
		top := int(rc.Top)
		c.fillRect(0, 0, w, h, a.headerBg(top+h/2))
		fill := cNeon
		if hot {
			fill = cNeonHi
		}
		if pressed {
			fill = cNeon.mix(cBg0, 0.25)
		}
		if disabled {
			c.strokeRound(0, 0, w, h, a.px(4), cNeon, cNeonDk)
			bilingual("掃描中", "SCANNING", 0, w, a.fCJKSeal, cText, cText2)
			break
		}
		c.fillRound(0, 0, w, h, a.px(4), fill)
		c.fillRect(a.px(4), 0, w-a.px(8), 1, argb(80, 255, 220, 200))
		label := "RESCAN"
		if a.res == nil {
			label = "SCAN"
		}
		bilingual("掃描", label, 0, w, a.fCJKSeal, cText, cText)
	case bkExport:
		top := int(rc.Top)
		c.fillRect(0, 0, w, h, a.headerBg(top+h/2))
		border, txt := cLineHi, cText2
		if hot {
			border, txt = cGold, cText
		}
		if disabled {
			txt = cDim
		}
		c.strokeRound(0, 0, w, h, a.px(4), border, a.headerBg(top+h/2))
		bilingual("匯出", "EXPORT", 0, w, a.fCJKSeal, txt, txt)
	case bkTab:
		c.fillRect(0, 0, w, h, cBg0)
		sel := b.index == a.tabIdx
		cjkCol, enCol := cDim, cDim
		switch {
		case sel:
			cjkCol, enCol = cText, cText2
		case hot:
			cjkCol, enCol = cText2, cText2
		}
		x := a.px(2)
		cw := a.textWidth(tabCJK[b.index], a.fCJKTab)
		c.text(tabCJK[b.index], x, 0, cw+a.px(4), h-a.px(4), a.fCJKTab, cjkCol, vc)
		x += cw + a.px(8)
		ew := a.capsWidth(tabNames[b.index], a.fTab, a.px(2))
		c.textX(tabNames[b.index], x, a.px(1), ew+a.px(4), h-a.px(4), a.fTab, enCol, vc, a.px(2))
		x += ew + a.px(10)
		if a.res != nil {
			n := fmt.Sprint(b.count)
			nw := a.textWidth(n, a.fMonoB) + a.px(12)
			bc, nc := cBg2, cDim
			if b.count > 0 {
				bc, nc = cNeon, cText
			}
			c.fillRound(x, (h-a.px(4)-a.px(18))/2, nw, a.px(18), a.px(9), bc)
			c.text(n, x, (h-a.px(4)-a.px(18))/2, nw, a.px(18), a.fMonoB, nc, vc|DT_CENTER)
		}
		if sel {
			c.fillRound(0, h-a.px(3), w, a.px(3), a.px(1), cNeon)
		} else if hot {
			c.fillRect(0, h-1, w, 1, cLineHi)
		}
	case bkChip:
		c.fillRect(0, 0, w, h, cBg0)
		d := filterDefs[b.index]
		sel := d.key == a.filter
		border, fill, txt, num := cLine, cBg1, cText2, cDim
		switch {
		case sel:
			border, fill, txt, num = cNeon, cNeon, cText, cText
		case hot:
			border, fill, txt = cLineHi, cBg2, cText
		}
		if b.count == 0 && !sel && a.res != nil {
			txt = cDim
		}
		if b.count > 0 && !sel {
			switch d.key {
			case "suspicious", "selfsigned", "tampered":
				num = cSus
			case "review":
				num = cRev
			default:
				num = cText2
			}
		}
		c.strokeRound(0, 0, w, h, h/2, border, fill)
		x := a.px(13)
		if cjk := filterCJK[d.key]; cjk != "" {
			cw := a.textWidth(cjk, a.fCJKSeal)
			c.text(cjk, x, 0, cw+a.px(4), h, a.fCJKSeal, txt, vc)
			x += cw + a.px(6)
		}
		lw := a.capsWidth(b.label, a.fTab, a.px(1))
		c.textX(b.label, x, a.px(1), lw+a.px(4), h, a.fTab, txt, vc, a.px(1))
		if a.res != nil {
			c.text(fmt.Sprint(b.count), x+lw+a.px(9), 0, a.px(40), h, a.fMonoB, num, vc)
		}
	case bkToggle:
		c.fillRect(0, 0, w, h, cBg0)
		tw, th := a.px(34), a.px(18)
		ty := (h - th) / 2
		track := cBg3
		if a.clean {
			track = cClean.mix(cBg0, 0.2)
		} else if hot {
			track = cLineHi
		}
		c.fillRound(0, ty, tw, th, th/2, track)
		kx := a.px(9)
		if a.clean {
			kx = tw - a.px(9)
		}
		c.dot(kx, ty+th/2, a.px(6), cText)
		c.text("Show clean", tw+a.px(10), 0, w-tw-a.px(10), h, a.fBody, cText2, vc)
	}
	c.close()
	bb.flush(int(rc.Left), int(rc.Top))
}

func (a *app) drawHeader(cd *NMCUSTOMDRAW) uintptr {
	switch cd.DrawStage {
	case CDDS_PREPAINT:
		rc := clientRect(a.header)
		c := newCanvas(cd.Hdc)
		c.fillRect(0, 0, int(rc.Right), int(rc.Bottom), cBg1)
		c.close()
		return CDRF_NOTIFYITEMDRAW | CDRF_NOTIFYPOSTPAINT
	case CDDS_ITEMPREPAINT:
		r := cd.Rc
		c := newCanvas(cd.Hdc)
		c.fillRect(int(r.Left), int(r.Top), int(r.Right-r.Left), int(r.Bottom-r.Top), cBg1)
		c.fillRect(int(r.Left), int(r.Bottom)-1, int(r.Right-r.Left), 1, cLine)
		i := int(cd.ItemSpec)
		label := columnTitles[a.tabIdx][i]
		if a.sortCol == i && label != "" {
			if a.sortDesc {
				label += "  ↓"
			} else {
				label += "  ↑"
			}
		}
		col := cDim
		if a.sortCol == i {
			col = cGold
		}
		c.textX(label, int(r.Left)+a.px(14), int(r.Top), int(r.Right-r.Left)-a.px(16), int(r.Bottom-r.Top), a.fLabel, col,
			DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPS, a.px(2))
		c.close()
		return CDRF_SKIPDEFAULT
	case CDDS_POSTPAINT:
		rc := clientRect(a.header)
		x := 0
		for i := range columnTitles[a.tabIdx] {
			x += int(send(a.list, LVM_GETCOLUMNWIDTH, uintptr(i), 0))
		}
		c := newCanvas(cd.Hdc)
		c.fillRect(x, 0, int(rc.Right)-x, int(rc.Bottom), cBg1)
		c.fillRect(x, int(rc.Bottom)-1, int(rc.Right)-x, 1, cLine)
		c.close()
	}
	return CDRF_DODEFAULT
}

// riskSeal returns the seal-stamp character, English code and colour.
func riskSeal(it *Item) (string, string, Color) {
	if it.Trusted {
		return "信", "TRUSTED", cInfo
	}
	switch it.Risk {
	case RiskSuspicious:
		return "危", "THREAT", cSus
	case RiskReview:
		return "疑", "REVIEW", cRev
	}
	return "安", "CLEAN", cClean
}

// seal draws a square chop with a white character inside.
func (a *app) seal(c *canvas, x, y, size int, ch string, col Color, font uintptr) {
	c.fillRound(x, y, size, size, a.px(3), col)
	c.fillRound(x+1, y+1, size-2, size-2, a.px(2), col.mix(hexc(0x000000), 0.12))
	c.text(ch, x, y, size, size, font, hexc(0xFFF6EE), DT_SINGLELINE|DT_VCENTER|DT_CENTER)
}

func (a *app) paintRow(cd *NMLVCUSTOMDRAW) uintptr {
	i := int(cd.Nmcd.ItemSpec)
	if i < 0 || i >= len(a.view) {
		return CDRF_DODEFAULT
	}
	it := a.view[i]
	rc := RECT{Left: 0}
	sendp(a.list, LVM_GETITEMRECT, uintptr(i), unsafe.Pointer(&rc))
	c := newCanvas(cd.Nmcd.Hdc)
	x0, y, h := int(rc.Left), int(rc.Top), int(rc.Bottom-rc.Top)
	full := int(clientRect(a.list).Right) - x0
	if r := int(rc.Right - rc.Left); r > full {
		full = r
	}
	sel := i == a.selIdx
	bg := cBg1
	if sel {
		bg = cSelRow
	}
	c.fillRect(x0, y, full, h, bg)
	c.fillRect(x0+a.px(10), y+h-1, full-a.px(20), 1, hexc(0x1E1517))
	if sel {
		c.fillRect(x0, y+a.px(6), a.px(3), h-a.px(12), cNeon)
	}
	x := x0
	for col := range columnTitles[a.tabIdx] {
		w := int(send(a.list, LVM_GETCOLUMNWIDTH, uintptr(col), 0))
		if w > 0 {
			a.paintCell(c, it, col, x, y, w, h)
		}
		x += w
	}
	c.close()
	return CDRF_SKIPDEFAULT
}

func (a *app) paintCell(c *canvas, it *Item, col, x, y, w, h int) {
	pad := a.px(14)
	flags := uint32(DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPS)
	switch col {
	case 0:
		ch, code, rc := riskSeal(it)
		sz := a.px(22)
		a.seal(c, x+pad, y+(h-sz)/2, sz, ch, rc, a.fCJKSeal)
		c.textX(code, x+pad+sz+a.px(8), y, w-pad-sz-a.px(8), h, a.fLabel, rc, flags, a.px(1))
	case 1:
		font, colr := a.fBody, cText2
		if it.Risk != RiskClean && !it.Trusted {
			font, colr = a.fBodyB, cText
		}
		nw := a.textWidth(it.Name, font)
		c.text(it.Name, x+pad, y, w-2*pad, h, font, colr, flags)
		if it.Kind == "task" {
			if folder := winDir(it.Path); folder != "" && nw+a.px(30) < w-2*pad {
				c.text(folder, x+pad+nw+a.px(8), y, w-2*pad-nw-a.px(8), h, a.fSub, cDim, flags)
			}
		}
	case 4:
		if it.Kind == "system" {
			return
		}
		status := it.SignatureStatus
		sc := sigColor(status)
		if it.Kind == "cert" {
			sc = cText2
			if strings.HasPrefix(status, "Self-signed") {
				sc = cRev
			}
		}
		sw := a.textWidth(status, a.fBodyB)
		c.text(status, x+pad, y, w-2*pad, h, a.fBodyB, sc, flags)
		if it.Signer != "" && it.Kind != "cert" && sw+a.px(30) < w-2*pad {
			c.text(it.Signer, x+pad+sw+a.px(8), y, w-2*pad-sw-a.px(8), h, a.fSub, cDim, flags)
		}
	case 5:
		colr := cText2
		if it.Risk == RiskSuspicious && !it.Trusted {
			colr = cText
		}
		c.text(a.cellText(it, col), x+pad, y, w-2*pad, h, a.fBody, colr, flags)
	default:
		c.text(a.cellText(it, col), x+pad, y, w-2*pad, h, a.fMono, cText2, flags)
	}
}
