//go:build !windows

package main

import (
	"errors"
	"fmt"
	"os"
	"time"
)

// Non-Windows builds exist only so the analysis logic can be unit-tested.

var errNotWindows = errors.New("HongKong only runs on Windows")

type nullPlatform struct{}

func newPlatform() Platform { return nullPlatform{} }

func (nullPlatform) Getenv(string) string                                  { return "" }
func (nullPlatform) Stat(string) FileStat                                  { return FileStat{} }
func (nullPlatform) ReadFile(string, int64) ([]byte, error)                { return nil, errNotWindows }
func (nullPlatform) HashFile(string) (string, error)                       { return "", errNotWindows }
func (nullPlatform) ListDir(string) ([]string, error)                      { return nil, errNotWindows }
func (nullPlatform) TaskFiles() ([]TaskFile, error)                        { return nil, errNotWindows }
func (nullPlatform) RegSubkeys(string, string) ([]string, error)           { return nil, errNotWindows }
func (nullPlatform) RegValues(string, string) (map[string]RegValue, error) { return nil, errNotWindows }
func (nullPlatform) RegKeyModTime(string, string) time.Time                { return time.Time{} }
func (nullPlatform) CheckSignatures([]string) (map[string]SigInfo, error)  { return nil, errNotWindows }
func (nullPlatform) WMIConsumers() ([]WMIConsumer, error)                  { return nil, errNotWindows }
func (nullPlatform) Hostname() string                                      { return "" }
func (nullPlatform) Username() string                                      { return "" }
func (nullPlatform) Elevated() bool                                        { return false }

func main() {
	fmt.Fprintln(os.Stderr, errNotWindows)
	os.Exit(1)
}
