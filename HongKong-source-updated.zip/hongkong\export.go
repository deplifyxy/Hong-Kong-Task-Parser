package main

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"os"
	"strings"
)

func writeJSON(r *ScanResult, path string) error {
	b, err := json.MarshalIndent(r, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0o644)
}

// writeCSV exports the given rows (normally the current filtered view).
func writeCSV(items []*Item, path string) error {
	var buf bytes.Buffer
	buf.Write([]byte{0xEF, 0xBB, 0xBF}) // UTF-8 BOM so Excel opens it correctly
	w := csv.NewWriter(&buf)
	w.Write([]string{"kind", "risk", "name", "path", "location", "command", "triggers", "run_as",
		"signature", "signer", "sha256", "flags", "findings"})
	for _, it := range items {
		var f []string
		for _, x := range it.Findings {
			f = append(f, "["+x.Sev.String()+"] "+x.Text)
		}
		w.Write([]string{it.Kind, it.Risk, it.Name, it.Path, it.Location, it.Command,
			strings.Join(it.Triggers, "; "), strings.TrimSpace(it.RunAs + " " + it.RunLevel),
			it.SignatureStatus, it.Signer, it.SHA256, strings.Join(it.FlagKeys, "; "), strings.Join(f, " | ")})
	}
	w.Flush()
	if err := w.Error(); err != nil {
		return err
	}
	return os.WriteFile(path, buf.Bytes(), 0o644)
}
