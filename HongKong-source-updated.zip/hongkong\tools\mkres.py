"""Builds rsrc_windows_amd64.syso: a COFF object with an .rsrc section holding
the app icon (RT_ICON + RT_GROUP_ICON), the application manifest and the
version resource. Go links any *.syso in the package directory automatically.

usage: python3 tools/mkres.py <assets dir> <version a.b.c> <output .syso>
"""
import struct
import sys
from PIL import Image

assets, version, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
ICON_SIZES = [16, 20, 24, 32, 40, 48, 64, 128, 256]
LANG = 0x0409

RT_ICON, RT_VERSION, RT_GROUP_ICON, RT_MANIFEST = 3, 16, 14, 24

MANIFEST = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity type="win32" name="HongKong.Forensics" version="{version}.0" processorArchitecture="amd64"/>
  <description>HongKong - scheduled task and autostart forensics</description>
  <dependency>
    <dependentAssembly>
      <assemblyIdentity type="win32" name="Microsoft.Windows.Common-Controls" version="6.0.0.0"
        processorArchitecture="*" publicKeyToken="6595b64144ccf1df" language="*"/>
    </dependentAssembly>
  </dependency>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3">
    <security><requestedPrivileges>
      <requestedExecutionLevel level="highestAvailable" uiAccess="false"/>
    </requestedPrivileges></security>
  </trustInfo>
  <application xmlns="urn:schemas-microsoft-com:asm.v3">
    <windowsSettings>
      <dpiAware xmlns="http://schemas.microsoft.com/SMI/2005/WindowsSettings">true</dpiAware>
      <longPathAware xmlns="http://schemas.microsoft.com/SMI/2016/WindowsSettings">true</longPathAware>
    </windowsSettings>
  </application>
  <compatibility xmlns="urn:schemas-microsoft-com:compatibility.v1">
    <application>
      <supportedOS Id="{{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}}"/>
      <supportedOS Id="{{1f676c76-80e1-4239-95bb-83d0f6d0da78}}"/>
    </application>
  </compatibility>
</assembly>
""".encode("utf-8")


def dib(img):
    """32-bit BGRA DIB with an (unused) AND mask, as stored in .ico/RT_ICON."""
    w, h = img.size
    hdr = struct.pack("<IiiHHIIiiII", 40, w, h * 2, 1, 32, 0, 0, 0, 0, 0, 0)
    px = img.convert("RGBA").load()
    xor = bytearray()
    for y in range(h - 1, -1, -1):
        for x in range(w):
            r, g, b, a = px[x, y]
            xor += bytes((b, g, r, a))
    stride = ((w + 31) // 32) * 4
    return hdr + bytes(xor) + bytes(stride * h)


def png(img):
    import io
    b = io.BytesIO()
    img.save(b, "PNG")
    return b.getvalue()


def icon_resources():
    icons, group = {}, struct.pack("<HHH", 0, 1, len(ICON_SIZES))
    for i, s in enumerate(ICON_SIZES, start=1):
        img = Image.open(f"{assets}/icon_{s}.png").convert("RGBA")
        data = png(img) if s >= 256 else dib(img)
        icons[i] = data
        wh = 0 if s >= 256 else s
        group += struct.pack("<BBBBHHIH", wh, wh, 0, 0, 1, 32, len(data), i)
    return icons, group


# --- VS_VERSIONINFO ------------------------------------------------------------

def pad4(b):
    return b + b"\0" * ((4 - len(b) % 4) % 4)


def wz(s):
    return (s + "\0").encode("utf-16-le")


def block(key, value=b"", children=(), wtype=1, value_len=None):
    head_tail = pad4(struct.pack("<HHH", 0, 0, 0) + wz(key))
    body = head_tail + value
    for c in children:
        body = pad4(body) + c
    if value_len is None:
        value_len = len(value) // 2 if wtype == 1 else len(value)
    return struct.pack("<HHH", len(body), value_len, wtype) + body[6:]


def version_resource():
    parts = [int(x) for x in version.split(".")] + [0] * 4
    ms = (parts[0] << 16) | parts[1]
    ls = (parts[2] << 16) | parts[3]
    fixed = struct.pack("<13I", 0xFEEF04BD, 0x00010000, ms, ls, ms, ls, 0x3F, 0, 0x00040004, 1, 0, 0, 0)
    strings = [
        ("CompanyName", "HongKong"),
        ("FileDescription", "HongKong - Scheduled Task & Autostart Forensics"),
        ("FileVersion", version + ".0"),
        ("InternalName", "HongKong"),
        ("LegalCopyright", ""),
        ("OriginalFilename", "HongKong.exe"),
        ("ProductName", "HongKong"),
        ("ProductVersion", version),
    ]
    st = [block(k, wz(v)) for k, v in strings]
    sfi = block("StringFileInfo", children=[block("040904B0", children=st)])
    vfi = block("VarFileInfo", children=[block("Translation", struct.pack("<HH", LANG, 1200), wtype=0)])
    return block("VS_VERSION_INFO", fixed, [sfi, vfi], wtype=0, value_len=len(fixed))


# --- .rsrc section ---------------------------------------------------------------

def build_rsrc(resources):
    """resources: {type: {id: bytes}} -> (section bytes, relocation offsets)"""
    types = sorted(resources)
    dir_size = lambda n: 16 + 8 * n
    off = dir_size(len(types))
    name_dir_off = {}
    for t in types:
        name_dir_off[t] = off
        off += dir_size(len(resources[t]))
    lang_dir_off = {}
    for t in types:
        for i in sorted(resources[t]):
            lang_dir_off[(t, i)] = off
            off += dir_size(1)
    entry_off = {}
    for t in types:
        for i in sorted(resources[t]):
            entry_off[(t, i)] = off
            off += 16
    data_off = {}
    for t in types:
        for i in sorted(resources[t]):
            off = (off + 7) & ~7
            data_off[(t, i)] = off
            off += len(resources[t][i])
    sec = bytearray(off)
    relocs = []

    def put_dir(at, entries):
        struct.pack_into("<IIHHHH", sec, at, 0, 0, 0, 0, 0, len(entries))
        for n, (ident, target) in enumerate(entries):
            struct.pack_into("<II", sec, at + 16 + 8 * n, ident, target)

    put_dir(0, [(t, 0x80000000 | name_dir_off[t]) for t in types])
    for t in types:
        put_dir(name_dir_off[t], [(i, 0x80000000 | lang_dir_off[(t, i)]) for i in sorted(resources[t])])
        for i in sorted(resources[t]):
            put_dir(lang_dir_off[(t, i)], [(LANG, entry_off[(t, i)])])
            e = entry_off[(t, i)]
            # OffsetToData is an RVA: store the section offset, relocate against the section.
            struct.pack_into("<IIII", sec, e, data_off[(t, i)], len(resources[t][i]), 0, 0)
            relocs.append(e)
            d = data_off[(t, i)]
            sec[d:d + len(resources[t][i])] = resources[t][i]
    return bytes(sec), relocs


def coff(section, relocs):
    IMAGE_FILE_MACHINE_AMD64 = 0x8664
    IMAGE_REL_AMD64_ADDR32NB = 3
    hdr_size, sec_hdr_size = 20, 40
    raw_ptr = hdr_size + sec_hdr_size
    reloc_ptr = raw_ptr + len(section)
    sym_ptr = reloc_ptr + 10 * len(relocs)
    out = struct.pack("<HHIIIHH", IMAGE_FILE_MACHINE_AMD64, 1, 0, sym_ptr, 1, 0, 0)
    out += struct.pack("<8sIIIIIIHHI", b".rsrc", 0, 0, len(section), raw_ptr, reloc_ptr, 0,
                       len(relocs), 0, 0x40000040)  # INITIALIZED_DATA | MEM_READ
    out += section
    for r in relocs:
        out += struct.pack("<IIH", r, 0, IMAGE_REL_AMD64_ADDR32NB)
    out += struct.pack("<8sIhHBB", b".rsrc", 0, 1, 0, 3, 0)  # static section symbol
    out += struct.pack("<I", 4)  # empty string table
    return out


icons, group = icon_resources()
res = {
    RT_ICON: icons,
    RT_GROUP_ICON: {1: group},
    RT_VERSION: {1: version_resource()},
    RT_MANIFEST: {1: MANIFEST},
}
section, relocs = build_rsrc(res)
open(out_path, "wb").write(coff(section, relocs))
print(f"wrote {out_path}: {len(section)} bytes of resources, {len(relocs)} relocations")
