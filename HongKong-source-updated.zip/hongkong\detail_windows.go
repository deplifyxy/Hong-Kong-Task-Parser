//go:build windows

package main

import (
	"fmt"
	"strings"
	"syscall"
	"unsafe"
)

// detailPanel is a custom-painted, scrollable view for one item's analysis.

type drow struct {
	measure func(hdc uintptr, w int) int
	paint   func(c *canvas, x, y, w, h int)
}

type detailPanel struct {
	a       *app
	hwnd    uintptr
	rows    []drow
	heights []int
	total   int
	scroll  int
	plain   string // clipboard text
}

var detailProc uintptr

func (a *app) createDetailPanel() {
	d := &detailPanel{a: a}
	a.detail = d
	if detailProc == 0 {
		detailProc = syscall.NewCallback(func(hwnd uintptr, msg uint32, w, l uintptr) uintptr {
			return a.detail.wndProc(hwnd, msg, w, l)
		})
	}
	cursor, _, _ := pLoadCursorW.Call(0, IDC_ARROW)
	wc := WNDCLASSEXW{LpfnWndProc: detailProc, HInstance: a.hInst, HCursor: cursor, LpszClassName: u16("HongKongDetail")}
	wc.CbSize = uint32(unsafe.Sizeof(wc))
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))
	d.hwnd, _, _ = pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(wc.LpszClassName)), 0,
		WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_TABSTOP, 0, 0, 10, 10, a.hwnd, idDetail, a.hInst, 0)
	pSetWindowTheme.Call(d.hwnd, uintptr(unsafe.Pointer(u16("DarkMode_Explorer"))), 0)
}

func (d *detailPanel) set(rows []drow, plain string) {
	d.rows, d.plain, d.scroll = rows, plain, 0
	d.relayout()
	pInvalidateRect.Call(d.hwnd, 0, 0)
}

func (d *detailPanel) pad() int { return d.a.px(18) }

func (d *detailPanel) relayout() {
	rc := clientRect(d.hwnd)
	w := int(rc.Right) - 2*d.pad()
	hdc, _, _ := pGetDC.Call(d.hwnd)
	d.heights = d.heights[:0]
	d.total = d.pad()
	for _, r := range d.rows {
		h := r.measure(hdc, w)
		d.heights = append(d.heights, h)
		d.total += h
	}
	d.total += d.pad()
	pReleaseDC.Call(d.hwnd, hdc)
	d.updateScroll()
}

func (d *detailPanel) updateScroll() {
	rc := clientRect(d.hwnd)
	page := int(rc.Bottom)
	maxScroll := d.total - page
	if maxScroll < 0 {
		maxScroll = 0
	}
	if d.scroll > maxScroll {
		d.scroll = maxScroll
	}
	if d.scroll < 0 {
		d.scroll = 0
	}
	si := SCROLLINFO{FMask: SIF_RANGE | SIF_PAGE | SIF_POS, NMin: 0, NMax: int32(d.total - 1), NPage: uint32(page), NPos: int32(d.scroll)}
	si.CbSize = uint32(unsafe.Sizeof(si))
	pSetScrollInfo.Call(d.hwnd, SB_VERT, uintptr(unsafe.Pointer(&si)), 1)
}

func (d *detailPanel) scrollTo(y int) {
	d.scroll = y
	d.updateScroll()
	pInvalidateRect.Call(d.hwnd, 0, 0)
}

func (d *detailPanel) wndProc(hwnd uintptr, msg uint32, w, l uintptr) uintptr {
	switch msg {
	case WM_ERASEBKGND:
		return 1
	case WM_SIZE:
		if d.hwnd != 0 {
			d.relayout()
		}
		return 0
	case WM_PAINT:
		d.paint()
		return 0
	case WM_MOUSEWHEEL:
		delta := int(int16(w >> 16))
		d.scrollTo(d.scroll - delta*d.a.px(56)/120)
		return 0
	case WM_VSCROLL:
		si := SCROLLINFO{FMask: SIF_TRACKPOS | SIF_POS | SIF_PAGE}
		si.CbSize = uint32(unsafe.Sizeof(si))
		pGetScrollInfo.Call(hwnd, SB_VERT, uintptr(unsafe.Pointer(&si)))
		switch w & 0xFFFF {
		case SB_LINEUP:
			d.scrollTo(d.scroll - d.a.px(40))
		case SB_LINEDOWN:
			d.scrollTo(d.scroll + d.a.px(40))
		case SB_PAGEUP:
			d.scrollTo(d.scroll - int(si.NPage))
		case SB_PAGEDOWN:
			d.scrollTo(d.scroll + int(si.NPage))
		case SB_THUMBTRACK, SB_THUMBPOSITION:
			d.scrollTo(int(si.NTrackPos))
		case SB_TOP:
			d.scrollTo(0)
		case SB_BOTTOM:
			d.scrollTo(d.total)
		}
		return 0
	case WM_LBUTTONDOWN:
		pSetFocus.Call(hwnd)
		return 0
	case WM_CONTEXTMENU:
		m, _, _ := pCreatePopupMenu.Call()
		pAppendMenuW.Call(m, MF_STRING, idmCopyDetails, uintptr(unsafe.Pointer(u16("Copy details"))))
		var pt POINT
		pGetCursorPos.Call(uintptr(unsafe.Pointer(&pt)))
		cmd, _, _ := pTrackPopupMenu.Call(m, TPM_RETURNCMD|TPM_RIGHTBUTTON, uintptr(pt.X), uintptr(pt.Y), 0, hwnd, 0)
		pDestroyMenu.Call(m)
		if int(cmd) == idmCopyDetails {
			setClipboard(hwnd, d.plain)
		}
		return 0
	case WM_KEYDOWN:
		if w == 'C' && keyDown(0x11) {
			setClipboard(hwnd, d.plain)
			return 0
		}
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, uintptr(msg), w, l)
	return r
}

func (d *detailPanel) paint() {
	var ps PAINTSTRUCT
	hdc, _, _ := pBeginPaint.Call(d.hwnd, uintptr(unsafe.Pointer(&ps)))
	rc := clientRect(d.hwnd)
	bb := newBackBuffer(hdc, int(rc.Right), int(rc.Bottom))
	c := newCanvas(bb.dc)
	c.fillRect(0, 0, int(rc.Right), int(rc.Bottom), cBg1)
	pad := d.pad()
	y := pad - d.scroll
	for i, r := range d.rows {
		h := d.heights[i]
		if y+h >= 0 && y <= int(rc.Bottom) {
			r.paint(c, pad, y, int(rc.Right)-2*pad, h)
		}
		y += h
	}
	c.close()
	bb.flush(0, 0)
	pEndPaint.Call(d.hwnd, uintptr(unsafe.Pointer(&ps)))
}

// ---------------------------------------------------------------------------
// row builders ("dossier" style)

func (a *app) rGap(h int) drow {
	return drow{func(uintptr, int) int { return a.px(h) }, func(*canvas, int, int, int, int) {}}
}

func (a *app) rText(s string, font uintptr, col Color) drow {
	return drow{
		func(hdc uintptr, w int) int { _, h := measure(hdc, s, font, w, true); return h + a.px(4) },
		func(c *canvas, x, y, w, h int) { c.text(s, x, y, w, h, font, col, DT_WORDBREAK|DT_EDITCONTROL) },
	}
}

func riskColor(r string) Color {
	switch r {
	case RiskSuspicious:
		return cSus
	case RiskReview:
		return cRev
	}
	return cClean
}

func sevColor(s Sev) Color {
	switch s {
	case SevHigh:
		return cSus
	case SevMedium:
		return cRev
	}
	return cInfo
}

func sigColor(status string) Color {
	switch sigSeverity(status) {
	case 0:
		return cClean
	case 1:
		return cDim
	case 2:
		return cRev
	}
	return cSus
}

// rTitle: seal stamp, kind tag, name, path.
func (a *app) rTitle(tag, title, sub, risk string, trusted bool) drow {
	seal := a.px(52)
	gap := a.px(16)
	return drow{
		func(hdc uintptr, w int) int {
			tw := w
			if risk != "" {
				tw -= seal + gap
			}
			_, h1 := measure(hdc, title, a.fName, tw, true)
			_, h2 := measure(hdc, sub, a.fSub, tw, true)
			h := a.px(20) + h1 + h2 + a.px(14)
			if risk != "" && h < seal+a.px(16) {
				h = seal + a.px(16)
			}
			return h
		},
		func(c *canvas, x, y, w, h int) {
			tx, tw := x, w
			if risk != "" {
				it := &Item{Risk: risk, Trusted: trusted}
				ch, code, col := riskSeal(it)
				a.seal(c, x, y+a.px(2), seal, ch, col, a.fCJKSealBig)
				c.textX(code, x, y+seal+a.px(4), seal, a.px(12), a.fLabel, col, DT_SINGLELINE|DT_CENTER, a.px(1))
				tx, tw = x+seal+gap, w-seal-gap
			}
			if parts := strings.SplitN(tag, "  ", 2); len(parts) == 2 {
				cw := a.textWidth(parts[0], a.fCJKSeal)
				c.text(parts[0], tx, y-a.px(2), cw+a.px(4), a.px(18), a.fCJKSeal, cGold, DT_SINGLELINE|DT_VCENTER)
				c.textX(parts[1], tx+cw+a.px(8), y-a.px(2), tw-cw, a.px(18), a.fLabel, cDim, DT_SINGLELINE|DT_VCENTER, a.px(2))
			} else {
				c.textX(tag, tx, y, tw, a.px(16), a.fLabel, cGold, DT_SINGLELINE, a.px(2))
			}
			yy := y + a.px(18)
			_, h1 := measure(c.hdc, title, a.fName, tw, true)
			c.text(title, tx, yy, tw, h1, a.fName, cText, DT_WORDBREAK|DT_EDITCONTROL)
			yy += h1 + a.px(2)
			_, h2 := measure(c.hdc, sub, a.fSub, tw, true)
			c.text(sub, tx, yy, tw, h2, a.fSub, cDim, DT_WORDBREAK|DT_EDITCONTROL)
		},
	}
}

var sectionCJK = map[string]string{"findings": "發現", "task": "任務", "entry": "項目", "certificate": "證書",
	"setting": "設定", "what it runs": "執行檔案", "results": "結果", "notes": "備註", "legend": "圖例", "coverage": "掃描範圍"}

func (a *app) rSection(label string) drow {
	return drow{
		func(uintptr, int) int { return a.px(40) },
		func(c *canvas, x, y, w, h int) {
			cjk := sectionCJK[label]
			cy := y + a.px(14)
			c.fillRound(x, cy+a.px(4), a.px(4), a.px(12), a.px(1), cNeon)
			xx := x + a.px(12)
			if cjk != "" {
				cw := a.textWidth(cjk, a.fCJKSeal)
				c.text(cjk, xx, cy, cw+a.px(4), a.px(20), a.fCJKSeal, cText, DT_SINGLELINE|DT_VCENTER)
				xx += cw + a.px(8)
			}
			en := strings.ToUpper(label)
			ew := a.capsWidth(en, a.fLabel, a.px(2))
			c.textX(en, xx, cy+a.px(1), ew+a.px(4), a.px(20), a.fLabel, cDim, DT_SINGLELINE|DT_VCENTER, a.px(2))
			lx := xx + ew + a.px(12)
			c.fillRect(lx, cy+a.px(10), w-(lx-x), 1, cLine)
		},
	}
}

func (a *app) rFinding(f Finding) drow {
	gx := a.px(24)
	return drow{
		func(hdc uintptr, w int) int {
			_, h := measure(hdc, f.Text, a.fBody, w-gx, true)
			return h + a.px(10)
		},
		func(c *canvas, x, y, w, h int) {
			col := sevColor(f.Sev)
			sz := a.px(10)
			if f.Sev == SevInfo {
				c.fillRound(x+a.px(3), y+a.px(5), a.px(5), a.px(5), a.px(1), col.mix(cBg1, 0.3))
			} else {
				c.fillRound(x, y+a.px(3), sz, sz, a.px(2), col)
			}
			fg := cText
			if f.Sev == SevInfo {
				fg = cText2
			}
			c.text(f.Text, x+gx, y, w-gx, h, a.fBody, fg, DT_WORDBREAK|DT_EDITCONTROL)
		},
	}
}

func (a *app) kvMeasure(hdc uintptr, k, v string, w int, mono bool) int {
	font := a.fBody
	if mono {
		font = a.fMono
	}
	kw := a.px(118)
	_, h := measure(hdc, v, font, w-kw, true)
	if h < a.px(18) {
		h = a.px(18)
	}
	return h + a.px(5)
}

func (a *app) kvPaint(c *canvas, x, y, w int, k, v string, mono bool, col Color) int {
	font := a.fBody
	if mono {
		font = a.fMono
	}
	kw := a.px(118)
	_, h := measure(c.hdc, v, font, w-kw, true)
	if h < a.px(18) {
		h = a.px(18)
	}
	c.text(strings.ToLower(k), x, y, kw-a.px(8), a.px(18), a.fMono, cDim, DT_SINGLELINE|DT_END_ELLIPS)
	c.text(v, x+kw, y, w-kw, h+a.px(2), font, col, DT_WORDBREAK|DT_EDITCONTROL)
	return h + a.px(5)
}

func (a *app) rKV(k, v string, mono bool, col Color) drow {
	return drow{
		func(hdc uintptr, w int) int { return a.kvMeasure(hdc, k, v, w, mono) },
		func(c *canvas, x, y, w, h int) { a.kvPaint(c, x, y, w, k, v, mono, col) },
	}
}

type kvLine struct {
	k, v string
	mono bool
	col  Color
}

func (a *app) rTarget(t Target) drow {
	var lines []kvLine
	add := func(k, v string, mono bool, col Color) {
		if strings.TrimSpace(v) != "" {
			lines = append(lines, kvLine{k, v, mono, col})
		}
	}
	add("path", t.Path, true, cText)
	if !t.Exists {
		add("on disk", "missing", false, cRev)
	}
	add("signer", t.Sig.Signer, false, cText)
	add("issuer", t.Sig.Issuer, false, cText2)
	add("chain root", t.Sig.ChainRoot, false, cText2)
	add("root thumb", t.Sig.RootThumb, true, cText2)
	if t.Sig.UserRoot != "" {
		add("root store", "user store "+t.Sig.UserRoot, false, cSus)
	}
	add("note", t.Sig.Note, false, sigColor(t.Sig.Status))
	add("chain", t.Sig.ChainStatus, false, cText2)
	if t.Sig.Embedded {
		add("verified by", "hongkong + windows", true, cText2)
	}
	add("company", t.Sig.Company, false, cText2)
	add("original", t.Sig.OriginalName, false, cText2)
	if !t.Sig.CompileTime.IsZero() {
		add("built", t.Sig.CompileTime.Format("2006-01-02 15:04"), true, cText2)
	}
	if !t.ModTime.IsZero() {
		add("modified", t.ModTime.Format("2006-01-02 15:04:05"), true, cText2)
	}
	add("sha256", t.SHA256, true, cText2)
	if t.UserWritable {
		add("folder", "user-writable", false, cRev)
	}
	pad := a.px(12)
	header := a.px(30)
	return drow{
		func(hdc uintptr, w int) int {
			h := header + a.px(4)
			for _, l := range lines {
				h += a.kvMeasure(hdc, l.k, l.v, w-2*pad, l.mono)
			}
			return h + a.px(16)
		},
		func(c *canvas, x, y, w, h int) {
			bh := h - a.px(10)
			c.strokeRound(x, y, w, bh, a.px(6), cLine, cBg0)
			sc := sigColor(t.Sig.Status)
			c.fillRound(x, y+a.px(8), a.px(3), bh-a.px(16), a.px(1), sc)
			c.textX(strings.ToUpper(t.Role), x+pad, y+a.px(8), w/2, a.px(16), a.fLabel, cGold, DT_SINGLELINE, a.px(2))
			st := t.Sig.Status
			sw := a.textWidth(st, a.fBodyB)
			c.fillRound(x+w-pad-sw-a.px(16), y+a.px(6), sw+a.px(16), a.px(20), a.px(10), sc.mix(cBg0, 0.82))
			c.text(st, x+w-pad-sw-a.px(8), y+a.px(6), sw+a.px(4), a.px(20), a.fBodyB, sc, DT_SINGLELINE|DT_VCENTER)
			c.fillRect(x+pad, y+header-a.px(2), w-2*pad, 1, cLine)
			yy := y + header + a.px(4)
			for _, l := range lines {
				yy += a.kvPaint(c, x+pad, yy, w-2*pad, l.k, l.v, l.mono, l.col)
			}
		},
	}
}

// ---------------------------------------------------------------------------
// content

var kindTag = map[string]string{"task": "排程任務  SCHEDULED TASK", "autostart": "自啟動  AUTOSTART", "cert": "證書  CERTIFICATE", "system": "系統  SYSTEM CHECK"}

func (a *app) showItem(it *Item) {
	sub := it.Path
	if it.Kind == "autostart" {
		sub = it.Location + "  ·  " + it.Path
	}
	rows := []drow{a.rTitle(kindTag[it.Kind], it.Name, sub, it.Risk, it.Trusted)}
	rows = append(rows, a.rSection("findings"))
	if len(it.Findings) == 0 {
		rows = append(rows, a.rText("Nothing notable.", a.fBody, cDim))
	}
	for _, f := range it.Findings {
		rows = append(rows, a.rFinding(f))
	}
	rows = append(rows, a.rSection(map[string]string{"task": "task", "cert": "certificate", "system": "setting"}[it.Kind]+map[bool]string{true: "entry", false: ""}[it.Kind == "autostart"]))
	kv := func(k, v string, mono bool) {
		if strings.TrimSpace(v) != "" {
			rows = append(rows, a.rKV(k, v, mono, cText))
		}
	}
	if it.Kind != "cert" {
		kv("command", it.Command, true)
		kv("triggers", strings.Join(it.Triggers, ", "), false)
		if it.Kind == "task" {
			state := "enabled"
			if !it.Enabled {
				state = "disabled"
			}
			if it.Hidden {
				state += ", hidden"
			}
			kv("state", state, false)
		}
		kv("run as", strings.TrimSpace(it.RunAs+" "+it.RunLevel), false)
		kv("source", it.Source, false)
		kv("author", it.Author, false)
		kv("registered", it.RegDate, true)
		if !it.Modified.IsZero() {
			kv("modified", it.Modified.Format("2006-01-02 15:04"), true)
		}
		kv("description", it.Description, false)
		kv("xml file", it.XMLFile, true)
	}
	for _, d := range it.Details {
		mono := d.K == "Thumbprint" || d.K == "Serial" || strings.Contains(d.K, "Id") || d.K == "Store"
		kv(d.K, d.V, mono)
	}
	if len(it.Targets) > 0 {
		rows = append(rows, a.rSection("what it runs"))
		for _, t := range it.Targets {
			rows = append(rows, a.rTarget(t))
		}
	}
	a.detail.set(rows, detailText(it))
}

func (a *app) showOverview() {
	var rows []drow
	if a.res == nil {
		rows = append(rows,
			a.rTitle("掃描中  SCANNING", "Checking this PC", "Tasks · TaskCache · services · drivers · Run keys · Winlogon · LSA · WMI · certificates · system settings", "", false),
			a.rSection("coverage"),
			a.rFinding(Finding{SevHigh, 0, "Forged, self-signed and untrusted-root signatures, including fake Microsoft roots planted in the certificate store"}),
			a.rFinding(Finding{SevHigh, 0, "Tampered files, data smuggled inside signatures, timestamp cloning"}),
			a.rFinding(Finding{SevHigh, 0, "Hidden and mismatched tasks, IFEO / COM / accessibility hijacks, vulnerable kernel drivers"}),
			a.rFinding(Finding{SevMedium, 0, "Test signing, Defender exclusions and other weakened security settings"}),
		)
		a.detail.set(rows, "")
		return
	}
	r := a.res
	sub := fmt.Sprintf("%s  ·  %s  ·  %s", r.Host, r.User, r.Generated.Format("2006-01-02 15:04"))
	rows = append(rows, a.rTitle("報告  OVERVIEW", "Scan report", sub, "", false))
	rows = append(rows, a.rSection("results"),
		a.rKV("threats", fmt.Sprint(r.Summary.Suspicious), true, cSus),
		a.rKV("review", fmt.Sprint(r.Summary.Review), true, cRev),
		a.rKV("clean", fmt.Sprint(r.Summary.Clean), true, cClean),
		a.rKV("tasks", fmt.Sprint(r.Summary.Tasks), true, cText),
		a.rKV("autostart", fmt.Sprint(r.Summary.Autostart), true, cText),
		a.rKV("certificates", fmt.Sprint(r.Summary.Certs), true, cText),
		a.rKV("system checks", fmt.Sprint(r.Summary.System), true, cText),
		a.rKV("trusted", fmt.Sprint(len(a.trust.Keys)), true, cInfo),
		a.rKV("elevated", fmt.Sprint(r.Elevated), true, cText),
		a.rKV("duration", fmt.Sprintf("%.1fs", r.Duration.Seconds()), true, cText),
	)
	if len(r.Notes) > 0 {
		rows = append(rows, a.rSection("notes"))
		for _, n := range r.Notes {
			rows = append(rows, a.rFinding(Finding{SevInfo, 0, n}))
		}
	}
	rows = append(rows, a.rSection("legend"),
		a.rFinding(Finding{SevHigh, 0, "Threat: strong evidence. Forged or self-signed signature, tampered file, hidden or mismatched task, hijack, encoded command"}),
		a.rFinding(Finding{SevMedium, 0, "Review: worth a look. Unsigned file, untrusted file in a user folder, vulnerable driver, user-installed root"}),
		a.rFinding(Finding{SevInfo, 0, "Right-click a row to act on it or mark it trusted. Clean items are hidden unless Show clean is on."}),
	)
	a.detail.set(rows, "")
}
