package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// User allowlist ("Mark as trusted"). Keys include the SHA-256 of every file
// an item runs, so trust silently expires if a trusted file is swapped.

type UserTrust struct {
	Keys map[string]string `json:"trusted"` // key -> display label
	path string
}

func trustKey(it *Item) string {
	switch it.Kind {
	case "cert":
		return "cert|" + strings.ToUpper(it.Command)
	case "system":
		return "system|" + strings.ToLower(it.Name+"|"+it.Command)
	}
	var parts []string
	for _, t := range it.Targets {
		if t.SHA256 != "" {
			parts = append(parts, t.SHA256)
		} else {
			parts = append(parts, "path:"+strings.ToLower(t.Path)+"|"+t.Sig.Status)
		}
	}
	sort.Strings(parts)
	return it.Kind + "|" + strings.ToLower(it.Location+"|"+it.Path+"|"+it.Name) + "|" + strings.Join(parts, ",")
}

func loadUserTrust(path string) *UserTrust {
	ut := &UserTrust{Keys: map[string]string{}, path: path}
	if b, err := os.ReadFile(path); err == nil {
		json.Unmarshal(b, ut)
		if ut.Keys == nil {
			ut.Keys = map[string]string{}
		}
	}
	return ut
}

func (ut *UserTrust) save() error {
	if ut.path == "" {
		return nil
	}
	os.MkdirAll(filepath.Dir(ut.path), 0o755)
	b, _ := json.MarshalIndent(ut, "", "  ")
	return os.WriteFile(ut.path, b, 0o644)
}

func (ut *UserTrust) has(it *Item) bool {
	_, ok := ut.Keys[trustKey(it)]
	return ok
}

// setTrusted marks or unmarks an item and updates its findings in place.
func (ut *UserTrust) setTrusted(it *Item, on bool) {
	k := trustKey(it)
	if on {
		ut.Keys[k] = it.Kind + ": " + it.Name
	} else {
		delete(ut.Keys, k)
	}
	applyTrustTo(it, on)
}

func applyTrustTo(it *Item, on bool) {
	if on && !it.Trusted {
		it.original = append([]Finding(nil), it.Findings...)
		fs := []Finding{{Sev: SevInfo, Text: "Marked as trusted by you (findings kept for reference)"}}
		for _, f := range it.Findings {
			f.Sev = SevInfo
			fs = append(fs, f)
		}
		it.Findings, it.Trusted = fs, true
	} else if !on && it.Trusted {
		it.Findings, it.Trusted = it.original, false
	}
	it.computeRisk()
}

func (r *ScanResult) applyUserTrust(ut *UserTrust) {
	if ut == nil {
		return
	}
	for _, list := range [][]*Item{r.Tasks, r.Autostart, r.Certs, r.System} {
		for _, it := range list {
			if ut.has(it) {
				applyTrustTo(it, true)
			}
		}
	}
	r.summarize()
}
