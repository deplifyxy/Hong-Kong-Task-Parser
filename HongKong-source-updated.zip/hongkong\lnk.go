package main

import (
	"encoding/binary"
	"errors"
	"strings"
)

// LnkInfo is the subset of a Shell Link (.lnk, MS-SHLLINK) that matters for persistence.
type LnkInfo struct {
	Target     string
	Arguments  string
	WorkingDir string
	RelPath    string
}

const (
	lnkHasIDList   = 0x1
	lnkHasLinkInfo = 0x2
	lnkHasName     = 0x4
	lnkHasRelPath  = 0x8
	lnkHasWorkDir  = 0x10
	lnkHasArgs     = 0x20
	lnkHasIcon     = 0x40
	lnkIsUnicode   = 0x80
)

var errLnk = errors.New("not a valid .lnk file")

func cstr(b []byte, off int) string {
	if off < 0 || off >= len(b) {
		return ""
	}
	end := off
	for end < len(b) && b[end] != 0 {
		end++
	}
	return string(b[off:end])
}

func cwstr(b []byte, off int) string {
	if off < 0 || off >= len(b) {
		return ""
	}
	end := off
	for end+1 < len(b) && !(b[end] == 0 && b[end+1] == 0) {
		end += 2
	}
	return utf16le(b[off:end])
}

func parseLnk(b []byte) (*LnkInfo, error) {
	if len(b) < 0x4C || binary.LittleEndian.Uint32(b) != 0x4C ||
		binary.LittleEndian.Uint32(b[4:]) != 0x00021401 {
		return nil, errLnk
	}
	flags := binary.LittleEndian.Uint32(b[0x14:])
	off := 0x4C
	if flags&lnkHasIDList != 0 {
		if off+2 > len(b) {
			return nil, errLnk
		}
		off += 2 + int(binary.LittleEndian.Uint16(b[off:]))
	}
	info := &LnkInfo{}
	if flags&lnkHasLinkInfo != 0 {
		if off+0x1C > len(b) {
			return nil, errLnk
		}
		li := b[off:]
		size := int(binary.LittleEndian.Uint32(li))
		if size < 0x1C || size > len(li) {
			return nil, errLnk
		}
		li = li[:size]
		hdr := binary.LittleEndian.Uint32(li[4:])
		liFlags := binary.LittleEndian.Uint32(li[8:])
		baseOff := int(binary.LittleEndian.Uint32(li[0x10:]))
		suffixOff := int(binary.LittleEndian.Uint32(li[0x18:]))
		var base, suffix string
		if hdr >= 0x24 && len(li) >= 0x24 {
			if u := int(binary.LittleEndian.Uint32(li[0x1C:])); u > 0 {
				base = cwstr(li, u)
			}
			if u := int(binary.LittleEndian.Uint32(li[0x20:])); u > 0 {
				suffix = cwstr(li, u)
			}
		}
		if base == "" && liFlags&1 != 0 {
			base = cstr(li, baseOff)
		}
		if suffix == "" {
			suffix = cstr(li, suffixOff)
		}
		info.Target = base + suffix
		off += size
	}
	readStr := func() (string, error) {
		if off+2 > len(b) {
			return "", errLnk
		}
		n := int(binary.LittleEndian.Uint16(b[off:]))
		off += 2
		if flags&lnkIsUnicode != 0 {
			if off+2*n > len(b) {
				return "", errLnk
			}
			s := utf16le(b[off : off+2*n])
			off += 2 * n
			return s, nil
		}
		if off+n > len(b) {
			return "", errLnk
		}
		s := string(b[off : off+n])
		off += n
		return s, nil
	}
	order := []struct {
		bit uint32
		dst *string
	}{
		{lnkHasName, nil}, {lnkHasRelPath, &info.RelPath}, {lnkHasWorkDir, &info.WorkingDir},
		{lnkHasArgs, &info.Arguments}, {lnkHasIcon, nil},
	}
	for _, o := range order {
		if flags&o.bit == 0 {
			continue
		}
		s, err := readStr()
		if err != nil {
			return info, nil // keep what we have
		}
		if o.dst != nil {
			*o.dst = s
		}
	}
	// ExtraData: EnvironmentVariableDataBlock carries %VAR% targets.
	for off+8 <= len(b) {
		size := int(binary.LittleEndian.Uint32(b[off:]))
		if size < 8 || off+size > len(b) {
			break
		}
		sig := binary.LittleEndian.Uint32(b[off+4:])
		if sig == 0xA0000001 && size >= 0x314 && info.Target == "" {
			if t := cwstr(b[off+8+260:off+size], 0); t != "" {
				info.Target = t
			} else {
				info.Target = cstr(b[off+8:off+8+260], 0)
			}
		}
		off += size
	}
	if info.Target == "" && info.RelPath != "" {
		info.Target = info.RelPath
	}
	info.Target = strings.TrimSpace(info.Target)
	return info, nil
}
