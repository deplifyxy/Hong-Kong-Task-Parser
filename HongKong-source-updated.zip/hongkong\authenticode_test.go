package main

import (
	"os"
	"testing"
	"time"
)

var nowForTest = time.Date(2026, 11, 5, 0, 0, 0, 0, time.UTC)

func readOrSkip(t *testing.T, p string) []byte {
	t.Helper()
	b, err := os.ReadFile(p)
	if err != nil {
		t.Skip("fixture not available: " + p)
	}
	return b
}

func TestEmbeddedSignatures(t *testing.T) {
	dir := os.Getenv("HK_FIXTURES")
	if dir == "" {
		t.Skip("set HK_FIXTURES")
	}
	cases := []struct {
		file                      string
		present, digest, sigOK    bool
		topSelf, claimsMS, forged bool
	}{
		{"HongKong.exe", true, true, true, true, false, false},
		{"ClubhouseAnchor.exe", true, true, true, true, false, false},
		{"sample.bin", true, true, true, true, true, true},
		{"VigilsTaskParser.exe", false, false, false, false, false, false},
	}
	db := newTrustDB()
	for _, c := range cases {
		es := VerifyEmbedded(readOrSkip(t, dir+"/"+c.file))
		top := ""
		leaf := ""
		if es.Top != nil {
			top, leaf = es.Top.Subject.String(), es.Signer.Subject.String()
		}
		forged, _ := db.rootVerdict(es.TopThumb, top, leaf, notBefore(es.Top), nowForTest)
		t.Logf("%-22s present=%v err=%q alg=%s digest=%v sig=%v chain=%d topSelf=%v top=%q thumb=%s broken=%q forged=%v",
			c.file, es.Present, es.ParseErr, es.DigestAlg, es.DigestOK, es.SignatureOK, len(es.Chain), es.TopSelf, firstCN(top), es.TopThumb, es.ChainBroken, forged)
		if es.Present != c.present || es.DigestOK != c.digest || es.SignatureOK != c.sigOK || es.TopSelf != c.topSelf ||
			claimsMicrosoft(top, leaf) != c.claimsMS || forged != c.forged {
			t.Errorf("%s: unexpected verdict", c.file)
		}
	}
	// Tampering: flip one byte in the code of a signed file.
	b := readOrSkip(t, dir+"/HongKong.exe")
	b[0x1000] ^= 0xFF
	if es := VerifyEmbedded(b); !es.Present || es.DigestOK {
		t.Errorf("tampered file not detected: %+v", es.DigestOK)
	}
}
