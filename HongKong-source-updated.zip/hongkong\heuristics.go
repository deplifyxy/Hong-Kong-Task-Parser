package main

import (
	"math"
	"path"
	"regexp"
	"strings"
)

// winPath helpers operate on Windows-style paths regardless of the build OS so
// the logic can be unit-tested anywhere.

func winBase(p string) string {
	p = strings.ReplaceAll(p, "/", `\`)
	if i := strings.LastIndex(p, `\`); i >= 0 {
		return p[i+1:]
	}
	return p
}

func winDir(p string) string {
	p = strings.ReplaceAll(p, "/", `\`)
	if i := strings.LastIndex(p, `\`); i >= 0 {
		return p[:i]
	}
	return ""
}

func winJoin(a, b string) string {
	if a == "" {
		return b
	}
	return strings.TrimRight(a, `\`) + `\` + strings.TrimLeft(b, `\`)
}

func winExt(p string) string { return strings.ToLower(path.Ext(winBase(p))) }

func isAbsWin(p string) bool {
	return (len(p) >= 3 && p[1] == ':' && (p[2] == '\\' || p[2] == '/')) || strings.HasPrefix(p, `\\`)
}

var envVarRe = regexp.MustCompile(`%([A-Za-z0-9_()]+)%`)

// expandWinEnv expands %VAR% references using getenv; unknown variables stay as-is.
func expandWinEnv(s string, getenv func(string) string) string {
	return envVarRe.ReplaceAllStringFunc(s, func(m string) string {
		if v := getenv(m[1 : len(m)-1]); v != "" {
			return v
		}
		return m
	})
}

func unquote(s string) string {
	s = strings.TrimSpace(s)
	if len(s) >= 2 && s[0] == '"' && s[len(s)-1] == '"' {
		return s[1 : len(s)-1]
	}
	return strings.Trim(s, `"`)
}

var execExts = map[string]bool{".exe": true, ".com": true, ".bat": true, ".cmd": true, ".ps1": true,
	".vbs": true, ".vbe": true, ".js": true, ".jse": true, ".wsf": true, ".wsh": true, ".hta": true,
	".lnk": true, ".scr": true, ".cpl": true, ".msi": true, ".dll": true, ".jar": true, ".py": true,
	".pyw": true, ".psm1": true, ".url": true, ".msc": true, ".sys": true, ".ocx": true}

// Resolver resolves command names to files using a filesystem view.
type Resolver struct {
	Getenv func(string) string
	Exists func(string) bool
}

func (r Resolver) systemRoot() string {
	if v := r.Getenv("SystemRoot"); v != "" {
		return v
	}
	return `C:\Windows`
}

// Resolve turns a command (possibly relative, env-laden, quoted, extension-less)
// into an absolute path. It returns the best guess even when the file is missing.
func (r Resolver) Resolve(cmd, workDir string) string {
	c := expandWinEnv(unquote(cmd), r.Getenv)
	if c == "" {
		return ""
	}
	c = strings.ReplaceAll(c, "/", `\`)
	candidates := []string{c}
	if winExt(c) == "" {
		candidates = append(candidates, c+".exe")
	}
	if isAbsWin(c) {
		for _, x := range candidates {
			if r.Exists(x) {
				return x
			}
		}
		return candidates[len(candidates)-1]
	}
	var dirs []string
	if workDir != "" {
		dirs = append(dirs, expandWinEnv(unquote(workDir), r.Getenv))
	}
	sr := r.systemRoot()
	dirs = append(dirs, winJoin(sr, "System32"), sr, winJoin(sr, `System32\Wbem`),
		winJoin(sr, `System32\WindowsPowerShell\v1.0`))
	for _, d := range strings.Split(r.Getenv("PATH"), ";") {
		if d = strings.TrimSpace(expandWinEnv(d, r.Getenv)); d != "" {
			dirs = append(dirs, d)
		}
	}
	if strings.Contains(c, `\`) { // relative path with directories: only the working dir applies
		if workDir != "" {
			dirs = []string{expandWinEnv(unquote(workDir), r.Getenv)}
		} else {
			dirs = []string{winJoin(sr, "System32")}
		}
	}
	for _, d := range dirs {
		for _, x := range candidates {
			p := winJoin(d, x)
			if r.Exists(p) {
				return p
			}
		}
	}
	// Not found anywhere: default to System32 for bare names.
	if !strings.Contains(c, `\`) {
		return winJoin(winJoin(sr, "System32"), candidates[len(candidates)-1])
	}
	return c
}

// SplitCommandLine splits a full command line (Run keys, Winlogon, IFEO) into
// executable and arguments, coping with unquoted paths containing spaces.
func (r Resolver) SplitCommandLine(line string) (exe, args string) {
	line = strings.TrimSpace(line)
	if line == "" {
		return "", ""
	}
	if line[0] == '"' {
		if end := strings.Index(line[1:], `"`); end >= 0 {
			return line[1 : end+1], strings.TrimSpace(line[end+2:])
		}
		return strings.Trim(line, `"`), ""
	}
	parts := strings.Split(line, " ")
	firstWithExt := -1
	for i := 1; i <= len(parts); i++ {
		cand := strings.Join(parts[:i], " ")
		expanded := expandWinEnv(cand, r.Getenv)
		if isAbsWin(expanded) && r.Exists(expanded) {
			return cand, strings.TrimSpace(strings.Join(parts[i:], " "))
		}
		if firstWithExt < 0 && execExts[winExt(cand)] {
			firstWithExt = i
		}
	}
	if firstWithExt > 0 {
		return strings.Join(parts[:firstWithExt], " "), strings.TrimSpace(strings.Join(parts[firstWithExt:], " "))
	}
	return parts[0], strings.TrimSpace(strings.Join(parts[1:], " "))
}

// ---------------------------------------------------------------------------

var execHosts = map[string]bool{
	"powershell.exe": true, "pwsh.exe": true, "cmd.exe": true, "wscript.exe": true, "cscript.exe": true,
	"mshta.exe": true, "rundll32.exe": true, "regsvr32.exe": true, "msiexec.exe": true, "certutil.exe": true,
	"bitsadmin.exe": true, "conhost.exe": true, "forfiles.exe": true, "wmic.exe": true, "hh.exe": true,
	"msbuild.exe": true, "installutil.exe": true, "regasm.exe": true, "regsvcs.exe": true, "cmstp.exe": true,
	"schtasks.exe": true, "curl.exe": true, "msxsl.exe": true, "odbcconf.exe": true, "pcalua.exe": true,
	"scriptrunner.exe": true, "syncappvpublishingserver.exe": true, "java.exe": true, "javaw.exe": true,
	"python.exe": true, "pythonw.exe": true, "node.exe": true, "bash.exe": true, "wsl.exe": true,
}

// System binary names commonly borrowed by malware.
var systemNames = map[string]bool{
	"svchost.exe": true, "lsass.exe": true, "csrss.exe": true, "winlogon.exe": true, "explorer.exe": true,
	"services.exe": true, "smss.exe": true, "rundll32.exe": true, "taskhostw.exe": true, "dllhost.exe": true,
	"conhost.exe": true, "spoolsv.exe": true, "wininit.exe": true, "taskhost.exe": true, "sihost.exe": true,
	"ctfmon.exe": true, "runtimebroker.exe": true, "searchindexer.exe": true, "taskmgr.exe": true,
	"wuauclt.exe": true, "lsm.exe": true, "dwm.exe": true, "audiodg.exe": true, "fontdrvhost.exe": true,
}

func isSystemDir(p string) bool {
	d := strings.ToLower(winDir(p))
	for _, s := range []string{`\windows\system32`, `\windows\syswow64`, `\windows`, `\windows\winsxs`} {
		if strings.HasSuffix(d, s) {
			return true
		}
	}
	return strings.Contains(d, `\windows\winsxs\`) || strings.Contains(d, `\windows\servicing\`)
}

func isMasquerading(p string) bool {
	if p == "" || !isAbsWin(p) {
		return false
	}
	return systemNames[strings.ToLower(winBase(p))] && !isSystemDir(p)
}

var userWritableMarkers = []string{`\appdata\`, `\temp\`, `\tmp\`, `\users\public\`, `\programdata\`,
	`\downloads\`, `\desktop\`, `\documents\`, `\$recycle.bin\`, `\perflogs\`, `\windows\tasks\`,
	`\windows\tracing\`, `\spool\drivers\color\`}

func isUserWritable(p string) bool {
	l := strings.ToLower(strings.ReplaceAll(p, "/", `\`))
	if l == "" {
		return false
	}
	for _, m := range userWritableMarkers {
		if strings.Contains(l, m) {
			return true
		}
	}
	// Directly in a drive root (C:\x.exe) is writable by authenticated users on many builds.
	return len(l) > 3 && l[1] == ':' && strings.Count(l, `\`) == 1
}

type staticRule struct {
	re     *regexp.Regexp
	reason string
	strong bool // strong indicators alone make an item Suspicious
}

var staticRules = []staticRule{
	{regexp.MustCompile(`(?i)(^|\s)[-/]e(nc|ncodedcommand|c|ncoded)?\s+[A-Za-z0-9+/=]{20,}`), "Encoded PowerShell command", true},
	{regexp.MustCompile(`(?i)frombase64string`), "Base64 decoding in arguments", true},
	{regexp.MustCompile(`(?i)\b(iex|invoke-expression)\b`), "Invoke-Expression", true},
	{regexp.MustCompile(`(?i)downloadstring|downloadfile|downloaddata|net\.webclient|invoke-webrequest|\biwr\b|invoke-restmethod|\birm\b|start-bitstransfer`), "Download cradle", true},
	{regexp.MustCompile(`(?i)bitsadmin.*/transfer|certutil.*(-urlcache|-decode|-decodehex)`), "LOLBin download / decode", true},
	{regexp.MustCompile(`(?i)/i:https?|scrobj\.dll`), "Squiblydoo (regsvr32 scriptlet)", true},
	{regexp.MustCompile(`(?i)\b(javascript|vbscript):`), "Inline script protocol", true},
	{regexp.MustCompile(`(?i)(add|set)-mppreference|exclusionpath|disablerealtimemonitoring`), "Defender tampering", true},
	{regexp.MustCompile(`(?i)\b(vssadmin|wbadmin)\b.*delete|bcdedit.*recoveryenabled`), "Recovery tampering", true},
	{regexp.MustCompile(`[A-Za-z0-9+/]{200,}={0,2}`), "Long base64 blob", true},
	{regexp.MustCompile(`(\^.){4,}`), "Caret obfuscation", true},
	{regexp.MustCompile(`(?i)\[char\]\s*\d+\s*\+|-bxor`), "String obfuscation", true},
	{regexp.MustCompile(`(?i)\bhttps?://`), "URL in arguments", false},
	{regexp.MustCompile(`(?i)ms-msdt:`), "MSDT / Follina protocol launcher", true},
	{regexp.MustCompile(`(?i)schtasks(\.exe)?\b[^|]*\s/[rc]reate\b`), "Task creates or runs another scheduled task", true},
	{regexp.MustCompile(`(?i)[-/]w(indowstyle)?\s+h(idden)?\b`), "Hidden window", false},
	{regexp.MustCompile(`(?i)[-/](ep|exec|executionpolicy)\s+(bypass|unrestricted)`), "Execution policy bypass", false},
	{regexp.MustCompile(`(?i)conhost(\.exe)?\s+--headless`), "Headless conhost", false},
}

type staticHit struct {
	reason string
	strong bool
}

func staticAnalysis(cmdline string) []staticHit {
	var out []staticHit
	seen := map[string]bool{}
	for _, r := range staticRules {
		if r.re.MatchString(cmdline) && !seen[r.reason] {
			seen[r.reason] = true
			out = append(out, staticHit{r.reason, r.strong})
		}
	}
	return out
}

var scriptExts = map[string]bool{".ps1": true, ".psm1": true, ".bat": true, ".cmd": true, ".vbs": true,
	".vbe": true, ".js": true, ".jse": true, ".wsf": true, ".wsh": true, ".hta": true, ".py": true, ".pyw": true}

var binaryExts = map[string]bool{".exe": true, ".dll": true, ".sys": true, ".cpl": true, ".ocx": true,
	".scr": true, ".com": true}

// inWindowsDir reports a path directly under the Windows directory, System32 or
// SysWOW64 (not Temp, Tasks or other writable subfolders).
func inWindowsDir(p, systemRoot string) bool {
	d := strings.ToLower(winDir(p))
	sr := strings.ToLower(strings.TrimRight(systemRoot, `\`))
	return d == sr || d == sr+`\system32` || d == sr+`\syswow64` ||
		d == sr+`\system32\wbem` || d == sr+`\system32\windowspowershell\v1.0`
}

// Original file names of system binaries that attackers like to copy and rename.
var lolbinOriginal = map[string]bool{
	"powershell.exe": true, "pwsh.dll": true, "cmd.exe": true, "wscript.exe": true, "cscript.exe": true,
	"mshta.exe": true, "rundll32.exe": true, "regsvr32.exe": true, "msiexec.exe": true, "certutil.exe": true,
	"bitsadmin.exe": true, "wmic.exe": true, "msbuild.exe": true, "installutil.exe": true, "regasm.exe": true,
	"regsvcs.exe": true, "cmstp.exe": true, "schtasks.exe": true, "curl.exe": true, "conhost.exe": true,
	"svchost.exe": true, "explorer.exe": true, "taskmgr.exe": true,
}

func normOriginalName(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	return strings.TrimSuffix(s, ".mui")
}

var vendorRe = regexp.MustCompile(`(?i)\b(microsoft|windows|google|nvidia|intel|amd|apple|adobe|oracle|valve|steam|riot|vanguard|epic games|discord|logitech|razer|corsair|realtek|mozilla|vmware|dell|hp|lenovo|asus|msi|cisco|zoom|spotify|battleye|easyanticheat|easy anti-cheat|faceit|activision|ubisoft|electronic arts|sony|samsung|avast|kaspersky|eset|bitdefender|malwarebytes)\b`)

// impersonatedVendor returns the well-known vendor named by an untrusted signer.
func impersonatedVendor(signer string) string {
	return vendorRe.FindString(signer)
}

// shannon returns the Shannon entropy in bits per character.
func shannon(s string) float64 {
	if s == "" {
		return 0
	}
	counts := map[rune]int{}
	n := 0
	for _, c := range s {
		counts[c]++
		n++
	}
	var h float64
	for _, c := range counts {
		p := float64(c) / float64(n)
		h -= p * math.Log2(p)
	}
	return math.Round(h*100) / 100
}

var (
	quotedFileRe   = regexp.MustCompile(`(?i)"([^"]+\.(exe|dll|ps1|psm1|vbs|vbe|js|jse|wsf|hta|bat|cmd|lnk|scr|cpl|jar|py|pyw|msi|sys|ocx))"`)
	unquotedFileRe = regexp.MustCompile(`(?i)((?:[a-z]:\\|\\\\|%[a-z0-9_]+%\\?)[^\s",;|<>]*\.(exe|dll|ps1|psm1|vbs|vbe|js|jse|wsf|hta|bat|cmd|lnk|scr|cpl|jar|py|pyw|msi|sys|ocx))\b`)
)

// argumentFiles extracts file paths that the arguments point at (scripts, DLLs ...).
func argumentFiles(args string) []string {
	var out []string
	seen := map[string]bool{}
	add := func(s string) {
		s = strings.TrimSpace(s)
		k := strings.ToLower(s)
		if s != "" && !seen[k] {
			seen[k] = true
			out = append(out, s)
		}
	}
	rest := args
	for _, m := range quotedFileRe.FindAllStringSubmatch(args, -1) {
		add(m[1])
		rest = strings.Replace(rest, m[0], " ", 1)
	}
	for _, m := range unquotedFileRe.FindAllStringSubmatch(rest, -1) {
		add(m[1])
	}
	// rundll32 a.dll,Entry
	return out
}

// normalizeDllArg strips the ",Entry" suffix used by rundll32.
func normalizeDllArg(p string) string {
	if i := strings.Index(strings.ToLower(p), ".dll,"); i >= 0 {
		return p[:i+4]
	}
	return p
}

func isPrivileged(runAs, runLevel string) bool {
	u := strings.ToLower(strings.TrimSpace(runAs))
	if strings.EqualFold(runLevel, "HighestAvailable") {
		return true
	}
	switch u {
	case "s-1-5-18", "system", "nt authority\\system", "localsystem", "s-1-5-32-544":
		return true
	}
	return false
}

type trick struct {
	sev  Sev
	text string
}

var docExts = map[string]bool{".pdf": true, ".doc": true, ".docx": true, ".xls": true, ".xlsx": true, ".txt": true,
	".jpg": true, ".jpeg": true, ".png": true, ".gif": true, ".mp4": true, ".mp3": true, ".zip": true, ".rar": true, ".html": true}

// execHostQuirks flags exec hosts used in odd ways: rundll32 without a
// "<file>.dll,<Entry>" argument, and conhost.exe acting as the launcher.
func execHostQuirks(base, args string) []trick {
	var out []trick
	arg := strings.TrimSpace(args)
	switch base {
	case "rundll32.exe":
		if arg == "" {
			out = append(out, trick{SevMedium, "rundll32.exe runs with no DLL or entry-point argument"})
		} else if !strings.Contains(strings.ToLower(arg), ".dll") {
			out = append(out, trick{SevMedium, "rundll32.exe runs without a .dll entry point: " + arg})
		}
	case "conhost.exe":
		txt := "console host used as the action: it spawns a child process the task never names directly"
		if arg != "" {
			txt += " (" + arg + ")"
		}
		out = append(out, trick{SevMedium, txt})
	}
	return out
}

// chainedHost returns the program an exec host front-loads, when cmd.exe or
// conhost.exe merely wrap it (cmd /c powershell ..., conhost --headless x ...).
// The rest of the child command line is returned for reporting.
func (r Resolver) chainedHost(base, args string) (host, rest string) {
	rest = strings.TrimSpace(args)
	switch base {
	case "cmd.exe":
		low := strings.ToLower(rest)
		if strings.HasPrefix(low, "/c ") || strings.HasPrefix(low, "/k ") {
			rest = strings.TrimSpace(rest[3:])
		} else if strings.HasPrefix(low, "/c") || strings.HasPrefix(low, "/k") {
			rest = strings.TrimSpace(rest[2:])
		}
	case "conhost.exe":
		if f := strings.Fields(rest); len(f) > 0 && (strings.EqualFold(f[0], "--headless") || f[0] == "0x4") {
			rest = strings.TrimSpace(strings.Join(f[1:], " "))
		}
	default:
		return "", ""
	}
	if rest == "" {
		return "", ""
	}
	exe, _ := r.SplitCommandLine(rest)
	name := strings.ToLower(winBase(exe))
	if exe != "" && execHosts[name] {
		return name, rest
	}
	return "", ""
}

// pathTricks finds ways a path hides what it really is.
func pathTricks(p string) []trick {
	var out []trick
	if p == "" {
		return nil
	}
	rest := strings.TrimPrefix(strings.TrimPrefix(p, `\\?\`), `\??\`)
	if len(rest) >= 2 && rest[1] == ':' {
		rest = rest[2:]
	}
	if strings.Contains(rest, ":") {
		out = append(out, trick{SevHigh, "Runs code from an NTFS alternate data stream: " + p})
	}
	for _, r := range p {
		if r == 0x202E || r == 0x202D || r == 0x200F || r == 0x200E || (r >= 0x2066 && r <= 0x2069) {
			out = append(out, trick{SevHigh, "File name contains a hidden text-direction character (disguised extension)"})
			break
		}
	}
	base := winBase(p)
	if t := strings.TrimRight(base, " ."); t != base && t != "" {
		out = append(out, trick{SevHigh, "File name ends with a space or dot (Windows path-normalisation trick): \"" + base + "\""})
	}
	if ext := winExt(base); execExts[ext] {
		inner := winExt(strings.TrimSuffix(strings.ToLower(base), ext))
		if docExts[inner] {
			out = append(out, trick{SevMedium, "Double extension disguises a program as a document: " + base})
		}
	}
	return out
}
