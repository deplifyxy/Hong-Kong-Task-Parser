package main

import (
	"bytes"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha1"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"math/big"
	"os"
	"strings"
	"testing"
	"time"
	"unicode/utf16"
)

// ---------------------------------------------------------------------------
// fake Windows

var errFake = errors.New("fake: not found")

type fakeKey struct {
	vals map[string]RegValue
	subs []string
}

type fakePlatform struct {
	env    map[string]string
	files  map[string][]byte // lower-cased path -> content
	dirs   map[string][]string
	mod    map[string]time.Time
	tasks  []TaskFile
	reg    map[string]*fakeKey // "HKLM\\path" lower-cased
	regMod map[string]time.Time
	sigs   map[string]SigInfo
	// failSigs simulates PowerShell being unavailable.
	failSigs bool
	wmi      []WMIConsumer
	denied   map[string]bool
}

func newFake() *fakePlatform {
	return &fakePlatform{
		env: map[string]string{"SystemRoot": `C:\Windows`, "windir": `C:\Windows`, "SystemDrive": "C:", "ProgramData": `C:\ProgramData`,
			"PATH": `C:\Windows\system32;C:\Windows`, "LOCALAPPDATA": `C:\Users\bob\AppData\Local`},
		files: map[string][]byte{}, dirs: map[string][]string{}, mod: map[string]time.Time{},
		reg: map[string]*fakeKey{}, regMod: map[string]time.Time{}, sigs: map[string]SigInfo{},
	}
}

func (f *fakePlatform) key(root, path string) string {
	k := strings.ToUpper(root)
	if path != "" {
		k += `\` + path
	}
	return strings.ToLower(k)
}

func (f *fakePlatform) ensure(full string) *fakeKey {
	parts := strings.Split(full, `\`)
	for i := 1; i <= len(parts); i++ {
		k := strings.ToLower(strings.Join(parts[:i], `\`))
		if _, ok := f.reg[k]; !ok {
			f.reg[k] = &fakeKey{vals: map[string]RegValue{}}
			if i > 1 {
				parent := f.reg[strings.ToLower(strings.Join(parts[:i-1], `\`))]
				parent.subs = append(parent.subs, parts[i-1])
			}
		}
	}
	return f.reg[strings.ToLower(full)]
}

func (f *fakePlatform) setStr(full, name, val string) {
	f.ensure(full).vals[strings.ToLower(name)] = RegValue{Name: name, Type: regSZ, Str: val}
}
func (f *fakePlatform) setBin(full, name string, b []byte) {
	f.ensure(full).vals[strings.ToLower(name)] = RegValue{Name: name, Type: regBinary, Bin: b}
}
func (f *fakePlatform) setDword(full, name string, n uint64) {
	f.ensure(full).vals[strings.ToLower(name)] = RegValue{Name: name, Type: regDWORD, Num: n}
}

// setRegKey timestamps a registry key (stand-in for RegQueryInfoKey).
func (f *fakePlatform) setRegKey(full string, t time.Time) {
	f.regMod[f.key("HKLM", strings.TrimPrefix(full, `HKLM\`))] = t
}

func (f *fakePlatform) addFile(path string, data []byte, sig SigInfo) {
	f.files[strings.ToLower(path)] = data
	if sig.Status != "" {
		f.sigs[strings.ToLower(path)] = sig
	}
}

func (f *fakePlatform) Getenv(k string) string {
	for kk, v := range f.env {
		if strings.EqualFold(kk, k) {
			return v
		}
	}
	return ""
}
func (f *fakePlatform) Stat(p string) FileStat {
	if b, ok := f.files[strings.ToLower(p)]; ok {
		return FileStat{Exists: true, Size: int64(len(b)), ModTime: f.mod[strings.ToLower(p)]}
	}
	if _, ok := f.dirs[strings.ToLower(p)]; ok {
		return FileStat{Exists: true, IsDir: true}
	}
	return FileStat{Denied: f.denied[strings.ToLower(p)]}
}
func (f *fakePlatform) ReadFile(p string, max int64) ([]byte, error) {
	if b, ok := f.files[strings.ToLower(p)]; ok {
		return b, nil
	}
	return nil, errFake
}
func (f *fakePlatform) HashFile(p string) (string, error) {
	return "hash-" + strings.ToLower(winBase(p)), nil
}
func (f *fakePlatform) ListDir(p string) ([]string, error) {
	if d, ok := f.dirs[strings.ToLower(p)]; ok {
		return d, nil
	}
	return nil, errFake
}
func (f *fakePlatform) TaskFiles() ([]TaskFile, error) { return f.tasks, nil }
func (f *fakePlatform) RegSubkeys(root, path string) ([]string, error) {
	if k, ok := f.reg[f.key(root, path)]; ok {
		return k.subs, nil
	}
	return nil, errFake
}
func (f *fakePlatform) RegValues(root, path string) (map[string]RegValue, error) {
	if k, ok := f.reg[f.key(root, path)]; ok {
		return k.vals, nil
	}
	return nil, errFake
}
func (f *fakePlatform) RegKeyModTime(root, path string) time.Time {
	return f.regMod[f.key(root, path)]
}
func (f *fakePlatform) CheckSignatures(paths []string) (map[string]SigInfo, error) {
	if f.failSigs {
		return nil, errFake
	}
	out := map[string]SigInfo{}
	for _, p := range paths {
		if s, ok := f.sigs[strings.ToLower(p)]; ok {
			out[p] = s
		} else {
			out[p] = SigInfo{Status: SigUnsigned}
		}
	}
	return out, nil
}
func (f *fakePlatform) WMIConsumers() ([]WMIConsumer, error) { return f.wmi, nil }
func (f *fakePlatform) Hostname() string                     { return "TESTBOX" }
func (f *fakePlatform) Username() string                     { return `LAB\bob` }
func (f *fakePlatform) Elevated() bool                       { return true }

// ---------------------------------------------------------------------------
// builders

func utf16File(s string) []byte {
	u := utf16.Encode([]rune(s))
	b := []byte{0xFF, 0xFE}
	for _, x := range u {
		b = append(b, byte(x), byte(x>>8))
	}
	return b
}

func taskXMLDoc(cmd, args, trigger, user, runLevel string, hidden bool) string {
	h := ""
	if hidden {
		h = "<Hidden>true</Hidden>"
	}
	a := ""
	if args != "" {
		a = "<Arguments>" + args + "</Arguments>"
	}
	return `<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Author>bob</Author><Date>2020-01-01T10:00:00.1234</Date><URI>\x</URI></RegistrationInfo>
  <Triggers><` + trigger + `><Enabled>true</Enabled></` + trigger + `></Triggers>
  <Principals><Principal id="Author"><UserId>` + user + `</UserId><RunLevel>` + runLevel + `</RunLevel></Principal></Principals>
  <Settings><Enabled>true</Enabled>` + h + `</Settings>
  <Actions Context="Author"><Exec><Command>` + cmd + `</Command>` + a + `</Exec></Actions>
</Task>`
}

func wstr(s string) []byte {
	u := utf16.Encode([]rune(s))
	b := make([]byte, 4, 4+2*len(u))
	binary.LittleEndian.PutUint32(b, uint32(2*len(u)))
	for _, x := range u {
		b = append(b, byte(x), byte(x>>8))
	}
	return b
}

func execBlob(ver uint16, cmd, args string) []byte {
	var b bytes.Buffer
	binary.Write(&b, binary.LittleEndian, ver)
	b.Write(wstr("Author"))
	binary.Write(&b, binary.LittleEndian, uint16(0x6666))
	b.Write(wstr(""))
	b.Write(wstr(cmd))
	b.Write(wstr(args))
	b.Write(wstr(""))
	if ver == 3 {
		binary.Write(&b, binary.LittleEndian, uint16(0))
	}
	return b.Bytes()
}

const tc = `HKLM\` + keyTaskCache

func (f *fakePlatform) registerTask(path, id string, blob []byte, withSD bool) {
	tree := tc + `\Tree` + path
	f.setStr(tree, "Id", id)
	if withSD {
		f.setBin(tree, "SD", []byte{1, 2})
	}
	f.setStr(tc+`\Tasks\`+id, "Path", path)
	if blob != nil {
		f.setBin(tc+`\Tasks\`+id, "Actions", blob)
	}
}

var msSig = SigInfo{Status: SigValid, Signer: "CN=Microsoft Windows, O=Microsoft Corporation", IsMicrosoft: true,
	ChainRoot: "CN=Microsoft Root Certificate Authority 2011, O=Microsoft Corporation", RootThumb: "8F43288AD272F3103B6FB1428485EA3014C0BCFE"}
var vendorSig = SigInfo{Status: SigValid, Signer: "CN=Contoso Ltd, O=Contoso Ltd"}

func findItem(t *testing.T, list []*Item, path string) *Item {
	t.Helper()
	for _, it := range list {
		if strings.EqualFold(it.Path, path) || strings.EqualFold(it.Name, path) {
			return it
		}
	}
	t.Fatalf("item %s not found", path)
	return nil
}

func hasFinding(it *Item, sub string) bool {
	for _, f := range it.Findings {
		if strings.Contains(strings.ToLower(f.Text), strings.ToLower(sub)) {
			return true
		}
	}
	return false
}

// ---------------------------------------------------------------------------
// scenario

func disabled(x string) string {
	return strings.Replace(x, "<Settings><Enabled>true</Enabled>", "<Settings><Enabled>false</Enabled>", 1)
}

var seq = 100

func (f *fakePlatform) task(path, xml string, blob []byte, withSD bool) {
	f.tasks = append(f.tasks, TaskFile{RelPath: strings.TrimLeft(path, `\`), Data: utf16File(xml),
		ModTime: time.Date(2020, 1, 1, 0, 0, 0, 0, time.UTC)})
	seq++
	f.registerTask(path, "{00000000-0000-0000-0000-"+strings.Repeat("0", 9)+itoa(seq)+"}", blob, withSD)
}

func itoa(n int) string {
	return string(rune('0'+n/100)) + string(rune('0'+n/10%10)) + string(rune('0'+n%10))
}

// simple adds an Exec task whose XML and TaskCache agree.
func (f *fakePlatform) simple(path, cmd, args, trigger, user, level string, hidden bool) {
	f.task(path, taskXMLDoc(cmd, args, trigger, user, level, hidden), execBlob(3, cmd, args), true)
}

func buildScenario() *fakePlatform {
	f := newFake()
	sys := `C:\Windows\System32\`
	for _, n := range []string{"cmd.exe", "rundll32.exe", `WindowsPowerShell\v1.0\powershell.exe`, "notepad.exe",
		"sc.exe", "wscript.exe", "usoclient.exe", "userinit.exe"} {
		f.addFile(sys+n, []byte("MZ"), msSig)
	}
	f.addFile(sys+"aepic.dll", []byte("MZ"), msSig)
	f.addFile(`C:\Windows\explorer.exe`, []byte("MZ"), msSig)
	f.addFile(`C:\Program Files\Acme\update.exe`, []byte("MZ"), vendorSig)
	f.addFile(`C:\Program Files\Vendor\maint.bat`, []byte("@echo off"), SigInfo{Status: SigUnsigned})
	defender := `C:\ProgramData\Microsoft\Windows Defender\Platform\4.18.24090-0\MpCmdRun.exe`
	f.addFile(defender, []byte("MZ"), msSig)
	onedrive := `C:\Users\bob\AppData\Local\Microsoft\OneDrive\OneDriveStandaloneUpdater.exe`
	f.addFile(onedrive, []byte("MZ"), msSig)
	loader := `C:\ProgramData\cheat\loader.exe`
	f.addFile(loader, []byte("MZ"), SigInfo{Status: SigSelfSigned, Signer: "CN=Loader Dev", Issuer: "CN=Loader Dev", SelfSigned: true})
	fakeMS := `C:\ProgramData\Updater\msupdate.exe`
	f.addFile(fakeMS, []byte("MZ"), SigInfo{Status: SigUntrustedRoot, Signer: "CN=Microsoft Corporation, O=Microsoft Corporation", Issuer: "CN=MS Root"})
	f.addFile(`C:\Users\bob\AppData\Local\Temp\svchost.exe`, []byte("MZ"), SigInfo{Status: SigUnsigned})
	f.addFile(`C:\Users\bob\AppData\Roaming\x\run.ps1`, []byte("Write-Host"), SigInfo{Status: SigUnsigned})
	f.addFile(`C:\Users\Public\svc.exe`, []byte("MZ"), SigInfo{Status: SigValid, Signer: msSig.Signer, IsMicrosoft: true, OriginalName: "PowerShell.EXE.MUI", ChainRoot: msSig.ChainRoot, RootThumb: msSig.RootThumb})
	f.addFile(sys+"wuaueng2.exe", []byte("MZ"), SigInfo{Status: SigUnsigned})
	f.addFile(`C:\Program Files\Game\patched.exe`, []byte("MZ"), SigInfo{Status: SigHashMismatch, Signer: "CN=Game Studio"})

	// ---- things that must stay Clean (false-positive regressions) ----
	f.simple(`\Microsoft\Windows\Time Synchronization\SynchronizeTime`, `%windir%\system32\sc.exe`, "start w32time task_started", "TimeTrigger", "S-1-5-19", "", false)
	f.simple(`\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan`, defender, "Scan -ScheduleJob -ScanTrigger 55", "TimeTrigger", "S-1-5-18", "HighestAvailable", false)
	f.simple(`\Microsoft\Windows\Application Experience\PcaPatchDbTask`, `%windir%\system32\rundll32.exe`, `%windir%\system32\aepic.dll,PcaPatchSdbTask`, "TimeTrigger", "S-1-5-18", "", true)
	f.simple(`\OneDrive Standalone Update Task-S-1-5-21-1`, onedrive, "", "TimeTrigger", "S-1-5-21-1", "", false)
	f.simple(`\AcmeUpdate`, `C:\Program Files\Acme\update.exe`, "", "LogonTrigger", "bob", "LeastPrivilege", false)
	f.simple(`\VendorMaintenance`, `cmd.exe`, `/c "C:\Program Files\Vendor\maint.bat"`, "TimeTrigger", "S-1-5-18", "HighestAvailable", false)
	f.task(`\OldUninstalledApp`, disabled(taskXMLDoc(`C:\Program Files\Gone\gone.exe`, "", "LogonTrigger", "bob", "", false)),
		execBlob(3, `C:\Program Files\Gone\gone.exe`, ""), true)
	f.simple(`\Microsoft\Windows\UpdateOrchestrator\Schedule Scan`, `%systemroot%\system32\usoclient.exe`, "StartScan", "TimeTrigger", "S-1-5-18", "", true)

	// ---- detections ----
	f.task(`\Hijacked`, taskXMLDoc(`C:\Windows\System32\notepad.exe`, "", "BootTrigger", "S-1-5-18", "HighestAvailable", false),
		execBlob(3, loader, "--inject"), false)
	f.simple(`\Updater`, `%LOCALAPPDATA%\Temp\svchost.exe`, "", "LogonTrigger", "bob", "", false)
	f.registerTask(`\Ghost`, "{00000000-0000-0000-0000-000000000999}", execBlob(3, `C:\ProgramData\cheat\loader.exe`, ""), true)
	f.setRegKey(tc+`\Tree\Ghost`, time.Date(2026, 11, 4, 19, 45, 0, 0, time.UTC))
	f.setRegKey(tc+`\Tasks\{00000000-0000-0000-0000-000000000999}`, time.Date(2026, 11, 4, 19, 45, 0, 0, time.UTC))
	f.simple(`\PSJob`, `powershell.exe`, `-ExecutionPolicy Bypass -File "C:\Users\bob\AppData\Roaming\x\run.ps1"`, "LogonTrigger", "bob", "", false)
	f.simple(`\EncodedPS`, `powershell.exe`, `-nop -w hidden -enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABOAGUAdAAuAFcAZQBiAEMAbABpAGUAbgB0ACkA`, "LogonTrigger", "bob", "", false)
	f.simple(`\RenamedPS`, `C:\Users\Public\svc.exe`, "-c whoami", "LogonTrigger", "bob", "", false)
	f.simple(`\FakeMicrosoft`, fakeMS, "", "BootTrigger", "S-1-5-18", "", false)
	f.simple(`\SystemDrop`, sys+"wuaueng2.exe", "", "BootTrigger", "S-1-5-18", "", false)
	f.simple(`\PatchedGame`, `C:\Program Files\Game\patched.exe`, "", "LogonTrigger", "bob", "", false)
	f.setStr(`HKLM\`+keyIFEO+`\sethc.exe`, "Debugger", `C:\Windows\System32\cmd.exe`)
	f.simple(`\StickyKeys`, `C:\Windows\System32\sethc.exe`, "", "LogonTrigger", "bob", "", false)
	f.addFile(sys+"sethc.exe", []byte("MZ"), msSig)

	// ---- exec-host / startup-trigger evasion shapes ----
	// Staged drop: the host runs, the payload has not landed yet.
	f.simple(`\StagedCmd`, sys+"cmd.exe", `/c C:\Users\Public\a\run.bat`, "LogonTrigger", "bob", "", false)
	// conhost.exe fronting a headless drop.
	f.addFile(sys+"conhost.exe", []byte("MZ"), msSig)
	f.addFile(`C:\Users\Public\a\drop.exe`, []byte("MZ"), SigInfo{Status: SigUnsigned})
	f.simple(`\ConhostCradle`, sys+"conhost.exe", `--headless C:\Users\Public\a\drop.exe`, "BootTrigger", "S-1-5-18", "HighestAvailable", false)
	// rundll32 with no DLL entry point, cmd chaining into PowerShell.
	f.simple(`\BareRundll`, sys+"rundll32.exe", `0x1337`, "LogonTrigger", "bob", "", false)
	f.simple(`\CmdChainsPS`, sys+"cmd.exe", `/c powershell.exe -c Get-Date`, "LogonTrigger", "bob", "", false)

	clsid := "{AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE}"
	f.ensure(`HKU\S-1-5-21-1`)
	f.ensure(`HKU\S-1-5-21-1_Classes`)
	f.setStr(`HKLM\SOFTWARE\Classes\CLSID\`+clsid+`\InprocServer32`, "", `C:\Windows\System32\notepad.exe`)
	f.setStr(`HKU\S-1-5-21-1_Classes\CLSID\`+clsid+`\InprocServer32`, "", loader)
	comXML := strings.Replace(taskXMLDoc("x", "", "LogonTrigger", "bob", "", false),
		"<Exec><Command>x</Command></Exec>", "<ComHandler><ClassId>"+clsid+"</ClassId></ComHandler>", 1)
	var cb bytes.Buffer
	binary.Write(&cb, binary.LittleEndian, uint16(3))
	cb.Write(wstr("Author"))
	binary.Write(&cb, binary.LittleEndian, uint16(0x7777))
	cb.Write(wstr(""))
	cb.Write([]byte{0xAA, 0xAA, 0xAA, 0xAA, 0xBB, 0xBB, 0xCC, 0xCC, 0xDD, 0xDD, 0xEE, 0xEE, 0xEE, 0xEE, 0xEE, 0xEE})
	cb.Write(wstr(""))
	f.task(`\ComTask`, comXML, cb.Bytes(), true)

	// autostart
	f.setStr(`HKLM\Software\Microsoft\Windows\CurrentVersion\Run`, "Acme", `"C:\Program Files\Acme\update.exe" /tray`)
	f.setStr(`HKU\S-1-5-21-1\Software\Microsoft\Windows\CurrentVersion\Run`, "OneDrive", `"`+onedrive+`" /background`)
	f.setStr(`HKU\S-1-5-21-1\Software\Microsoft\Windows\CurrentVersion\Run`, "Loader", loader)
	f.setStr(`HKLM\`+keyWinlogon, "Shell", "explorer.exe")
	f.setStr(`HKLM\`+keyWinlogon, "Userinit", `C:\Windows\system32\userinit.exe,C:\ProgramData\cheat\loader.exe,`)
	f.dirs[strings.ToLower(`C:\Users`)] = []string{"bob"}
	sd := `C:\Users\bob\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup`
	f.dirs[strings.ToLower(sd)] = []string{"desktop.ini", "loader.lnk", "Acme.lnk"}
	f.addFile(sd+`\loader.lnk`, buildLnk(loader, "--silent"), SigInfo{})
	f.addFile(sd+`\Acme.lnk`, buildLnk(`C:\Program Files\Acme\update.exe`, ""), SigInfo{})
	return f
}

func scanScenario(t *testing.T) *ScanResult {
	t.Helper()
	return Scan(buildScenario(), ScanOptions{Tasks: true, Autostart: true, Signatures: true, Hashes: true,
		RecentDays: 7, Now: time.Date(2026, 11, 5, 0, 0, 0, 0, time.UTC)})
}

// ---------------------------------------------------------------------------
// tests

func TestNoFalsePositives(t *testing.T) {
	r := scanScenario(t)
	for _, p := range []string{
		`\Microsoft\Windows\Time Synchronization\SynchronizeTime`,
		`\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan`,
		`\Microsoft\Windows\Application Experience\PcaPatchDbTask`,
		`\OneDrive Standalone Update Task-S-1-5-21-1`,
		`\AcmeUpdate`, `\VendorMaintenance`, `\OldUninstalledApp`,
		`\Microsoft\Windows\UpdateOrchestrator\Schedule Scan`,
	} {
		if it := findItem(t, r.Tasks, p); it.Risk != RiskClean {
			t.Errorf("%s should be Clean, got %s: %+v", p, it.Risk, it.Findings)
		}
	}
	for _, it := range r.Autostart {
		if (it.Name == "Acme" || it.Name == "OneDrive" || it.Name == "Acme.lnk" || it.Name == "Shell") && it.Risk != RiskClean {
			t.Errorf("autostart %s should be Clean: %+v", it.Name, it.Findings)
		}
	}
}

func TestDetections(t *testing.T) {
	r := scanScenario(t)
	cases := []struct {
		path string
		flag uint64
		text string
	}{
		{`\Hijacked`, FlagActionMismatch, "action mismatch"},
		{`\Hijacked`, FlagSDMissing, "security descriptor removed"},
		{`\Hijacked`, FlagSelfSigned, "self-signed"},
		{`\Updater`, FlagMasquerade, "system binary name"},
		{`\Ghost`, FlagTaskCacheMismatch, "no xml"},
		{`\PSJob`, FlagExecHost, "untrusted payload"},
		{`\EncodedPS`, FlagStaticAnalysis, "encoded powershell"},
		{`\RenamedPS`, FlagMasquerade, "renamed system binary"},
		{`\FakeMicrosoft`, FlagSelfSigned, "untrusted root"},
		{`\FakeMicrosoft`, FlagImpersonation, "claims to be microsoft"},
		{`\SystemDrop`, FlagBadSignature, "inside the windows directory"},
		{`\PatchedGame`, FlagBadSignature, "modified after it was signed"},
		{`\StickyKeys`, FlagIFEO, "ifeo debugger"},
		{`\ComTask`, FlagCOMHijack, "overridden"},
	}
	for _, c := range cases {
		it := findItem(t, r.Tasks, c.path)
		if !it.has(c.flag) || !hasFinding(it, c.text) || it.Risk != RiskSuspicious {
			t.Errorf("%s: want %v / %q / Suspicious; got %s %v %+v", c.path, flagNames(c.flag), c.text, it.Risk, it.FlagKeys, it.Findings)
		}
	}
	var loaderRun, userinit, lnk *Item
	for _, it := range r.Autostart {
		switch {
		case it.Name == "Loader":
			loaderRun = it
		case it.Location == "Winlogon" && strings.Contains(it.Command, "loader"):
			userinit = it
		case it.Name == "loader.lnk":
			lnk = it
		}
	}
	for name, it := range map[string]*Item{"run key": loaderRun, "userinit": userinit, "startup lnk": lnk} {
		if it == nil || it.Risk != RiskSuspicious || !it.has(FlagSelfSigned) {
			t.Errorf("%s: %+v", name, it)
		}
	}
	if !userinit.has(FlagNonDefault) {
		t.Error("userinit should be non-default")
	}
	if c := findItem(t, r.Tasks, `\ComTask`); c.SignatureStatus != SigSelfSigned {
		t.Errorf("worst signature should be shown, got %s", c.SignatureStatus)
	}
}

func TestMassAnomalySuppression(t *testing.T) {
	f := newFake()
	f.addFile(`C:\Windows\System32\cmd.exe`, []byte("MZ"), msSig)
	for i := 0; i < 20; i++ {
		p := `\Vendor\Task` + itoa(i)
		f.task(p, taskXMLDoc(`C:\Windows\System32\cmd.exe`, "/c a", "TimeTrigger", "bob", "", false),
			execBlob(3, `C:\Windows\System32\cmd.exe`, "/c b"), false) // every blob differs, every SD missing
	}
	r := Scan(f, ScanOptions{Tasks: true, Signatures: true})
	for _, it := range r.Tasks {
		if it.has(FlagActionMismatch) || it.has(FlagSDMissing) {
			t.Fatalf("mass anomaly not suppressed: %v", it.FlagKeys)
		}
	}
	if len(r.Notes) < 2 {
		t.Errorf("expected suppression notes, got %v", r.Notes)
	}
}

func TestUnreadableTreeKeyIsNotHidden(t *testing.T) {
	f := newFake()
	f.addFile(`C:\Windows\System32\cmd.exe`, []byte("MZ"), msSig)
	f.simple(`\Fine`, `C:\Windows\System32\cmd.exe`, "/c x", "TimeTrigger", "bob", "", false)
	f.tasks = append(f.tasks, TaskFile{RelPath: "Locked", Data: utf16File(taskXMLDoc(`C:\Windows\System32\cmd.exe`, "/c x", "TimeTrigger", "bob", "", false))})
	tree := f.ensure(tc + `\Tree\Locked`) // exists but values unreadable
	_ = tree
	delete(f.reg, strings.ToLower(tc+`\Tree\Locked`))
	f.reg[strings.ToLower(tc+`\Tree`)].subs = append(f.reg[strings.ToLower(tc+`\Tree`)].subs, "Locked")
	r := Scan(f, ScanOptions{Tasks: true, Signatures: true})
	if it := findItem(t, r.Tasks, `\Locked`); it.Risk != RiskClean {
		t.Fatalf("unreadable key must not be flagged: %+v", it.Findings)
	}
}

func TestParseTaskXMLUTF16(t *testing.T) {
	pt, err := parseTaskXML(utf16File(taskXMLDoc(`%windir%\system32\cmd.exe`, "/c echo hi", "LogonTrigger", "S-1-5-18", "HighestAvailable", true)))
	if err != nil {
		t.Fatal(err)
	}
	if !pt.Logon || pt.Boot || !pt.Hidden || pt.RunAs != "S-1-5-18" || len(pt.Actions) != 1 || pt.Actions[0].Arguments != "/c echo hi" {
		t.Fatalf("bad parse: %+v", pt)
	}
}

func TestActionsBlob(t *testing.T) {
	for _, v := range []uint16{1, 3} {
		ctx, acts, err := parseActionsBlob(execBlob(v, `C:\a b\x.exe`, "-q"))
		if err != nil || ctx != "Author" || len(acts) != 1 || acts[0].Command != `C:\a b\x.exe` {
			t.Fatalf("v%d: %q %+v %v", v, ctx, acts, err)
		}
	}
	if _, _, err := parseActionsBlob([]byte{3, 0, 0xff, 0xff, 0xff, 0x7f}); err == nil {
		t.Fatal("expected error")
	}
}

func TestSplitCommandLine(t *testing.T) {
	f := newFake()
	f.addFile(`C:\Program Files\Acme App\acme.exe`, []byte("MZ"), vendorSig)
	r := Resolver{Getenv: f.Getenv, Exists: func(p string) bool { return f.Stat(p).Exists }}
	for _, c := range []struct{ in, exe, args string }{
		{`"C:\Program Files\Acme App\acme.exe" --tray`, `C:\Program Files\Acme App\acme.exe`, "--tray"},
		{`C:\Program Files\Acme App\acme.exe --tray -x`, `C:\Program Files\Acme App\acme.exe`, "--tray -x"},
		{`rundll32.exe C:\x\y.dll,Start`, "rundll32.exe", `C:\x\y.dll,Start`},
	} {
		if exe, args := r.SplitCommandLine(c.in); exe != c.exe || args != c.args {
			t.Errorf("%q -> %q %q", c.in, exe, args)
		}
	}
}

func TestStaticTiers(t *testing.T) {
	strong := 0
	for _, h := range staticAnalysis(`-nop -w hidden -enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABOAGUAdAAuAFcAZQBiAEMAbABpAGUAbgB0ACkA`) {
		if h.strong {
			strong++
		}
	}
	if strong == 0 {
		t.Error("encoded command must be strong")
	}
	for _, h := range staticAnalysis(`-ExecutionPolicy Bypass -WindowStyle Hidden -File C:\x.ps1`) {
		if h.strong {
			t.Errorf("weak indicator marked strong: %s", h.reason)
		}
	}
}

func TestMapSignature(t *testing.T) {
	for _, c := range []struct {
		in   psSig
		want string
	}{
		{psSig{Status: "Valid", Signer: "CN=Microsoft Windows, O=Microsoft Corporation", Issuer: "CN=PCA"}, SigValid},
		{psSig{Status: "Valid", Signer: "CN=Me", Issuer: "CN=Me", SelfSigned: true}, SigSelfTrusted},
		{psSig{Status: "UnknownError", Signer: "CN=Me", Issuer: "CN=Me", SelfSigned: true, Chain: "UntrustedRoot"}, SigSelfSigned},
		{psSig{Status: "UnknownError", Signer: "CN=Leaf", Issuer: "CN=My CA", Chain: "UntrustedRoot"}, SigUntrustedRoot},
		{psSig{Status: "UnknownError", Signer: "CN=Leaf", Issuer: "CN=CA", Chain: "NotSignatureValid"}, SigBadCert},
		{psSig{Status: "UnknownError", Signer: "CN=Leaf", Issuer: "CN=CA", Chain: "Revoked"}, SigRevoked},
		{psSig{Status: "UnknownError", Signer: "CN=Leaf", Issuer: "CN=CA", Chain: "OfflineRevocation"}, SigUnverified},
		{psSig{Status: "NotSigned"}, SigUnsigned},
		{psSig{Status: "HashMismatch", Signer: "CN=X"}, SigHashMismatch},
	} {
		if got := mapSignature(c.in).Status; got != c.want {
			t.Errorf("%+v -> %s, want %s", c.in, got, c.want)
		}
	}
}

// buildLnk writes a minimal MS-SHLLINK with LinkInfo + unicode arguments.
func buildLnk(target, args string) []byte {
	var b bytes.Buffer
	hdr := make([]byte, 0x4C)
	binary.LittleEndian.PutUint32(hdr[0:], 0x4C)
	binary.LittleEndian.PutUint32(hdr[4:], 0x00021401)
	binary.LittleEndian.PutUint32(hdr[0x14:], lnkHasLinkInfo|lnkHasArgs|lnkIsUnicode)
	b.Write(hdr)
	base := append([]byte(target), 0)
	li := make([]byte, 0x1C)
	binary.LittleEndian.PutUint32(li[0:], uint32(0x1C+len(base)+1))
	binary.LittleEndian.PutUint32(li[4:], 0x1C)
	binary.LittleEndian.PutUint32(li[8:], 1)
	binary.LittleEndian.PutUint32(li[0x10:], 0x1C)
	binary.LittleEndian.PutUint32(li[0x18:], uint32(0x1C+len(base)))
	b.Write(li)
	b.Write(base)
	b.WriteByte(0)
	u := utf16.Encode([]rune(args))
	binary.Write(&b, binary.LittleEndian, uint16(len(u)))
	for _, x := range u {
		binary.Write(&b, binary.LittleEndian, x)
	}
	b.Write([]byte{0, 0, 0, 0})
	return b.Bytes()
}

func TestParseLnk(t *testing.T) {
	li, err := parseLnk(buildLnk(`C:\Tools\a.exe`, "-x 1"))
	if err != nil || li.Target != `C:\Tools\a.exe` || li.Arguments != "-x 1" {
		t.Fatalf("%+v %v", li, err)
	}
}

func TestExportCSV(t *testing.T) {
	r := scanScenario(t)
	p := t.TempDir() + "/x.csv"
	if err := writeCSV(r.Tasks, p); err != nil {
		t.Fatal(err)
	}
	if err := writeJSON(r, t.TempDir()+"/x.json"); err != nil {
		t.Fatal(err)
	}
}

func TestParsersDoNotPanic(t *testing.T) {
	for _, s := range [][]byte{execBlob(3, "a", "b"), buildLnk(`C:\a`, "b"), utf16File("<Task/>")} {
		for i := 0; i < len(s); i++ {
			for _, v := range []byte{0, 0xFF, 0x7F} {
				m := append([]byte(nil), s...)
				m[i] = v
				parseActionsBlob(m)
				parseLnk(m)
				parseTaskXML(m)
				parseActionsBlob(m[:i])
				parseLnk(m[:i])
			}
		}
	}
}

func TestUnverifiableSignaturesDoNotEscalate(t *testing.T) {
	r := Scan(buildScenario(), ScanOptions{Tasks: true, Autostart: true, Signatures: false})
	for _, p := range []string{
		`\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan`,
		`\Microsoft\Windows\Application Experience\PcaPatchDbTask`,
		`\OneDrive Standalone Update Task-S-1-5-21-1`,
		`\AcmeUpdate`, `\VendorMaintenance`,
	} {
		if it := findItem(t, r.Tasks, p); it.Risk == RiskSuspicious {
			t.Errorf("%s escalated without a signature verdict: %+v", p, it.Findings)
		}
	}
}

// TestExecHostAndStartupBypass covers the shapes that used to score Clean:
// startup triggers wired to script hosts, staged (not-yet-dropped) payloads,
// conhost.exe as the action, rundll32 without a DLL entry, and cmd.exe
// chaining into PowerShell.
func TestExecHostAndStartupBypass(t *testing.T) {
	r := scanScenario(t)
	cases := []struct {
		path string
		risk string
	}{
		{`\StagedCmd`, RiskSuspicious},      // cmd /c run.bat, payload missing at logon
		{`\ConhostCradle`, RiskSuspicious},  // conhost --headless drop.exe
		{`\BareRundll`, RiskReview},         // rundll32 0x1337: no DLL entry
		{`\CmdChainsPS`, RiskReview},        // cmd /c powershell -c Get-Date
	}
	for _, c := range cases {
		it := findItem(t, r.Tasks, c.path)
		if it.Risk != c.risk {
			t.Errorf("%s: want %s, got %s: %+v (%+v)", c.path, c.risk, it.Risk, it.FlagKeys, it.Findings)
		}
		if !it.has(FlagExecHost) {
			t.Errorf("%s: missing executionHost flag", c.path)
		}
	}
	if it := findItem(t, r.Tasks, `\ConhostCradle`); !hasFinding(it, "console host") {
		t.Errorf("\\ConhostCradle: missing console-host finding: %+v", it.Findings)
	}
	if it := findItem(t, r.Tasks, `\CmdChainsPS`); !hasFinding(it, "chains into powershell.exe") {
		t.Errorf("\\CmdChainsPS: missing chained-host finding: %+v", it.Findings)
	}
	if it := findItem(t, r.Tasks, `\BareRundll`); !hasFinding(it, "entry point") {
		t.Errorf("\\BareRundll: missing bare-rundll32 finding: %+v", it.Findings)
	}
	// The same shapes must also fire with signature verification unavailable.
	r2 := Scan(buildScenario(), ScanOptions{Tasks: true, Signatures: false})
	for _, p := range []string{`\StagedCmd`, `\ConhostCradle`, `\BareRundll`, `\CmdChainsPS`} {
		it := findItem(t, r2.Tasks, p)
		if !it.has(FlagExecHost) {
			t.Errorf("%s: missing executionHost flag without signatures", p)
		}
	}
}

// TestGhostTaskLastWrite checks that registry-only ghost tasks carry the
// registry key last-write time (it.Modified, "Registry last write" detail,
// and the 7-day RECENT heuristic driven from it).
func TestGhostTaskLastWrite(t *testing.T) {
	r := scanScenario(t)
	it := findItem(t, r.Tasks, `\Ghost`)
	if it.Risk != RiskSuspicious {
		t.Fatalf("ghost task should be Suspicious: %+v", it.Findings)
	}
	want := time.Date(2026, 11, 4, 19, 45, 0, 0, time.UTC)
	if it.Modified.IsZero() || !it.Modified.UTC().Equal(want) {
		t.Errorf("ghost Modified = %v, want registry last write %v", it.Modified, want)
	}
	found := false
	for _, d := range it.Details {
		if d.K == "Registry last write" {
			found = true
		}
	}
	if !found {
		t.Error("ghost task missing 'Registry last write' detail")
	}
	if !it.has(FlagRecent) {
		t.Errorf("registry last write within RecentDays should raise FlagRecent: %+v", it.FlagKeys)
	}
}

// certBlob wraps DER in the registry certificate-store Blob format.
func certBlob(der []byte) []byte {
	var b bytes.Buffer
	binary.Write(&b, binary.LittleEndian, uint32(32))
	binary.Write(&b, binary.LittleEndian, uint32(1))
	binary.Write(&b, binary.LittleEndian, uint32(len(der)))
	b.Write(der)
	return b.Bytes()
}

// TestSingNowTechnique reproduces 2020SINGNOW.exe: a forged "Microsoft Root
// Certificate Authority 2011" is planted in the user's Root store, so Windows
// reports the dropped copy as validly signed by Microsoft. The task is a hidden
// SYSTEM ONEVENT task.
func TestSingNowTechnique(t *testing.T) {
	der, err := os.ReadFile("testdata/fake_ms_root.cer")
	if err != nil {
		t.Fatal(err)
	}
	const fakeThumb = "4CDF2365DD9BE0EA2D4E7732A7D14887662007BB"
	f := buildScenario()
	f.setBin(`HKU\S-1-5-21-1\Software\Microsoft\SystemCertificates\Root\Certificates\`+fakeThumb, "Blob", certBlob(der))
	drop := `C:\Windows\System32\WinSecHelper.exe`
	windowsSays := SigInfo{Status: SigValid, Signer: "CN=Microsoft Windows, O=Microsoft Corporation",
		Issuer: "CN=Microsoft Code Signing PCA 2011, O=Microsoft Corporation", RawStatus: "Valid",
		ChainRoot: "CN=Microsoft Root Certificate Authority 2011, O=Microsoft Corporation", RootThumb: fakeThumb,
		RootNotBefore: time.Date(2026, 11, 4, 18, 19, 36, 0, time.UTC), Company: "Microsoft Corporation", OriginalName: "WinSecHelper.exe"}
	content := []byte("MZ")
	if b, err := os.ReadFile(os.Getenv("HK_FIXTURES") + "/sample.bin"); err == nil {
		content = b // also exercises the native verifier
	}
	f.addFile(drop, content, windowsSays)
	xml := strings.Replace(taskXMLDoc(drop, "", "EventTrigger", "S-1-5-18", "HighestAvailable", true),
		"<EventTrigger><Enabled>true</Enabled></EventTrigger>", "<EventTrigger><Enabled>true</Enabled><Subscription>x</Subscription></EventTrigger>", 1)
	f.task(`\Microsoft\Windows\WinSecHelper`, xml, execBlob(3, drop, ""), true)

	r := Scan(f, ScanOptions{Tasks: true, Autostart: true, Signatures: true, Hashes: true,
		Now: time.Date(2026, 11, 5, 0, 0, 0, 0, time.UTC)})
	it := findItem(t, r.Tasks, `\Microsoft\Windows\WinSecHelper`)
	if it.Risk != RiskSuspicious || !it.has(FlagSelfSigned) || !hasFinding(it, "forged signature") || it.SignatureStatus != SigForged {
		t.Fatalf("task not caught: %s %s %+v", it.Risk, it.SignatureStatus, it.Findings)
	}
	var root *Item
	for _, c := range r.Certs {
		if c.Command == fakeThumb {
			root = c
		}
	}
	if root == nil || root.Risk != RiskSuspicious || !root.has(FlagImpersonation) || !root.has(FlagSignsTarget) || !root.has(FlagUserRoot) {
		t.Fatalf("fake root not caught: %+v", root)
	}
	t.Logf("task findings: %v", it.Findings)
	t.Logf("cert findings: %v", root.Findings)

	// Same file when Windows verification is unavailable: native check alone must catch it.
	if len(content) > 2 {
		f.sigs = map[string]SigInfo{}
		f.failSigs = true
		r = Scan(f, ScanOptions{Tasks: true, Signatures: true, Now: time.Date(2026, 11, 5, 0, 0, 0, 0, time.UTC)})
		it = findItem(t, r.Tasks, `\Microsoft\Windows\WinSecHelper`)
		if it.Risk != RiskSuspicious || it.SignatureStatus != SigForged {
			t.Fatalf("native-only path missed it: %s %s %+v", it.Risk, it.SignatureStatus, it.Findings)
		}
	}
}

func selfSignedCert(t *testing.T, cn string, ekus []x509.ExtKeyUsage, extra []pkix.Extension, notBefore time.Time) []byte {
	t.Helper()
	k, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	tpl := &x509.Certificate{SerialNumber: big.NewInt(7), Subject: pkix.Name{CommonName: cn},
		NotBefore: notBefore, NotAfter: notBefore.AddDate(10, 0, 0), IsCA: true, BasicConstraintsValid: true,
		ExtKeyUsage: ekus, ExtraExtensions: extra}
	der, err := x509.CreateCertificate(rand.Reader, tpl, tpl, &k.PublicKey, k)
	if err != nil {
		t.Fatal(err)
	}
	return der
}

func thumbOf(der []byte) string {
	s := sha1.Sum(der)
	return strings.ToUpper(hex.EncodeToString(s[:]))
}

func TestCertAndTaskFalsePositives(t *testing.T) {
	f := buildScenario()
	old := time.Date(2019, 1, 1, 0, 0, 0, 0, time.UTC)
	av := selfSignedCert(t, "Avast Web/Mail Shield Root", nil, nil, old)
	f.setBin(`HKLM\`+keyCerts+`\ROOT\Certificates\`+thumbOf(av), "Blob", certBlob(av))
	dev := selfSignedCert(t, "localhost", []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		[]pkix.Extension{{Id: oidAspNetDevCert, Value: []byte{0x04, 0x01, 0x02}}}, old)
	f.setBin(`HKU\S-1-5-21-1\Software\Microsoft\SystemCertificates\Root\Certificates\`+thumbOf(dev), "Blob", certBlob(dev))
	// populate a CTL so the root-program logic is active
	ctl := []byte{}
	for i := 0; i < 150; i++ {
		ctl = append(ctl, 0x04, 0x14)
		ctl = append(ctl, bytes.Repeat([]byte{byte(i)}, 20)...)
	}
	ctl = append(ctl, 0x04, 0x14)
	gen, _ := hex.DecodeString("8F43288AD272F3103B6FB1428485EA3014C0BCFE")
	ctl = append(ctl, gen...)
	f.setBin(`HKLM\`+keyCerts+`\AuthRoot\AutoUpdate`, "EncodedCtl", ctl)

	f.addFile(`C:\Program Files\Lenovo\Vantage\maint.ps1`, []byte("x"), SigInfo{Status: SigUnsigned})
	f.simple(`\Lenovo\VantageMaintenance`, `powershell.exe`, `-ExecutionPolicy Bypass -WindowStyle Hidden -NoProfile -File "C:\Program Files\Lenovo\Vantage\maint.ps1"`, "TimeTrigger", "S-1-5-18", "HighestAvailable", false)
	f.simple(`\GoogleUpdateLeftover`, `C:\Program Files (x86)\Google\Update\GoogleUpdate.exe`, "/ua /installsource scheduler", "LogonTrigger", "S-1-5-18", "HighestAvailable", false)

	r := Scan(f, ScanOptions{Tasks: true, Autostart: true, Signatures: true, Now: time.Date(2026, 11, 5, 0, 0, 0, 0, time.UTC)})
	for _, c := range r.Certs {
		if c.Risk != RiskClean {
			t.Errorf("cert %s should be Clean: %+v", c.Name, c.Findings)
		}
	}
	for _, p := range []string{`\Lenovo\VantageMaintenance`, `\GoogleUpdateLeftover`} {
		if it := findItem(t, r.Tasks, p); it.Risk != RiskClean {
			t.Errorf("%s should be Clean: %+v", p, it.Findings)
		}
	}
}

func findAuto(t *testing.T, r *ScanResult, loc, name string) *Item {
	t.Helper()
	for _, it := range r.Autostart {
		if strings.EqualFold(it.Location, loc) && strings.EqualFold(it.Name, name) {
			return it
		}
	}
	t.Fatalf("autostart %s/%s not found", loc, name)
	return nil
}

func TestV4DetectionsAndFalsePositives(t *testing.T) {
	f := buildScenario()
	sys := `C:\Windows\System32\`
	f.denied = map[string]bool{}
	when := time.Date(2026, 11, 5, 0, 0, 0, 0, time.UTC)

	// --- false-positive regressions ---
	// task XML in a folder admins can't list
	f.registerTask(`\Microsoft\Windows\WaaSMedic\PerformRemediation`, "{00000000-0000-0000-0000-00000000A001}", execBlob(3, sys+"usoclient.exe", ""), true)
	f.denied[strings.ToLower(sys+`Tasks\Microsoft\Windows\WaaSMedic\PerformRemediation`)] = true
	// arguments-only difference between XML and TaskCache
	f.task(`\Vendor\ArgsDiffer`, taskXMLDoc(sys+"cmd.exe", "/c a", "TimeTrigger", "bob", "", false), execBlob(3, sys+"cmd.exe", "/c b"), true)
	// unsigned vendor updater in ProgramData running as SYSTEM
	f.addFile(`C:\ProgramData\Vendor\updater.exe`, []byte("MZ"), SigInfo{Status: SigUnsigned})
	f.simple(`\VendorUpdater`, `C:\ProgramData\Vendor\updater.exe`, "", "TimeTrigger", "S-1-5-18", "HighestAvailable", false)
	// Microsoft services / drivers
	svc := `HKLM\` + keyServices + `\`
	f.addFile(sys+`drivers\ntfs.sys`, []byte("MZ"), msSig)
	f.setStr(svc+"Ntfs", "ImagePath", `\SystemRoot\System32\drivers\ntfs.sys`)
	f.setDword(svc+"Ntfs", "Start", 0)
	f.setDword(svc+"Ntfs", "Type", 2)
	f.addFile(sys+"wuaueng.dll", []byte("MZ"), msSig)
	f.addFile(sys+"svchost.exe", []byte("MZ"), msSig)
	f.setStr(svc+"wuauserv", "ImagePath", `%systemroot%\system32\svchost.exe -k netsvcs -p`)
	f.setDword(svc+"wuauserv", "Start", 2)
	f.setDword(svc+"wuauserv", "Type", 0x20)
	f.setStr(svc+`wuauserv\Parameters`, "ServiceDll", `%systemroot%\system32\wuaueng.dll`)
	f.addFile(sys+"utilman.exe", []byte("MZ"), SigInfo{Status: SigValid, Signer: msSig.Signer, ChainRoot: msSig.ChainRoot, RootThumb: msSig.RootThumb, OriginalName: "utilman.exe"})

	// --- detections ---
	f.addFile(`C:\Windows\Temp\iqvw64e.sys`, []byte("MZ"), SigInfo{Status: SigUnsigned})
	f.setStr(svc+"KdMap", "ImagePath", `\??\C:\Windows\Temp\iqvw64e.sys`)
	f.setDword(svc+"KdMap", "Start", 1)
	f.setDword(svc+"KdMap", "Type", 1)
	f.addFile(`C:\Program Files\MSI\RTCore64.sys`, []byte("MZ"), vendorSig)
	f.setStr(svc+"RTCore64", "ImagePath", `\??\C:\Program Files\MSI\RTCore64.sys`)
	f.setDword(svc+"RTCore64", "Start", 2)
	f.setDword(svc+"RTCore64", "Type", 1)
	f.setStr(`HKLM\SYSTEM\CurrentControlSet\Control`, "SystemStartOptions", " NOEXECUTE=OPTIN  TESTSIGNING")
	f.ensure(`HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Paths`).vals["c:\\"] = RegValue{Name: `C:\`, Type: regDWORD}
	f.ensure(`HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Extensions`).vals[".exe"] = RegValue{Name: ".exe", Type: regDWORD}
	f.addFile(sys+"sethc.exe", []byte("MZ"), SigInfo{Status: SigValid, Signer: msSig.Signer, ChainRoot: msSig.ChainRoot, RootThumb: msSig.RootThumb, IsMicrosoft: true, OriginalName: "Cmd.Exe"})
	f.ensure(`HKLM\SYSTEM\CurrentControlSet\Control\Lsa`).vals["notification packages"] = RegValue{Name: "Notification Packages", Type: regMultiSZ, Strs: []string{"scecli", "pwfilter"}}
	f.addFile(sys+"pwfilter.dll", []byte("MZ"), SigInfo{Status: SigUnsigned})
	f.wmi = []WMIConsumer{{Name: "Updater", Kind: "ActiveScriptEventConsumer", Engine: "VBScript", Script: `CreateObject("WScript.Shell").Run "powershell -enc AAAAAAAAAAAAAAAAAAAAAAAAAAAA"`}}
	// timestomped dropper: write time copied from kernel32.dll
	k32 := time.Date(2025, 3, 1, 4, 5, 6, 7*100, time.UTC)
	f.addFile(sys+"kernel32.dll", []byte("MZ"), msSig)
	f.mod[strings.ToLower(sys+"kernel32.dll")] = k32
	f.addFile(`C:\ProgramData\svc\host.exe`, []byte("MZ"), SigInfo{Status: SigUnsigned})
	f.mod[strings.ToLower(`C:\ProgramData\svc\host.exe`)] = k32
	f.simple(`\Timestomped`, `C:\ProgramData\svc\host.exe`, "", "LogonTrigger", "bob", "", false)
	// path tricks
	f.addFile(`C:\ProgramData\notes.txt:payload.exe`, []byte("MZ"), SigInfo{Status: SigUnsigned})
	f.simple(`\ADS`, `C:\ProgramData\notes.txt:payload.exe`, "", "LogonTrigger", "bob", "", false)

	r := Scan(f, ScanOptions{Tasks: true, Autostart: true, Signatures: true, Now: when})

	for _, p := range []string{`\Microsoft\Windows\WaaSMedic\PerformRemediation`} {
		if it := findItem(t, r.Tasks, p); it.Risk != RiskClean {
			t.Errorf("%s should be Clean: %+v", p, it.Findings)
		}
	}
	for p, want := range map[string]string{`\Vendor\ArgsDiffer`: RiskReview, `\VendorUpdater`: RiskReview,
		`\Timestomped`: RiskSuspicious, `\ADS`: RiskSuspicious} {
		if it := findItem(t, r.Tasks, p); it.Risk != want {
			t.Errorf("%s: want %s got %s %+v", p, want, it.Risk, it.Findings)
		}
	}
	if !findItem(t, r.Tasks, `\Timestomped`).has(FlagTimestomp) {
		t.Error("timestomp flag missing")
	}
	for _, c := range []struct{ loc, name, want string }{
		{"Driver", "Ntfs", RiskClean}, {"Service", "wuauserv", RiskClean}, {"Accessibility", "utilman.exe", RiskClean},
		{"Driver", "KdMap", RiskSuspicious}, {"Driver", "RTCore64", RiskReview},
		{"Accessibility", "sethc.exe", RiskSuspicious}, {"LSA", "Notification Packages", RiskSuspicious},
		{"WMI", "Updater", RiskSuspicious},
	} {
		if it := findAuto(t, r, c.loc, c.name); it.Risk != c.want {
			t.Errorf("%s/%s: want %s got %s %+v", c.loc, c.name, c.want, it.Risk, it.Findings)
		}
	}
	sysRisk := map[string]string{}
	for _, it := range r.System {
		sysRisk[it.Name+"="+it.Command] = it.Risk
	}
	for k, want := range map[string]string{"Driver test signing=ON": RiskSuspicious, `Defender exclusion (paths)=C:\`: RiskSuspicious,
		"Defender exclusion (extensions)=.exe": RiskSuspicious, "Vulnerable driver blocklist=on": RiskClean} {
		if sysRisk[k] != want {
			t.Errorf("system %s: want %s got %q (%v)", k, want, sysRisk[k], sysRisk)
		}
	}
}

func TestSignatureSmuggling(t *testing.T) {
	dir := os.Getenv("HK_FIXTURES")
	b, err := os.ReadFile(dir + "/HongKong.exe")
	if err != nil {
		t.Skip("fixture")
	}
	_, secDir, certOff, certSize, _ := peLayout(b)
	extra := bytes.Repeat([]byte{0xAB}, 16)
	b = append(b, extra...)
	binary.LittleEndian.PutUint32(b[secDir+4:], certSize+16)
	wl := binary.LittleEndian.Uint32(b[certOff:])
	binary.LittleEndian.PutUint32(b[certOff:], wl+16)
	es := VerifyEmbedded(b)
	if !es.DigestOK || es.Smuggled != 16 {
		t.Fatalf("smuggling not detected: digest=%v smuggled=%d err=%q", es.DigestOK, es.Smuggled, es.ParseErr)
	}
	if clean := VerifyEmbedded(readOrSkip(t, dir+"/HongKong.exe")); clean.Smuggled != 0 {
		t.Fatalf("false smuggling on clean file: %d", clean.Smuggled)
	}
}

func TestPathTricks(t *testing.T) {
	for p, want := range map[string]int{
		`C:\x\notes.txt:evil.exe`: 1, "C:\\x\\invoice\u202Efdp.exe": 1, `C:\x\svchost.exe.`: 1,
		`C:\x\report.pdf.exe`: 1, `C:\Program Files\App\app.exe`: 0, `\\?\C:\x\app.exe`: 0,
	} {
		if got := len(pathTricks(p)); got != want {
			t.Errorf("%q: %d tricks, want %d", p, got, want)
		}
	}
}

func TestUserTrust(t *testing.T) {
	r := scanScenario(t)
	it := findItem(t, r.Tasks, `\Updater`)
	if it.Risk == RiskClean {
		t.Fatal("precondition")
	}
	ut := &UserTrust{Keys: map[string]string{}, path: t.TempDir() + "/trusted.json"}
	ut.setTrusted(it, true)
	if it.Risk != RiskClean || !it.Trusted {
		t.Fatalf("trust not applied: %s", it.Risk)
	}
	if err := ut.save(); err != nil {
		t.Fatal(err)
	}
	// a fresh scan picks it up from disk
	r2 := scanScenario(t)
	r2.applyUserTrust(loadUserTrust(ut.path))
	if it2 := findItem(t, r2.Tasks, `\Updater`); it2.Risk != RiskClean {
		t.Fatalf("persisted trust not applied: %s", it2.Risk)
	}
	// the file changes -> trust no longer matches
	it3 := findItem(t, scanScenario(t).Tasks, `\Updater`)
	it3.Targets[0].SHA256 = "different"
	if ut.has(it3) {
		t.Fatal("trust must not survive a changed file")
	}
	ut.setTrusted(it, false)
	if it.Risk == RiskClean {
		t.Fatal("untrust did not restore findings")
	}
}

func utf16z(s string) []byte {
	var b []byte
	for _, r := range utf16.Encode([]rune(s)) {
		b = append(b, byte(r), byte(r>>8))
	}
	return append(b, 0, 0)
}

func TestStaleTaskCacheEntries(t *testing.T) {
	f := buildScenario()
	// Real-world leftovers from the user's machine: Tree + Tasks keys, no XML, no Actions.
	for i, p := range []string{`\Microsoft\Windows\Application Experience\AitAgent`,
		`\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask`,
		`\Microsoft\Windows\Clip\ClipESUConsumer`, `\Microsoft\Windows\WindowsBackup\ConfigNotification`} {
		f.registerTask(p, fmt.Sprintf("{00000000-0000-0000-0000-0000000B%04d}", i), nil, true)
	}
	// Unknown blob layout that still contains an untrusted program path.
	odd := append([]byte{9, 0, 0xAA, 0xBB}, utf16z(`C:\ProgramData\cheat\loader.exe`)...)
	odd = append(odd, utf16z("--hidden")...)
	f.registerTask(`\SneakyRegistryOnly`, "{00000000-0000-0000-0000-0000000C0001}", odd, true)
	// Non-Microsoft folder, nothing readable.
	f.registerTask(`\Vendor\Leftover`, "{00000000-0000-0000-0000-0000000C0002}", nil, true)

	r := Scan(f, ScanOptions{Tasks: true, Signatures: true, Now: time.Date(2026, 11, 5, 0, 0, 0, 0, time.UTC)})
	for _, p := range []string{`\Microsoft\Windows\Application Experience\AitAgent`, `\Microsoft\Windows\Clip\ClipESUConsumer`} {
		if it := findItem(t, r.Tasks, p); it.Risk != RiskClean {
			t.Errorf("stale %s should be Clean: %+v", p, it.Findings)
		}
	}
	s := findItem(t, r.Tasks, `\SneakyRegistryOnly`)
	if s.Risk != RiskSuspicious || !strings.Contains(s.Command, "loader.exe") {
		t.Errorf("recovered registry-only task: %s %q %+v", s.Risk, s.Command, s.Findings)
	}
	if v := findItem(t, r.Tasks, `\Vendor\Leftover`); v.Risk != RiskReview {
		t.Errorf("non-Microsoft leftover should be Review: %s", v.Risk)
	}
}

func TestCertNoiseOnRealMachines(t *testing.T) {
	f := buildScenario() // no authroot CTL cached, like many real PCs
	old := time.Date(2019, 6, 1, 0, 0, 0, 0, time.UTC)
	put := func(store, cn string, ekus []x509.ExtKeyUsage, nb time.Time) string {
		der := selfSignedCert(t, cn, ekus, nil, nb)
		th := thumbOf(der)
		f.setBin(store+`\`+th, "Blob", certBlob(der))
		return th
	}
	userRoot := `HKU\S-1-5-21-1\Software\Microsoft\SystemCertificates\Root\Certificates`
	machineRoot := `HKLM\` + keyCerts + `\ROOT\Certificates`
	pub := `HKLM\` + keyCerts + `\TrustedPublisher\Certificates`
	clean := []string{
		put(userRoot, "DO_NOT_TRUST_FiddlerRoot", nil, old),
		put(machineRoot, "Kaspersky Anti-Virus Personal Root Certificate", nil, old),
		put(machineRoot, "Corp Internal Root CA", nil, old),
		put(pub, "Old Driver Vendor", []x509.ExtKeyUsage{x509.ExtKeyUsageCodeSigning}, old),
	}
	fresh := put(userRoot, "Totally Normal Root", nil, time.Date(2026, 10, 30, 0, 0, 0, 0, time.UTC))
	r := Scan(f, ScanOptions{Tasks: true, Autostart: true, Signatures: true, Now: time.Date(2026, 11, 5, 0, 0, 0, 0, time.UTC)})
	byThumb := map[string]*Item{}
	for _, c := range r.Certs {
		byThumb[c.Command] = c
	}
	for _, th := range clean {
		if c := byThumb[th]; c == nil || c.Risk != RiskClean {
			t.Errorf("cert %v should be Clean: %+v", c.Name, c.Findings)
		}
	}
	if c := byThumb[fresh]; c == nil || c.Risk != RiskReview {
		t.Errorf("fresh user root should be Review: %+v", c)
	}
}

// From a real Windows 11 scan: Windows updates remove built-in tasks but
// leave Tree keys (often without actions, sometimes without SD).
func TestStaleTaskCacheRegistrations(t *testing.T) {
	f := buildScenario()
	sys := `C:\Windows\System32\`
	stale := []string{`\Microsoft\Windows\Application Experience\AitAgent`, `\Microsoft\Windows\Application Experience\ProgramDataUpdater`,
		`\Microsoft\Windows\Clip\ClipESU`, `\Microsoft\Windows\Maintenance\CorruptionDetector`}
	for i, p := range stale {
		id := fmt.Sprintf("{00000000-0000-0000-0000-0000000B%04d}", i)
		f.setStr(tc+`\Tree`+p, "Id", id)
		if i%2 == 0 {
			f.setBin(tc+`\Tree`+p, "SD", []byte{1})
		}
		if i == 1 {
			f.setStr(tc+`\Tasks\`+id, "Path", p) // Tasks entry exists but has no actions
		}
	}
	// registry-only, runs a genuine Microsoft program: stale Windows registration
	f.registerTask(`\Microsoft\Windows\DirectX\DirectXDatabaseUpdater`, "{00000000-0000-0000-0000-00000000C001}", execBlob(3, sys+"sc.exe", "start x"), true)
	// registry-only, runs an untrusted file: still a threat
	f.addFile(`C:\ProgramData\x\ghost.exe`, []byte("MZ"), SigInfo{Status: SigUnsigned})
	f.registerTask(`\Microsoft\Windows\Ghosted`, "{00000000-0000-0000-0000-00000000C002}", execBlob(3, `C:\ProgramData\x\ghost.exe`, ""), false)

	r := Scan(f, ScanOptions{Tasks: true, Signatures: true, Now: time.Date(2026, 11, 5, 0, 0, 0, 0, time.UTC)})
	for _, p := range append(stale, `\Microsoft\Windows\DirectX\DirectXDatabaseUpdater`) {
		if it := findItem(t, r.Tasks, p); it.Risk != RiskClean {
			t.Errorf("%s should be Clean: %s %+v", p, it.Risk, it.Findings)
		}
	}
	if it := findItem(t, r.Tasks, `\Microsoft\Windows\Ghosted`); it.Risk != RiskSuspicious {
		t.Errorf("registry-only untrusted task must stay Suspicious: %s %+v", it.Risk, it.Findings)
	}
}
