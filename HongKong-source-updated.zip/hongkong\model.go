package main

import (
	"sort"
	"strings"
	"time"
)

const appName = "HongKong"
const appVersion = "5.0.0"

// Attribute flags. They describe what was observed and drive the filter
// buttons; the risk comes from finding severities, not from the flags.
const (
	FlagIFEO              uint64 = 1 << iota // IFEO Debugger / SilentProcessExit
	FlagStaticAnalysis                       // command-line indicators
	FlagTaskCacheMismatch                    // registry-only task, Tree -> missing Tasks entry, path mismatch
	FlagActionMismatch                       // XML actions differ from the TaskCache actions (the ones that run)
	FlagTreeMissingID                        // Tree key without Id
	FlagSDMissing                            // Tree key without SD: hidden from schtasks / UI
	FlagExecHost                             // script host / LOLBin
	FlagRecent                               // changed within RecentDays
	FlagUnsigned                             // no signature, or signature could not be verified
	FlagNotOnDisk                            // target missing
	FlagSelfSigned                           // self-signed leaf, untrusted root, or locally trusted self-signed cert
	FlagBadSignature                         // tampered: hash mismatch, broken/revoked cert, unsigned Windows binary
	FlagHeurLnk                              // launches a .lnk
	FlagHeurArgs                             // arguments reference a payload file
	FlagHiddenSetting                        // <Hidden>true</Hidden>
	FlagUserWritable                         // target in a user-writable directory
	FlagMasquerade                           // system name outside Windows dirs, or renamed system binary
	FlagCOMHijack                            // ComHandler CLSID overridden in a user hive
	FlagOrphan                               // XML not registered / Tasks entry without Tree
	FlagNonDefault                           // Winlogon / AppInit changed from default
	FlagUnusualExt                           // non-executable extension
	FlagHighPriv                             // SYSTEM / highest privileges
	FlagImpersonation                        // untrusted signer claims a well-known vendor name
	FlagUserRoot                             // root certificate added to a user's trusted store
	FlagCodeSigningRoot                      // self-made code-signing certificate trusted on this machine
	FlagSignsTarget                          // certificate signs something that runs on this machine
	FlagPathTrick                            // ADS, RTLO, trailing dot/space, double extension
	FlagTimestomp                            // file times cloned from a system file or older than the build
	FlagSmuggled                             // data hidden inside the signature block
	FlagDriver                               // kernel driver / vulnerable driver
	FlagSystemWeak                           // weakened Windows security setting
)

type flagInfo struct {
	Bit   uint64 `json:"bit"`
	Key   string `json:"key"`
	Label string `json:"label"`
}

var flagTable = []flagInfo{
	{FlagIFEO, "ifeo", "IFEO hijack"},
	{FlagStaticAnalysis, "static", "Static analysis"},
	{FlagTaskCacheMismatch, "registry", "TaskCache mismatch"},
	{FlagActionMismatch, "actionMismatch", "XML / TaskCache action mismatch"},
	{FlagTreeMissingID, "treeMissingId", "Tree task missing Id"},
	{FlagSDMissing, "sdMissing", "Hidden (SD removed)"},
	{FlagExecHost, "executionHost", "Execution host"},
	{FlagRecent, "recent", "Recently changed"},
	{FlagUnsigned, "unsigned", "Unsigned / unverified"},
	{FlagNotOnDisk, "offDisk", "Missing file"},
	{FlagSelfSigned, "selfSigned", "Self-signed / untrusted root"},
	{FlagBadSignature, "tampered", "Tampered signature"},
	{FlagHeurLnk, "lnk", "LNK action"},
	{FlagHeurArgs, "argPayload", "Argument payload"},
	{FlagHiddenSetting, "hidden", "Hidden setting"},
	{FlagUserWritable, "userWritable", "User-writable path"},
	{FlagMasquerade, "masquerade", "Masquerade / renamed binary"},
	{FlagCOMHijack, "comHijack", "COM hijack"},
	{FlagOrphan, "orphan", "Orphaned registration"},
	{FlagNonDefault, "nonDefault", "Non-default value"},
	{FlagUnusualExt, "unusualExt", "Unusual extension"},
	{FlagHighPriv, "highPriv", "Privileged"},
	{FlagImpersonation, "impersonation", "Vendor impersonation"},
	{FlagUserRoot, "userRoot", "User-installed root"},
	{FlagCodeSigningRoot, "codeSigningRoot", "Self-made code-signing cert"},
	{FlagSignsTarget, "signsTarget", "Signs a running file"},
	{FlagPathTrick, "pathTrick", "Path trick"},
	{FlagTimestomp, "timestomp", "Timestomped"},
	{FlagSmuggled, "smuggled", "Signature smuggling"},
	{FlagDriver, "driver", "Driver"},
	{FlagSystemWeak, "systemWeak", "Weakened security"},
}

func flagNames(f uint64) []string {
	out := []string{}
	for _, fi := range flagTable {
		if f&fi.Bit != 0 {
			out = append(out, fi.Key)
		}
	}
	return out
}

type Sev int

const (
	SevInfo Sev = iota
	SevMedium
	SevHigh
)

func (s Sev) String() string {
	switch s {
	case SevHigh:
		return "high"
	case SevMedium:
		return "medium"
	}
	return "info"
}

type Finding struct {
	Sev  Sev    `json:"sev"`
	Flag uint64 `json:"-"`
	Text string `json:"text"`
}

const (
	RiskSuspicious = "Suspicious"
	RiskReview     = "Review"
	RiskClean      = "Clean"
)

func riskRank(r string) int {
	switch r {
	case RiskSuspicious:
		return 0
	case RiskReview:
		return 1
	}
	return 2
}

// SigInfo is the Authenticode verdict for a single file.
type SigInfo struct {
	Status       string `json:"status"`
	RawStatus    string `json:"rawStatus,omitempty"`
	Signer       string `json:"signer,omitempty"`
	Issuer       string `json:"issuer,omitempty"`
	ChainRoot    string `json:"chainRoot,omitempty"`
	ChainStatus  string `json:"chainStatus,omitempty"`
	Thumbprint   string `json:"thumbprint,omitempty"`
	Type         string `json:"type,omitempty"` // Authenticode / Catalog
	Timestamped  bool   `json:"timestamped,omitempty"`
	SelfSigned   bool   `json:"selfSigned,omitempty"`
	IsMicrosoft  bool   `json:"isMicrosoft,omitempty"`
	OriginalName string `json:"originalName,omitempty"`
	Company      string `json:"company,omitempty"`

	RootThumb     string    `json:"rootThumb,omitempty"`
	RootNotBefore time.Time `json:"rootNotBefore,omitempty"`
	UserRoot      string    `json:"userRoot,omitempty"` // hive whose Root store holds the chain root
	Embedded      bool      `json:"embedded,omitempty"` // verified natively from the file
	Note          string    `json:"note,omitempty"`
	Smuggled      int       `json:"smuggled,omitempty"`    // bytes hidden after the PKCS#7 blob
	CompileTime   time.Time `json:"compileTime,omitempty"` // PE TimeDateStamp
}

const (
	SigValid          = "Signed (Valid)"
	SigSelfSigned     = "Self-signed"
	SigSelfTrusted    = "Self-signed (locally trusted)"
	SigUntrustedRoot  = "Untrusted root"
	SigHashMismatch   = "Tampered (hash mismatch)"
	SigBadCert        = "Tampered (invalid certificate)"
	SigRevoked        = "Revoked / distrusted"
	SigUnverified     = "Unverified"
	SigUnsigned       = "Unsigned"
	SigNotOnDisk      = "Not on disk"
	SigUnknown        = "Unknown"
	SigSkipped        = "Not checked"
	SigUnsignedWinDir = "Unsigned (Windows directory)"
	SigForged         = "Forged (fake root)"
	SigLocalRoot      = "Signed by locally trusted root"
	SigExpired        = "Signed (expired certificate)"
)

// trusted means a valid signature chaining to a trusted root that is not a
// self-signed leaf. This is the main false-positive brake: trusted publishers
// do not get flagged for living in AppData or using script hosts.
func (s SigInfo) trusted() bool { return s.Status == SigValid }

// Target is one file a task or autostart entry executes or loads.
type Target struct {
	Role         string    `json:"role"` // action, argument, lnk-target, com-server
	Raw          string    `json:"raw"`
	Path         string    `json:"path"`
	Exists       bool      `json:"exists"`
	Size         int64     `json:"size,omitempty"`
	SHA256       string    `json:"sha256,omitempty"`
	Sig          SigInfo   `json:"sig"`
	UserWritable bool      `json:"userWritable,omitempty"`
	ModTime      time.Time `json:"modTime,omitempty"`
	CTime        time.Time `json:"cTime,omitempty"`
}

var roleLabel = map[string]string{"action": "action file", "argument": "argument payload",
	"lnk-target": "shortcut target", "com-server": "COM server", "service-dll": "service DLL"}

type Action struct {
	Kind       string `json:"kind"`
	Command    string `json:"command,omitempty"`
	Arguments  string `json:"arguments,omitempty"`
	WorkingDir string `json:"workingDir,omitempty"`
	ClassID    string `json:"classId,omitempty"`
	Data       string `json:"data,omitempty"`
}

func (a Action) display() string {
	switch a.Kind {
	case "Exec":
		if a.Arguments != "" {
			return a.Command + " " + a.Arguments
		}
		return a.Command
	case "ComHandler":
		s := "COM " + a.ClassID
		if a.Data != "" {
			s += " " + a.Data
		}
		return s
	}
	return a.Kind
}

type KV struct {
	K string `json:"k"`
	V string `json:"v"`
}

// Item is a scheduled task or an autostart entry after analysis.
type Item struct {
	Kind        string    `json:"kind"` // task | autostart
	ID          string    `json:"id"`
	Name        string    `json:"name"`
	Path        string    `json:"path"`
	Location    string    `json:"location,omitempty"`
	Source      string    `json:"source,omitempty"`
	Author      string    `json:"author,omitempty"`
	Description string    `json:"description,omitempty"`
	RegDate     string    `json:"regDate,omitempty"`
	Modified    time.Time `json:"modified,omitempty"`
	Enabled     bool      `json:"enabled"`
	Hidden      bool      `json:"hidden,omitempty"`
	RunAs       string    `json:"runAs,omitempty"`
	RunLevel    string    `json:"runLevel,omitempty"`
	Triggers    []string  `json:"triggers,omitempty"`
	BootTrigger bool      `json:"bootTrigger,omitempty"`
	LogonTrig   bool      `json:"logonTrigger,omitempty"`

	Command          string   `json:"command"`
	XMLActions       []Action `json:"xmlActions,omitempty"`
	TaskCacheActions []Action `json:"taskCacheActions,omitempty"`
	TaskCacheID      string   `json:"taskCacheId,omitempty"`
	XMLFile          string   `json:"xmlFile,omitempty"`

	Targets  []Target  `json:"targets,omitempty"`
	Entropy  float64   `json:"entropy"`
	Flags    uint64    `json:"flags"`
	FlagKeys []string  `json:"flagKeys"`
	Findings []Finding `json:"findings"`
	Details  []KV      `json:"details,omitempty"`
	Risk     string    `json:"risk"`

	SignatureStatus string `json:"signatureStatus"`
	Signer          string `json:"signer,omitempty"`
	SHA256          string `json:"sha256,omitempty"`
	Trusted         bool   `json:"trustedByUser,omitempty"`

	original []Finding // findings before the user marked it trusted
}

// add records a finding and sets its attribute flag.
func (it *Item) add(sev Sev, flag uint64, text string) {
	it.Flags |= flag
	if text == "" {
		return
	}
	for i, f := range it.Findings {
		if f.Text == text {
			if sev > f.Sev {
				it.Findings[i].Sev = sev
			}
			return
		}
	}
	it.Findings = append(it.Findings, Finding{Sev: sev, Flag: flag, Text: text})
}

// adjust rewrites the severity of every finding raised under flag.
func (it *Item) adjust(flag uint64, fn func(Sev) Sev) {
	for i := range it.Findings {
		if it.Findings[i].Flag&flag != 0 {
			it.Findings[i].Sev = fn(it.Findings[i].Sev)
		}
	}
}

// drop removes all findings and the attribute for flag.
func (it *Item) drop(flag uint64) {
	out := it.Findings[:0]
	for _, f := range it.Findings {
		if f.Flag&flag == 0 {
			out = append(out, f)
		}
	}
	it.Findings = out
	it.Flags &^= flag
}

func (it *Item) detail(k, v string) {
	if strings.TrimSpace(v) == "" {
		return
	}
	it.Details = append(it.Details, KV{k, v})
}

func (it *Item) has(f uint64) bool { return it.Flags&f != 0 }

func (it *Item) maxSev() Sev {
	m := SevInfo
	for _, f := range it.Findings {
		if f.Sev > m {
			m = f.Sev
		}
	}
	return m
}

func (it *Item) computeRisk() {
	switch it.maxSev() {
	case SevHigh:
		it.Risk = RiskSuspicious
	case SevMedium:
		it.Risk = RiskReview
	default:
		it.Risk = RiskClean
	}
	sort.SliceStable(it.Findings, func(i, j int) bool { return it.Findings[i].Sev > it.Findings[j].Sev })
	it.FlagKeys = flagNames(it.Flags)
	if it.Findings == nil {
		it.Findings = []Finding{}
	}
}

// headline is the short findings summary shown in the results table.
func (it *Item) headline() string {
	var parts []string
	for _, f := range it.Findings {
		if f.Sev > SevInfo {
			parts = append(parts, f.Text)
		}
	}
	return strings.Join(parts, "; ")
}

type Summary struct {
	Tasks      int            `json:"tasks"`
	Autostart  int            `json:"autostart"`
	Certs      int            `json:"certificates"`
	System     int            `json:"system"`
	Suspicious int            `json:"suspicious"`
	Review     int            `json:"review"`
	Clean      int            `json:"clean"`
	ByFlag     map[string]int `json:"byFlag"`
}

type ScanResult struct {
	Tool      string        `json:"tool"`
	Version   string        `json:"version"`
	Generated time.Time     `json:"generated"`
	Duration  time.Duration `json:"durationNs"`
	Host      string        `json:"host"`
	User      string        `json:"user"`
	Elevated  bool          `json:"elevated"`
	Notes     []string      `json:"notes"`
	Tasks     []*Item       `json:"tasks"`
	Autostart []*Item       `json:"autostart"`
	Certs     []*Item       `json:"certificates"`
	System    []*Item       `json:"system"`
	Summary   Summary       `json:"summary"`
}

func (r *ScanResult) summarize() {
	s := Summary{Tasks: len(r.Tasks), Autostart: len(r.Autostart), Certs: len(r.Certs), System: len(r.System), ByFlag: map[string]int{}}
	for _, list := range [][]*Item{r.Tasks, r.Autostart, r.Certs, r.System} {
		for _, it := range list {
			switch it.Risk {
			case RiskSuspicious:
				s.Suspicious++
			case RiskReview:
				s.Review++
			default:
				s.Clean++
			}
			if it.Risk != RiskClean {
				for _, k := range it.FlagKeys {
					s.ByFlag[k]++
				}
			}
		}
	}
	r.Summary = s
}

func sortItems(items []*Item) {
	sort.SliceStable(items, func(i, j int) bool {
		a, b := items[i], items[j]
		if riskRank(a.Risk) != riskRank(b.Risk) {
			return riskRank(a.Risk) < riskRank(b.Risk)
		}
		return strings.ToLower(a.Path+a.Name) < strings.ToLower(b.Path+b.Name)
	})
}
