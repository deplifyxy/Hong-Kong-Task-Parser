package main

import (
	"crypto/x509"
	"encoding/asn1"
	"fmt"
	"sort"
	"strings"
	"time"
)

const keyCerts = `SOFTWARE\Microsoft\SystemCertificates`

// loadTrust reads what this machine actually trusts from the registry.
func (s *scanner) loadTrust() *TrustDB {
	db := newTrustDB()
	if v, ok := s.values("HKLM", keyCerts+`\AuthRoot\AutoUpdate`)["encodedctl"]; ok && len(v.Bin) > 0 {
		db.CTL = parseCTL(v.Bin)
	}
	for _, k := range s.subkeys("HKLM", keyCerts+`\AuthRoot\Certificates`) {
		db.CTL[strings.ToUpper(k)] = true
	}
	db.CTLLoaded = len(db.CTL) >= 100
	if !db.CTLLoaded {
		s.note("Microsoft's root list (authroot) is not cached on this PC, so only forged-Microsoft and user-installed roots are judged.")
	}
	for _, k := range []string{`SOFTWARE\Policies\Microsoft\SystemCertificates\Root\Certificates`,
		`SOFTWARE\Microsoft\EnterpriseCertificates\Root\Certificates`} {
		for _, t := range s.subkeys("HKLM", k) {
			db.Enterprise[strings.ToUpper(t)] = true
		}
	}
	for _, store := range []string{`\ROOT\Certificates`, `\AuthRoot\Certificates`} {
		for _, t := range s.subkeys("HKLM", keyCerts+store) {
			db.Machine[strings.ToUpper(t)] = true
		}
	}
	for _, t := range s.subkeys("HKLM", keyCerts+`\Disallowed\Certificates`) {
		db.Disallowed[strings.ToUpper(t)] = true
	}
	for _, h := range s.userHives {
		for _, t := range s.subkeys(h, `Software\Microsoft\SystemCertificates\Root\Certificates`) {
			db.UserRoots[strings.ToUpper(t)] = h
		}
	}
	return db
}

var certStores = []struct {
	sub, label string
	user, root bool
}{
	{`Software\Microsoft\SystemCertificates\Root\Certificates`, "User Root", true, true},
	{`Software\Microsoft\SystemCertificates\TrustedPublisher\Certificates`, "User TrustedPublisher", true, false},
	{keyCerts + `\ROOT\Certificates`, "Machine Root", false, true},
	{keyCerts + `\TrustedPublisher\Certificates`, "Machine TrustedPublisher", false, false},
}

var (
	oidEKUCodeSigning = asn1.ObjectIdentifier{1, 3, 6, 1, 5, 5, 7, 3, 3}
	oidAspNetDevCert  = asn1.ObjectIdentifier{1, 3, 6, 1, 4, 1, 311, 84, 1, 1}
)

func hasExt(c *x509.Certificate, oid asn1.ObjectIdentifier) bool {
	for _, e := range c.Extensions {
		if e.Id.Equal(oid) {
			return true
		}
	}
	return false
}

func codeSigningCapable(c *x509.Certificate) bool {
	if len(c.ExtKeyUsage) == 0 && len(c.UnknownExtKeyUsage) == 0 {
		return true // no EKU restriction: valid for everything
	}
	for _, u := range c.ExtKeyUsage {
		if u == x509.ExtKeyUsageCodeSigning || u == x509.ExtKeyUsageAny {
			return true
		}
	}
	for _, u := range c.UnknownExtKeyUsage {
		if u.Equal(oidEKUCodeSigning) {
			return true
		}
	}
	return false
}

// collectCerts audits the trusted root / trusted publisher stores
// (the ClubhouseAnchor "self sign" angle, applied to the whole machine).
func (s *scanner) collectCerts() []*Item {
	var items []*Item
	now := s.o.Now
	type loc struct {
		hive, sub, label string
		user, root       bool
	}
	var locs []loc
	for _, st := range certStores {
		if st.user {
			for _, h := range s.userHives {
				locs = append(locs, loc{h, st.sub, st.label, true, st.root})
			}
		} else {
			locs = append(locs, loc{"HKLM", st.sub, st.label, false, st.root})
		}
	}
	for _, l := range locs {
		for _, thumb := range s.subkeys(l.hive, l.sub) {
			thumb = strings.ToUpper(thumb)
			vals := s.values(l.hive, l.sub+`\`+thumb)
			it := s.newItem("cert")
			it.Location = l.label
			it.Path = l.hive + `\` + l.sub + `\` + thumb
			it.Command = thumb
			it.detail("Thumbprint", thumb)
			it.detail("Store", it.Path)
			der := certFromBlob(vals["blob"].Bin)
			c, err := x509.ParseCertificate(der)
			if err != nil || c == nil {
				it.Name = "(unparsed certificate) " + thumb
				it.SignatureStatus = "-"
				if l.user && l.root && !s.trust.inProgram(thumb) {
					it.add(SevMedium, FlagUserRoot, "Unreadable root certificate added to a user's trusted store")
				}
				items = append(items, it)
				continue
			}
			s.scoreCert(it, c, thumb, l.user, l.root, now)
			items = append(items, it)
		}
	}
	for _, it := range items {
		it.computeRisk()
	}
	return items
}

func (s *scanner) scoreCert(it *Item, c *x509.Certificate, thumb string, user, root bool, now time.Time) {
	subj := c.Subject.String()
	it.Name = firstCN(subj)
	if it.Name == "" {
		it.Name = subj
	}
	self := c.Subject.String() == c.Issuer.String()
	it.Signer = firstCN(c.Issuer.String())
	if self {
		it.SignatureStatus = "Self-signed"
	} else {
		it.SignatureStatus = "Issued by " + it.Signer
	}
	it.Description = subj
	it.RegDate = c.NotBefore.Format("2006-01-02")
	it.detail("Subject", subj)
	it.detail("Issuer", c.Issuer.String())
	it.detail("Valid", c.NotBefore.Format("2006-01-02")+" to "+c.NotAfter.Format("2006-01-02"))
	it.detail("Serial", fmt.Sprintf("%X", c.SerialNumber))
	var ekus []string
	if codeSigningCapable(c) {
		ekus = append(ekus, "code signing")
	}
	if len(c.ExtKeyUsage) == 0 {
		ekus = append(ekus, "(unrestricted)")
	}
	it.detail("Usage", strings.Join(ekus, ", "))

	inProgram := s.trust.inProgram(thumb)
	enterprise := s.trust.Enterprise[thumb]
	ageDays := int(now.Sub(c.NotBefore).Hours() / 24)
	fresh := ageDays >= 0 && ageDays <= 365
	trustedSource := inProgram || enterprise
	if user && s.trust.Machine[thumb] {
		trustedSource = true // a copy of something the machine already trusts
	}
	if !user && !s.trust.CTLLoaded && ageDays > 90 {
		trustedSource = true // can't check Microsoft's list: give established machine roots the benefit of the doubt
	}
	devCert := hasExt(c, oidAspNetDevCert)
	explicitCodeSigning := false
	for _, u := range c.ExtKeyUsage {
		if u == x509.ExtKeyUsageCodeSigning {
			explicitCodeSigning = true
		}
	}

	// 1. Fake Microsoft roots.
	if forged, _ := s.trust.rootVerdict(thumb, subj, subj, c.NotBefore, now); forged {
		it.add(SevHigh, FlagImpersonation|FlagSelfSigned, "Fake Microsoft certificate: named \""+it.Name+"\" but it is not a genuine Microsoft certificate")
	}
	// 2. Roots a user added. Old ones are usually developer / proxy tools.
	if user && root && !trustedSource {
		switch {
		case devCert:
			it.add(SevInfo, FlagUserRoot, "ASP.NET Core development certificate")
		case fresh || explicitCodeSigning || impersonatedVendor(subj) != "":
			it.add(SevMedium, FlagUserRoot, fmt.Sprintf("Root certificate added to a user's trusted store %d day(s) after it was created", ageDays))
		default:
			it.add(SevInfo, FlagUserRoot, "Older root certificate in a user's trusted store (typically a developer or proxy tool)")
		}
	}
	// 3. Self-made certificates trusted for code.
	if !trustedSource && self && !devCert && explicitCodeSigning {
		it.add(SevMedium, FlagCodeSigningRoot, "Self-signed code-signing certificate is trusted on this machine")
	}
	if !root && self && !trustedSource {
		sev := SevInfo
		if fresh {
			sev = SevMedium
		}
		it.add(sev, FlagCodeSigningRoot, "Self-signed certificate is a trusted publisher (its code runs without prompts)")
	}
	if !trustedSource && ageDays >= 0 && ageDays <= 30 {
		sev := SevInfo
		if user {
			sev = SevMedium
		}
		it.add(sev, FlagRecent, fmt.Sprintf("Created %d day(s) ago", ageDays))
	}
	if !trustedSource && s.trust.CTLLoaded && !user {
		it.add(SevInfo, 0, "Not part of Microsoft's root program (normal for antivirus, VPN or company certificates)")
	}
	// 3. Cross-reference: does it sign something that runs here?
	if files := s.rootUse[thumb]; len(files) > 0 && !trustedSource {
		sort.Strings(files)
		it.add(SevHigh, FlagSignsTarget, fmt.Sprintf("Signs %d file(s) that run at startup or from tasks: %s", len(files), strings.Join(files, ", ")))
	}
	if inProgram {
		it.detail("Trust", "Microsoft Trusted Root Program")
	} else if enterprise {
		it.detail("Trust", "Enterprise / Group Policy")
	}
}
