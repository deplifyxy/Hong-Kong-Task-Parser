"""Draws the HongKong app icon: a black tile with a neon-red bauhinia
pinwheel and glow (neon-sign style). Writes assets/icon_<size>.png."""
import sys
from PIL import Image, ImageDraw, ImageFilter, ImageChops

S = 1024
SIZES = [16, 20, 24, 32, 40, 48, 64, 128, 256]
out_dir = sys.argv[1] if len(sys.argv) > 1 else "assets"
NEON = (236, 56, 32)  # Hong Kong flag red, lifted for the neon glow

def petal_mask(width):
    """Outline (or solid if width=0) of the five-petal pinwheel."""
    m = Image.new("L", (S, S), 0)
    c = S // 2
    for k in range(5):
        p = Image.new("L", (S, S), 0)
        d = ImageDraw.Draw(p)
        box = [c - 30, c - 380, c + 160, c - 40]
        if width:
            d.ellipse(box, outline=255, width=width)
            d.arc([c - 100, c - 310, c + 130, c - 60], start=300, end=40, fill=255, width=max(8, width // 2))
        else:
            d.ellipse(box, fill=255)
        m = ImageChops.lighter(m, p.rotate(-72 * k, resample=Image.BICUBIC, center=(c, c)))
    return m

def render():
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    tile = Image.new("L", (S, S), 0)
    ImageDraw.Draw(tile).rounded_rectangle([20, 20, S - 20, S - 20], radius=170, fill=255)
    bg = Image.new("RGBA", (S, S), (10, 9, 12, 255))
    # faint scanlines
    sl = ImageDraw.Draw(bg)
    for y in range(0, S, 12):
        sl.line([(0, y), (S, y)], fill=(16, 14, 19, 255), width=4)
    img.paste(bg, (0, 0), tile)
    # thin neon frame
    frame = Image.new("L", (S, S), 0)
    ImageDraw.Draw(frame).rounded_rectangle([44, 44, S - 44, S - 44], radius=150, outline=255, width=10)
    def neon(mask, glow_r, glow_a):
        glow = mask.filter(ImageFilter.GaussianBlur(glow_r)).point(lambda v: min(255, int(v * glow_a)))
        g = Image.new("RGBA", (S, S), NEON + (0,))
        g.putalpha(glow)
        img.alpha_composite(g)
        core = Image.new("RGBA", (S, S), NEON + (0,))
        core.putalpha(mask)
        img.alpha_composite(core)
        hot = Image.new("RGBA", (S, S), (255, 190, 196, 0))
        hot.putalpha(mask.filter(ImageFilter.MinFilter(9)).point(lambda v: int(v * 0.55)))
        img.alpha_composite(hot)
    neon(frame.point(lambda v: int(v * 0.6)), 18, 1.4)
    neon(petal_mask(40), 34, 2.2)
    c = S // 2
    dot = Image.new("L", (S, S), 0)
    ImageDraw.Draw(dot).ellipse([c - 36, c - 36, c + 36, c + 36], fill=255)
    neon(dot, 20, 2.0)
    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    out.paste(img, (0, 0), tile)
    return out

big = render()
for s in SIZES:
    im = big.resize((s, s), Image.LANCZOS)
    if s <= 32:
        # small sizes: solid petals read better than outlines
        small = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        tile = Image.new("L", (S, S), 0)
        ImageDraw.Draw(tile).rounded_rectangle([20, 20, S - 20, S - 20], radius=170, fill=255)
        small.paste(Image.new("RGBA", (S, S), (12, 10, 14, 255)), (0, 0), tile)
        pm = petal_mask(0)
        core = Image.new("RGBA", (S, S), NEON + (0,))
        core.putalpha(pm)
        small.alpha_composite(core)
        im = small.resize((s, s), Image.LANCZOS).filter(ImageFilter.UnsharpMask(radius=1, percent=60, threshold=0))
    im.save(f"{out_dir}/icon_{s}.png")
big.save(f"{out_dir}/logo_1024.png")
strip = Image.new("RGBA", (sum(SIZES) + 10 * len(SIZES) + 10, 266), (20, 20, 24, 255))
x = 10
for s in SIZES:
    strip.alpha_composite(Image.open(f"{out_dir}/icon_{s}.png"), (x, 266 - 10 - s))
    x += s + 10
strip.save(f"{out_dir}/preview.png")
print("ok")
