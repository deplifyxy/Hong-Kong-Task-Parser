//go:build windows

package main

import (
	"math"
	"strings"
	"syscall"
	"unsafe"
)

// Drawing helpers: GDI+ (flat API) for anti-aliased shapes, GDI for text.
// GDI+ calls only take integer coordinates; the few REAL parameters sit in
// stack slots, so they are passed as float32 bits.

var (
	gdiplus                 = syscall.NewLazyDLL("gdiplus.dll")
	pGdiplusStartup         = gdiplus.NewProc("GdiplusStartup")
	pGdipCreateFromHDC      = gdiplus.NewProc("GdipCreateFromHDC")
	pGdipDeleteGraphics     = gdiplus.NewProc("GdipDeleteGraphics")
	pGdipSetSmoothingMode   = gdiplus.NewProc("GdipSetSmoothingMode")
	pGdipCreateSolidFill    = gdiplus.NewProc("GdipCreateSolidFill")
	pGdipCreateLineBrushI   = gdiplus.NewProc("GdipCreateLineBrushI")
	pGdipDeleteBrush        = gdiplus.NewProc("GdipDeleteBrush")
	pGdipCreatePath         = gdiplus.NewProc("GdipCreatePath")
	pGdipDeletePath         = gdiplus.NewProc("GdipDeletePath")
	pGdipAddPathArcI        = gdiplus.NewProc("GdipAddPathArcI")
	pGdipClosePathFigure    = gdiplus.NewProc("GdipClosePathFigure")
	pGdipFillPath           = gdiplus.NewProc("GdipFillPath")
	pGdipFillEllipseI       = gdiplus.NewProc("GdipFillEllipseI")
	pGdipFillRectangleI     = gdiplus.NewProc("GdipFillRectangleI")
	pCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	pCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	pBitBlt                 = gdi32.NewProc("BitBlt")
	pDeleteDC               = gdi32.NewProc("DeleteDC")
	pDeleteObject           = gdi32.NewProc("DeleteObject")
	pDwmSetWindowAttribute  = syscall.NewLazyDLL("dwmapi.dll").NewProc("DwmSetWindowAttribute")
)

var gdipReady bool

func gdipStartup() {
	type startupInput struct {
		Version         uint32
		Callback        uintptr
		SuppressBgThr   int32
		SuppressExtCode int32
	}
	in := startupInput{Version: 1}
	var token uintptr
	if pGdiplusStartup.Find() != nil {
		return
	}
	r, _, _ := pGdiplusStartup.Call(uintptr(unsafe.Pointer(&token)), uintptr(unsafe.Pointer(&in)), 0)
	gdipReady = r == 0
}

// Color is 0xAARRGGBB.
type Color uint32

func argb(a, r, g, b byte) Color {
	return Color(uint32(a)<<24 | uint32(r)<<16 | uint32(g)<<8 | uint32(b))
}
func hexc(v uint32) Color          { return Color(0xFF000000 | v) }
func (c Color) alpha(a byte) Color { return Color(uint32(c)&0x00FFFFFF | uint32(a)<<24) }

// ref converts to a GDI COLORREF (0x00BBGGRR).
func (c Color) ref() uint32 {
	return uint32(c)>>16&0xFF | (uint32(c)>>8&0xFF)<<8 | (uint32(c)&0xFF)<<16
}

// mix blends c towards o by t (0..1), ignoring alpha.
func (c Color) mix(o Color, t float64) Color {
	ch := func(sh uint) byte {
		a, b := float64(uint32(c)>>sh&0xFF), float64(uint32(o)>>sh&0xFF)
		return byte(math.Round(a + (b-a)*t))
	}
	return argb(0xFF, ch(16), ch(8), ch(0))
}

type canvas struct {
	hdc uintptr
	g   uintptr
}

func newCanvas(hdc uintptr) *canvas { return &canvas{hdc: hdc} }

// gfx returns the GDI+ graphics, creating it on demand (0 when GDI+ is unavailable).
func (c *canvas) gfx() uintptr {
	if c.g == 0 && gdipReady {
		pGdipCreateFromHDC.Call(c.hdc, uintptr(unsafe.Pointer(&c.g)))
		if c.g != 0 {
			pGdipSetSmoothingMode.Call(c.g, 4) // anti-alias
		}
	}
	return c.g
}

func (c *canvas) close() {
	if c.g != 0 {
		pGdipDeleteGraphics.Call(c.g)
		c.g = 0
	}
}

func solidBrush(col Color) uintptr {
	var b uintptr
	pGdipCreateSolidFill.Call(uintptr(col), uintptr(unsafe.Pointer(&b)))
	return b
}

func f32(v float32) uintptr { return uintptr(math.Float32bits(v)) }

func (c *canvas) roundPath(x, y, w, h, r int) uintptr {
	var path uintptr
	pGdipCreatePath.Call(0, uintptr(unsafe.Pointer(&path)))
	if r*2 > h {
		r = h / 2
	}
	if r*2 > w {
		r = w / 2
	}
	if r < 1 {
		r = 1
	}
	d := 2 * r
	arc := func(ax, ay int, start float32) {
		pGdipAddPathArcI.Call(path, uintptr(ax), uintptr(ay), uintptr(d), uintptr(d), f32(start), f32(90))
	}
	arc(x, y, 180)
	arc(x+w-d, y, 270)
	arc(x+w-d, y+h-d, 0)
	arc(x, y+h-d, 90)
	pGdipClosePathFigure.Call(path)
	return path
}

// fillRound draws an anti-aliased rounded rectangle (GDI fallback without GDI+).
func (c *canvas) fillRound(x, y, w, h, r int, col Color) {
	if w <= 0 || h <= 0 {
		return
	}
	g := c.gfx()
	if g == 0 {
		c.fillRect(x, y, w, h, col)
		return
	}
	b := solidBrush(col)
	p := c.roundPath(x, y, w, h, r)
	pGdipFillPath.Call(g, b, p)
	pGdipDeletePath.Call(p)
	pGdipDeleteBrush.Call(b)
}

// strokeRound draws a 1px rounded border by layering two fills.
func (c *canvas) strokeRound(x, y, w, h, r int, border, fill Color) {
	c.fillRound(x, y, w, h, r, border)
	c.fillRound(x+1, y+1, w-2, h-2, r-1, fill)
}

func (c *canvas) fillRect(x, y, w, h int, col Color) {
	if w <= 0 || h <= 0 {
		return
	}
	if g := c.gfx(); g != 0 {
		b := solidBrush(col)
		pGdipFillRectangleI.Call(g, b, uintptr(x), uintptr(y), uintptr(w), uintptr(h))
		pGdipDeleteBrush.Call(b)
		return
	}
	br, _, _ := pCreateSolidBrush.Call(uintptr(col.ref()))
	rc := RECT{int32(x), int32(y), int32(x + w), int32(y + h)}
	pFillRect.Call(c.hdc, uintptr(unsafe.Pointer(&rc)), br)
	pDeleteObject.Call(br)
}

func (c *canvas) gradientRect(x, y, w, h int, from, to Color, vertical bool) {
	if w <= 0 || h <= 0 {
		return
	}
	g := c.gfx()
	if g == 0 {
		c.fillRect(x, y, w, h, from)
		return
	}
	p1 := POINT{int32(x), int32(y)}
	p2 := POINT{int32(x + w), int32(y)}
	if vertical {
		p2 = POINT{int32(x), int32(y + h)}
	}
	var b uintptr
	pGdipCreateLineBrushI.Call(uintptr(unsafe.Pointer(&p1)), uintptr(unsafe.Pointer(&p2)), uintptr(from), uintptr(to), 0, uintptr(unsafe.Pointer(&b)))
	if b == 0 {
		c.fillRect(x, y, w, h, from)
		return
	}
	pGdipFillRectangleI.Call(g, b, uintptr(x), uintptr(y), uintptr(w), uintptr(h))
	pGdipDeleteBrush.Call(b)
}

func (c *canvas) dot(cx, cy, r int, col Color) {
	g := c.gfx()
	if g == 0 {
		c.fillRect(cx-r, cy-r, 2*r, 2*r, col)
		return
	}
	b := solidBrush(col)
	pGdipFillEllipseI.Call(g, b, uintptr(cx-r), uintptr(cy-r), uintptr(2*r), uintptr(2*r))
	pGdipDeleteBrush.Call(b)
}

// text draws GDI text (ClearType) inside a rectangle.
func (c *canvas) text(s string, x, y, w, h int, font uintptr, col Color, flags uint32) {
	if s == "" || w <= 0 {
		return
	}
	c.close() // flush GDI+ before GDI text
	old, _, _ := pSelectObject.Call(c.hdc, font)
	pSetBkMode.Call(c.hdc, TRANSPARENT)
	pSetTextColor.Call(c.hdc, uintptr(col.ref()))
	rc := RECT{int32(x), int32(y), int32(x + w), int32(y + h)}
	pDrawTextW.Call(c.hdc, uintptr(unsafe.Pointer(u16(s))), ^uintptr(0), uintptr(unsafe.Pointer(&rc)), uintptr(flags|DT_NOPREFIX))
	pSelectObject.Call(c.hdc, old)
}

// measure returns the height needed to wrap s into width w (or the single-line width).
func measure(hdc uintptr, s string, font uintptr, w int, wrap bool) (int, int) {
	if s == "" {
		return 0, 0
	}
	old, _, _ := pSelectObject.Call(hdc, font)
	rc := RECT{0, 0, int32(w), 0}
	flags := uintptr(DT_CALCRECT | DT_NOPREFIX)
	if wrap {
		flags |= DT_WORDBREAK | DT_EDITCONTROL
	} else {
		flags |= DT_SINGLELINE
	}
	pDrawTextW.Call(hdc, uintptr(unsafe.Pointer(u16(s))), ^uintptr(0), uintptr(unsafe.Pointer(&rc)), flags)
	pSelectObject.Call(hdc, old)
	return int(rc.Right - rc.Left), int(rc.Bottom - rc.Top)
}

// backBuffer is a memory DC for flicker-free painting.
type backBuffer struct {
	dst, dc, bmp, old uintptr
	w, h              int
}

func newBackBuffer(dst uintptr, w, h int) *backBuffer {
	if w < 1 {
		w = 1
	}
	if h < 1 {
		h = 1
	}
	bb := &backBuffer{dst: dst, w: w, h: h}
	bb.dc, _, _ = pCreateCompatibleDC.Call(dst)
	bb.bmp, _, _ = pCreateCompatibleBitmap.Call(dst, uintptr(w), uintptr(h))
	bb.old, _, _ = pSelectObject.Call(bb.dc, bb.bmp)
	return bb
}

func (bb *backBuffer) flush(x, y int) {
	pBitBlt.Call(bb.dst, uintptr(x), uintptr(y), uintptr(bb.w), uintptr(bb.h), bb.dc, 0, 0, 0x00CC0020)
	pSelectObject.Call(bb.dc, bb.old)
	pDeleteObject.Call(bb.bmp)
	pDeleteDC.Call(bb.dc)
}

func darkTitleBar(hwnd uintptr, caption Color) {
	if pDwmSetWindowAttribute.Find() != nil {
		return
	}
	on := int32(1)
	pDwmSetWindowAttribute.Call(hwnd, 20, uintptr(unsafe.Pointer(&on)), 4) // DWMWA_USE_IMMERSIVE_DARK_MODE
	pDwmSetWindowAttribute.Call(hwnd, 19, uintptr(unsafe.Pointer(&on)), 4) // pre-20H1 builds
	ref := caption.ref()
	pDwmSetWindowAttribute.Call(hwnd, 35, uintptr(unsafe.Pointer(&ref)), 4) // DWMWA_CAPTION_COLOR (Win11)
}

var (
	pSetTextCharacterExtra = gdi32.NewProc("SetTextCharacterExtra")
	pGetTextFaceW          = gdi32.NewProc("GetTextFaceW")
)

// textX draws text with extra letter spacing (tracking), for HUD-style caps.
func (c *canvas) textX(s string, x, y, w, h int, font uintptr, col Color, flags uint32, spacing int) {
	c.close()
	pSetTextCharacterExtra.Call(c.hdc, uintptr(spacing))
	c.text(s, x, y, w, h, font, col, flags)
	pSetTextCharacterExtra.Call(c.hdc, 0)
}

// neonText draws a soft halo behind the text (cheap neon-sign glow).
func (c *canvas) neonText(s string, x, y, w, h int, font uintptr, core, halo Color, flags uint32, spacing int) {
	for _, o := range [][2]int{{-2, 0}, {2, 0}, {0, -2}, {0, 2}, {-1, -1}, {1, 1}, {-1, 1}, {1, -1}} {
		c.textX(s, x+o[0], y+o[1], w, h, font, halo, flags, spacing)
	}
	c.textX(s, x, y, w, h, font, core, flags, spacing)
}

// glow paints fading translucent rings around a rectangle.
func (c *canvas) glow(x, y, w, h, spread int, col Color) {
	for i := spread; i >= 1; i-- {
		a := byte(8 + (spread-i)*(40/spread))
		c.fillRound(x-i, y-i, w+2*i, h+2*i, i+1, col.alpha(a))
	}
}

func createFontEx(height, weight int, charset byte, pitch byte, face string) uintptr {
	h, _, _ := pCreateFontW.Call(uintptr(int32(-height)), 0, 0, 0, uintptr(weight), 0, 0, 0,
		uintptr(charset), 0, 0, 5 /*CLEARTYPE_QUALITY*/, uintptr(pitch), uintptr(unsafe.Pointer(u16(face))))
	return h
}

// pickFont returns the first face that is actually installed.
func pickFont(height, weight int, charset, pitch byte, faces ...string) uintptr {
	hdc, _, _ := pGetDC.Call(0)
	defer pReleaseDC.Call(0, hdc)
	var last uintptr
	for _, face := range faces {
		f := createFontEx(height, weight, charset, pitch, face)
		old, _, _ := pSelectObject.Call(hdc, f)
		buf := make([]uint16, 64)
		pGetTextFaceW.Call(hdc, 64, uintptr(unsafe.Pointer(&buf[0])))
		pSelectObject.Call(hdc, old)
		got := strings.ToLower(syscall.UTF16ToString(buf))
		if strings.HasPrefix(got, strings.ToLower(strings.Fields(face)[0])) {
			if last != 0 {
				pDeleteObject.Call(last)
			}
			return f
		}
		if last != 0 {
			pDeleteObject.Call(last)
		}
		last = f
	}
	return last
}
