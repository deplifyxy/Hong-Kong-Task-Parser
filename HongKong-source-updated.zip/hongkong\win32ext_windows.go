//go:build windows

package main

var (
	pSetTimer          = user32.NewProc("SetTimer")
	pKillTimer         = user32.NewProc("KillTimer")
	pTrackMouseEvent   = user32.NewProc("TrackMouseEvent")
	pSetScrollInfo     = user32.NewProc("SetScrollInfo")
	pGetScrollInfo     = user32.NewProc("GetScrollInfo")
	pScreenToClient    = user32.NewProc("ScreenToClient")
	pSetCursor         = user32.NewProc("SetCursor")
	pGetFocus          = user32.NewProc("GetFocus")
	pSetWindowSubclass = comctl32.NewProc("SetWindowSubclass")
	pDefSubclassProc   = comctl32.NewProc("DefSubclassProc")
	pImageListCreate   = comctl32.NewProc("ImageList_Create")
)

const (
	WM_SETCURSOR     = 0x0020
	WM_ERASEBKGND    = 0x0014
	WM_DRAWITEM      = 0x002B
	WM_TIMER         = 0x0113
	WM_VSCROLL       = 0x0115
	WM_MOUSEMOVE     = 0x0200
	WM_LBUTTONDOWN   = 0x0201
	WM_LBUTTONDBLCLK = 0x0203
	WM_MOUSEWHEEL    = 0x020A
	WM_MOUSELEAVE    = 0x02A3

	BS_OWNERDRAW     = 0xB
	BN_DOUBLECLICKED = 5
	ODS_SELECTED     = 0x1
	ODS_DISABLED     = 0x4

	EN_SETFOCUS  = 0x0100
	EN_KILLFOCUS = 0x0200

	TME_LEAVE = 0x2
	IDC_HAND  = 32649

	SB_VERT          = 1
	SIF_RANGE        = 0x1
	SIF_PAGE         = 0x2
	SIF_POS          = 0x4
	SIF_TRACKPOS     = 0x10
	SB_LINEUP        = 0
	SB_LINEDOWN      = 1
	SB_PAGEUP        = 2
	SB_PAGEDOWN      = 3
	SB_THUMBTRACK    = 5
	SB_THUMBPOSITION = 4
	SB_TOP           = 6
	SB_BOTTOM        = 7

	DT_CENTER      = 0x1
	DT_RIGHT       = 0x2
	DT_WORDBREAK   = 0x10
	DT_CALCRECT    = 0x400
	DT_EDITCONTROL = 0x2000

	LVM_SETBKCOLOR     = LVM_FIRST + 1
	LVM_SETIMAGELIST   = LVM_FIRST + 3
	LVM_GETITEMRECT    = LVM_FIRST + 14
	LVM_GETCOLUMNWIDTH = LVM_FIRST + 29
	LVM_GETHEADER      = LVM_FIRST + 31
	LVM_SETTEXTCOLOR   = LVM_FIRST + 36
	LVM_SETTEXTBKCOLOR = LVM_FIRST + 38
	LVS_NOCOLUMNHEADER = 0x4000

	CDDS_POSTPAINT       = 0x2
	CDRF_SKIPDEFAULT     = 0x4
	CDRF_NOTIFYPOSTPAINT = 0x10

	ILC_COLOR32 = 0x20
)

type DRAWITEMSTRUCT struct {
	CtlType    uint32
	CtlID      uint32
	ItemID     uint32
	ItemAction uint32
	ItemState  uint32
	HwndItem   uintptr
	HDC        uintptr
	RcItem     RECT
	ItemData   uintptr
}

type SCROLLINFO struct {
	CbSize    uint32
	FMask     uint32
	NMin      int32
	NMax      int32
	NPage     uint32
	NPos      int32
	NTrackPos int32
}

type TRACKMOUSEEVENT struct {
	CbSize      uint32
	DwFlags     uint32
	HwndTrack   uintptr
	DwHoverTime uint32
}
